source(findFile("scripts", "initialize.py"))

def main():

#     launchEmulator()
    launchMacchia()
#     disconnectAllSystem()
#     connectEmulator()
    click(outputTab)
    click(screenTypeOutput)
    deleteDestinations("all")
    addScreenDestination(1)
    addOutputsToDestination(4,1)
    editDestination(1)
    