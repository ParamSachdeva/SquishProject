from toplevelwindow import *
source(findFile("scripts", "initialize.py"))


def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    win = ToplevelWindow.focused()
    geom = win.geometry
    width  = geom.width
    height = geom.height/40
# moveDetachableTab(tabName, sourceOccurrence,xPos, yPos, destinationOccurrence)
    moveDetachableTab("Input", 3, int(-width/5.5), height, 3)
    moveDetachableTab("Custom Format",4,int(-width/2.50), height,4)
    moveDetachableTab("Device(s)", 1, int(width/6.8), height, 5)
    moveDetachableTab("Destination",6,int(-width/1.95), height,6)
    moveDetachableTab("Input",3,int(-width/1.8),height,1)
    moveDetachableTab("Custom Format",3,int(-width/2.2),height,1)
    moveDetachableTab("Device(s)",3,int(width/1.5),height,4)
    moveDetachableTab("Destination",3,int(-width/4),height,1)