source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))


def main():
    test.log("Verification of SDI Input Adjustments Color Tab Section")
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  
    connectEmulator()
    selectInput(9, 9, "asc")
    createInputs()
    verifyInput("dp")
    verifyColorTabSection()
    verifyDraggerColorTab()
    verifyPlusMinusColorTab()