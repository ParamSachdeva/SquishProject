source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))


def main():
    test.log("Verification of DP Input Adjustments Settings Tab Section")
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  
    connectEmulator()
    selectInput(9, 9, "asc")
    createInputs()
    verifyInput("dp")
    verifySettingTabSection()

    
    formats = ['1024x2160', '1024x768']
    verifyFormats(formats)
    
    frequencies = ['23.98','24']
    verifyFrequencies(frequencies)
    
    colorspaces = ['RGB,Full Range', 'RGB,Reduced Range']
    verifyColorSpaces(colorspaces)
    
    colorimeters = ['BT.601','BT.709']
    verifyColorimeters(colorimeters)
    
    hdcpModes = ['HDCP 1.x', 'HDCP 2.2']
    verifyHDCPModes(hdcpModes)
    
      
    updateAndVerifyTextBox(inputName,"testdp")