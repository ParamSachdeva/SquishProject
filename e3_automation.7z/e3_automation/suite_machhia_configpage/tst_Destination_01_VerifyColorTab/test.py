source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "destinations.py"))


def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(destinationTab)
    deleteDestinations("all")
    addScreenDestination(1)
    selectScreenDestination(1,"list")
    click(colorTab)
    verifyZoomFunctionality(zoomAlltabObj,aoiRect)
    verifyDestinationSubTabSectionEnabledDisabled("Color", resetAllButton, colorTabDestinationOutputRectangle)
    verifyAdjustmentUsingSliderValues()
    verifyResetContrastFunctionality("max") #Testing Maximum Slider Value
    verifyResetContrastFunctionality("min") #Testing Minimum Slider Value
    verifyResetBrightnessFunctionality("max") #Testing Maximum Slider Value
    verifyResetBrightnessFunctionality("min") #Testing Minimum Slider Value
    verifyResetAllFunctionality("max") #Testing Maximum Slider Value
    verifyResetAllFunctionality("min") #Testing Minimum Slider Value
    verifyPlusMinusButtonAdjustmentValues("-")
    verifyPlusMinusButtonAdjustmentValues("+")
    verifyAdjustmentsUsingeditboxColor()