source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():    
    launchMacchia()
    disconnectAllSystem() 
    statusIcon = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objDeviceStateImage", "occurrence": 1, "type": "CustomImage"}
   
    compareTwoTexts(str(waitForObject(statusIcon).source.path),"/images/generalImages/g7_yellowDot.png")
    systemDrop()
    snooze(.5)
    compareTwoTexts(str(waitForObject(statusIcon).source.path), "/images/generalImages/g7_greenDot.png")
    snooze(.5)
    disconnectAllSystem()    
    compareTwoTexts(str(waitForObject(statusIcon).source.path), "/images/generalImages/g7_yellowDot.png")