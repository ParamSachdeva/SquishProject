source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():
    launchMacchia()
    disconnectAllSystem()     
    moveDevicesDetachableTab("mid")
    setWindowState(waitForObject(barco_Inc_Event_Master_Toolset_WindowUI), WindowState.Normal)
    snooze(0.5)
    objectNotExist(devices_Tab)    
    snooze(0.5)
    setWindowState(waitForObject(barco_Inc_Event_Master_Toolset_WindowUI), WindowState.Maximize)
    objectExist(deviceHeader)       
    closeApp()       