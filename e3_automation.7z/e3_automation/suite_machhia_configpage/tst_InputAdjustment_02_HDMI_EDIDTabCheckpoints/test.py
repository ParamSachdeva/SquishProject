source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))

def main():
    test.log("Verification of HDMI Input Adjustments EDID tab section")
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  
    connectEmulator()
    
    selectInput(10, 10, "asc")
    createInputs()
    verifyInput("hdmi")
    
    verifyEDIDTabSection()
    
    files = ['None']    
    verifyEDIDFiles(files)
    
    edidformats = ['1024x2160', '1024x768']
    verifyFormats(edidformats)
    
    edidfrequencies = ['23.98','24']
    verifyFrequencies(edidfrequencies)
    
    bitdepths = ['8','9', '10', '12']
    verifyBitDepths(bitdepths)
    
