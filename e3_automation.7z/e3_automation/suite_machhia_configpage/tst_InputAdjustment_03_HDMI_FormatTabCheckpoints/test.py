source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))

def main():
    test.log("Verification of HDMI Input Adjustments format tab section")
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  
    connectEmulator()
    selectInput(10, 10, "asc")
    createInputs()
    verifyInput("hdmi")
    verifyFormatTabSection()
    
    formats = ['1024x2160', '1024x768']
    verifyFormats(formats)
    
    frequencies = ['23.98', '24']
    verifyFrequencies(frequencies)