source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "multioperator.py"))


def main():
    test.log("Multi Operator Enable/Disable")
    launchMacchia()
    launchEmulator()    
    connectEmulator()
    launchMultioperator()
    enableOperator(1)
    enableOperator(2)
    enableOperator(3)
    disableOperator(1)
    disableOperator(2)
    disableOperator(3)