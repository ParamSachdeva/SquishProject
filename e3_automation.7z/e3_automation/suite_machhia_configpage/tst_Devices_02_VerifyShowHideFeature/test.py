source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():   
    launchMacchia()
    snooze(.5)          
    for x in range(3):
        expandobj = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "occurrence": str(x+1), "visible": True}
        mouseClick(waitForObject(expandobj))
    
    snooze(1)     
    objectExist(vScrollBar)    
    for x in range(1):
        expandobj = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "occurrence": str(x+1), "visible": True}
        mouseClick(waitForObject(expandobj))      
    snooze(.5)         
    objectNotExist(vScrollBar)