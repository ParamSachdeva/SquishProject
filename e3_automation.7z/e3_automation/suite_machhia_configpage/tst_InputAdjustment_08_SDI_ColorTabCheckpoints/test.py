source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))


def main():
    test.log("Verification of SDI Input Adjustments Color Tab Section")
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  
    connectEmulator()
    selectInput(11, 11, "asc")
    createInputs()
    verifyInput("sdi")
    
    verifyColorTabSection()
    verifyDraggerColorTab()
    verifyPlusMinusColorTab()
