source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "multioperator.py"))


def main():
    test.log("Multi Operator set Presets")
    launchMacchia()
    launchEmulator()
    connectEmulator()    
    launchMultioperator()
    setPresetRange(1,10,100)
    setPresetRange(2,20,200)
    setPresetRange(3,30,300)
    #Reset
    setPresetRange(1,1,1000)
    setPresetRange(2,1,1000)
    setPresetRange(3,1,1000)