source(findFile("scripts", "initialize.py"))

def main():
    test.log("Validate Performance Time for areas: "
    + "Application Launch, Emulator Launch, System Active State")    
       
    t0 = time.time()
    launchMacchia() 
    t1 = time.time()
    verifyTimer(t1-t0,"launchMacchia")  
    disconnectAllSystem()  
    launchEmulator()      
    t0 = time.time()
    connectEmulator()
    t1 = time.time()
    verifyTimer(t1-t0,"connectEmulator")

    t0 = time.time()
    closeEmulator()
    t1 = time.time()
    verifyTimer(t1-t0,"closeEmulator")

    t0 = time.time()
    closeApp()
    t1 = time.time()
    verifyTimer(t1-t0,"closeApp")