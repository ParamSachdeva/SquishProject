source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))

def main():   
    test.log("Verify Multiple Input Creation Feature") 
    closeEmulator() 
    launchMacchia()   
    resetEmulator()
    launchEmulator()  
    connectEmulator()  
    #createMultipleInputs(4)  
    verifyaddAllInputs("Hdmi")      
    deleteAllInputs(4,3)