source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "customFormat.py"))


def main():
    test.log("Verification of custom format adjustment tab")
    
    launchMacchia()
    launchEmulator()   
    connectEmulator()
    
    click(customTab)
    objectExist(customFileMessage)  
    
    click(connector_0_1_0)
    createInputs()
    verifyInput("hdmi")
     
    click(connector_0_1_0)
    saveCustomFormatFromInput()
    verifyStatusBar("Custom Format is saved by the name: CustomFormat 1")
    verifyCustomFile("CustomFormat 1")
    
 
    selectDestination("ScreenDest1")
    saveCustomFormatFromDest()
    verifyStatusBar("Custom Format is saved by the name: CustomFormat 2")
    verifyCustomFile("CustomFormat 2")
    
  
    
    