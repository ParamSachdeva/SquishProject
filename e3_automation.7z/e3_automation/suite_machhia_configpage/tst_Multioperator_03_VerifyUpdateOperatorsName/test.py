source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "multioperator.py"))


def main():
    test.log("Multi Operator Rename Operators")
    launchMacchia()
    launchEmulator()   
    connectEmulator()
    launchMultioperator()
    renameOperator(1,"test1")
    renameOperator(2,"test2")
    renameOperator(3,"test3")
    #Reset
    renameOperator(1,"Operator1")
    renameOperator(2,"Operator2")
    renameOperator(3,"Operator3")