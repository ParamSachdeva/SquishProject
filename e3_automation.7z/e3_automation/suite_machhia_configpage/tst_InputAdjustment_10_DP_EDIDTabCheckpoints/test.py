source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))


def main():
    test.log("Verification of DP Input Adjustments EDID Tab Section")
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  
    connectEmulator()
    selectInput(9, 9, "asc")
    createInputs()
    verifyInput("dp")
    verifyEDIDTabSection()
    
    files = ['None']    
    verifyEDIDFiles(files)
    
    edidformats = ['1024x2160', '1024x768']
    verifyFormats(edidformats)
    
    edidfrequencies = ['23.98','24']
    verifyFrequencies(edidfrequencies)
    
    bitdepths = ['8','9', '10', '12']
    verifyBitDepths(bitdepths)