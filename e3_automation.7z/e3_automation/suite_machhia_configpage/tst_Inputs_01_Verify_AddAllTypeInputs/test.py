source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))

def main():   
    
    test.log("Verify Input Creation Feature")
    closeEmulator() 
    launchMacchia()   
    resetEmulator()
    launchEmulator()  
    connectEmulator()
    #verifyaddAllInputs("Hdmi")
    #verifyaddAllInputs("Dp")
    #verifyaddAllInputs("Sdi")

     
      
    
#createInputs()
#     verifyInput("dp")
#     selectInput(10, 10, "asc")
#     createInputs()
#     verifyInput("hdmi")
#     selectInput(11, 11, "asc")
#     createInputs()
#     verifyInput("sdi")
#     selectInput(12, 14, "asc")
#     createInputs()
#     verifyStatusBar("Error: Three connectors can't be added as an single Input")   
#     closeEmulator()