source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():
    launchMacchia()
    disconnectAllSystem()  
    launchEmulator()
    test.log("Emulator IP: " + ip_address)
    status = False
    for ip in findAllObjects(IPs):
        test.log(str(waitForObject(ip).text))
        if (str(waitForObject(ip).text) == ip_address):
            status = True
            break    
    if(status):
        test.verify(True, "Emulator available under devices Tab")
    else:
        test.fail("Emulator not available under devices Tab") 
    closeEmulator()