from toplevelwindow import *

source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():
    launchMacchia()
    disconnectAllSystem()  
    win = ToplevelWindow.focused()
    geom = win.geometry
    width  = geom.width
    height = geom.height/40
    moveDetachableTab("Device(s)", 1, int(width/6.8), height, 3)
    moveDetachableTab("Device(s)", 3, int(width/1.5), height, 3)
    moveDetachableTab("Device(s)", 3, int(-width/1.2), height, 1)

#     moveDevicesDetachableTab("mid")
#     closeDevicesDetachableTab()
#     moveDevicesDetachableTab("right")
#     moveDevicesDetachableTab("left")
#     closeDevicesDetachableTab()
