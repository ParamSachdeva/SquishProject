source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "multioperator.py"))


def main():
    test.log("Multi Operator Update Password and Show Hide Password")
    launchMacchia()   
    launchEmulator()   
    connectEmulator()
    launchMultioperator()
    verifyShowHidePassword()   
    updateOperatorPassword("test")
    #Reset
    updateOperatorPassword("password")