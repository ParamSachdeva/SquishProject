source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():
    launchMacchia()
    disconnectAllSystem()     
    moveDevicesDetachableTab("mid")
    snooze(0.5)
    objectExist(deviceHeader)  
    closeDevicesDetachableTab()
    snooze(0.5)
    objectNotExist(deviceHeader) 
    objectExist(devices_Tab)            
    closeApp()       