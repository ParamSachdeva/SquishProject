source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():
    header = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "id": "textItem", "type": "CustomText", "unnamed": 1, "visible": True}
    
    launchMacchia()
    disconnectAllSystem()   
    test.compare(str(waitForObject(header).text),"Device(s)")      
    moveDevicesDetachableTab("mid")