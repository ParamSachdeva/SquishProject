source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "systemModifier.py"))

import random

nativeRateArrowObj = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True} 
systemNativeRateComboBox = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "id": "objEnabledGradRect", "type": "Rectangle", "unnamed": 1, "visible": True}

def main():
    test.log("Verification of custom format creation, rename, deletion using custom tab")
    
    launchMacchia()
    launchEmulator() 
    disconnectAllSystem()  
    connectEmulator() 
    expandSystemModifier()
    verifySystemModifierDefaultValue()
      
    for nativeRate in defaultSystemNativeRateList:
        setSystemNativeRate(nativeRate)
         
    for presetMode in defaultPresetConflictModeList:    
        setPresetConflictMode(presetMode)
     
    randomTimeValue = randint(0, 999)
    setPresetConflictTime(randomTimeValue)    
     
    for genlockType in defaultGenlockTypeList:
        setGenlock(genlockType)
     
    randomUnitId = random.randint(0, 13)
    test.log("Print value for random Unit ID"+str(randomUnitId))
    setGenlockUnitId(randomUnitId)
     
    randomHorizontalOffset = random.randint(-100, 100)
    test.log("Print value for random H offset"+str(randomHorizontalOffset))
    setHorizontalOffset(randomHorizontalOffset)
     
    randomVerticalOffset = random.randint(-100, 100)
    test.log("Print value for random V offset"+str(randomVerticalOffset))
    setVerticalOffset(randomVerticalOffset)