source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))

def main():
    test.log("Verification of SDI Input Adjustments Settings Tab Section")
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  
    connectEmulator()
    selectInput(11, 11, "asc")
    createInputs()
    verifyInput("sdi")
    
    verifySettingTabSection()
    
    formats = ['1024x2160', '1024x768']
    verifyFormats(formats)
    
    frequencies = ['23.98','24']
    verifyFrequencies(frequencies)
    
    colorspaces = ['RGB,Full Range', 'RGB,Reduced Range']
    verifyColorSpaces(colorspaces)
    
    sdiTypes = ['SD', 'HD', 'LevelA', "LevelB", 'LevelA 2SI', 'LevelB 2SI', '6G', '12G']
    verifySDITypes(sdiTypes)
    
    updateAndVerifyTextBox(inputName,"testsdi")