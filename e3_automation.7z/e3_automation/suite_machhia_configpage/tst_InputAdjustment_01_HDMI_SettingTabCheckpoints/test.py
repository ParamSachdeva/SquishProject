source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))

def main():
    test.log("Verification of HDMI Input Adjustments Settings Tab Section")
    closeEmulator() 
    launchMacchia()   
    resetEmulator()
    launchEmulator()  
    connectEmulator()        
    verifyaddAllInputs("Hdmi")
    
    selectInput(5,5, "asc")
    
    verifySettingTabSection()
    
    formats = ['1024x2160', '1024x768']
    verifyFormats(formats)
    
    frequencies = ['23.98','24']
    verifyFrequencies(frequencies)
    
    colorspaces = ['RGB,Full Range', 'RGB,Reduced Range']
    verifyColorSpaces(colorspaces)
    
    colorimeters = ['BT.601','BT.709']
    verifyColorimeters(colorimeters)
    
    hdcpModes = ['HDCP 1.x', 'HDCP 2.2']
    verifyHDCPModes(hdcpModes)
    
      
    updateAndVerifyTextBox(inputName,"testhdmi")