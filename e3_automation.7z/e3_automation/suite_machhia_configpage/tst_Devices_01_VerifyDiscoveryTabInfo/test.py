source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))

def main():    
    launchMacchia() 
    disconnectAllSystem()    
    addSystem("10.98.6.187")   
    #verifyDiscoveryInfo("E2-Gen2","System1","10.98.6.188","(H)","/images/generalImages/g7_greenDot.png","9876","c4:00:ad:20:e0:17","E2-Gen2-32L","1","c4:00:ad:20:e0:17","9.2.5791","0",True)    
    verifyDiscoveryInfo("EX-d026","System1","10.98.6.187","(H)","/images/generalImages/g7_greenDot.png","9876","00:0b:ab:c7:d0:26","EX","1","00:0b:ab:c7:d0:26","9.1.5417","2",True)    
    verifyDiscoveryInfo("ImagePRO 4K","System1","10.98.6.67","(H)","/images/generalImages/g7_yellowDot.png","9876","00:0b:ab:d2:5c:a7","ImagePRO 4K","1","00:0b:ab:d2:5c:a7","9.2.5791","0",False)    
    closeApp()   