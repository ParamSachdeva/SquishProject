source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))


def main():
    test.log("Verification of SDI Input Adjustments Format Tab Section")
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  
    connectEmulator()
    selectInput(9, 9, "asc")
    createInputs()
    verifyInput("dp")
    verifyFormatTabSection()
       
    formats = ['1024x2160', '1024x768']
    verifyFormats(formats)
    
    frequencies = ['23.98', '24']
    verifyFrequencies(frequencies)
    