source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  

    addSystem(str(waitForObject(IPs).text))  
    test.compare(str(waitForObject(discoveredSystem).color.name), "#5f5f5f")
    disconnectAllSystem()
    test.compare(str(waitForObject(discoveredSystem).color.name), "#474747")    
    systemDrop()
    test.compare(str(waitForObject(discoveredSystem).color.name), "#5f5f5f")
    disconnectAllSystem()
    test.compare(str(waitForObject(discoveredSystem).color.name), "#474747")