import builtins
import math
source(findFile('scripts', 'initialize.py'))

def main():
 
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(outputTab)
    click(screenTypeOutput)
    deleteDestinations('allonebyone')
    addScreenDestination(1)
    editDestination(1)
    deleteExistingOutputs()
     
    resolutionVals = getDisplayedResolutions()

    TotalH = [3840,5760]
    TotalV = 2160
    for k in TotalH:
        setTotalHortzontalVertical(k,TotalV)
        for i in resolutionVals:
            test.log(str(i))
            setOutputResolution(i)
            a = math.ceil(k / builtins.int(str(i).split('x')[0]))
            b = math.ceil(TotalV / builtins.int(str(i).split('x')[1].split('p')[0]))
            verifyNumberOfOutputs(a*b)
  
    #zero is passed as string because numeric 0 was giving error with squish ide
    setTotalHortzontalVertical('0','0')
    verifyNumberOfOutputs('0')
     
    setTotalHortzontalVertical(3840,2160)
    setOutputResolution('1920x1080')
    click(addOutputApplyChangesButton)
    verifyNumOfOpOnSystemWindow(str(4))