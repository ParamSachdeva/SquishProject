source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "customFormat.py"))

def main():
    test.log("Verification of custom format adjustment tab")
    
    launchMacchia()
    launchEmulator()   
    connectEmulator()

    addCustomFormat(2);
    verifyCustomAdjustDefaultValue("CustomFormat 1")
    
    saveCustomFormat("CustomFormat 2")
    verifyStatusBar("Custom Format is saved by the name: CustomFormat 3");
    verifyCustomFile("CustomFormat 3")

    

       

    