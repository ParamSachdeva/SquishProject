source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))

def main():
    test.log("Verification of HDMI Input Adjustments Color tab section")
   
    launchMacchia()
    disconnectAllSystem() 
    launchEmulator()  
    connectEmulator()
    selectInput(10, 10, "asc")
    createInputs()
    verifyInput("hdmi")
    verifyColorTabSection()
    verifyDraggerColorTab()
    verifyPlusMinusColorTab()
    
