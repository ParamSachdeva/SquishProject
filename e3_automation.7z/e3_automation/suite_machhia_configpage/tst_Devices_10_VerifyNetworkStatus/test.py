source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():
    statusIcon = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objDeviceStateImage", "type": "CustomImage"}

    launchMacchia()
    disconnectAllSystem()  
    launchEmulator()  
    connectEmulator()     
    objectExist(statusIcon)   
    compareTwoTexts(str(waitForObject(statusIcon).source.path), "/images/generalImages/g7_yellowDot.png")     
    disconnectAllSystem()   
    compareTwoTexts(str(waitForObject(statusIcon).source.path), "/images/generalImages/g7_yellowDot.png")     
    systemDrop()  
    compareTwoTexts(str(waitForObject(statusIcon).source.path), "/images/generalImages/g7_greenDot.png") 
    closeEmulator()
    snooze(10)
    compareTwoTexts(str(waitForObject(statusIcon).source.path), "/images/generalImages/g7_redDot.png")     