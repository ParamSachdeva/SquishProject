source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "customFormat.py"))


def main():
    test.log("Verification of custom format creation, rename, deletion using custom tab")
    launchMacchia()
    launchEmulator()    
    connectEmulator()   
    click(customTab)
    objectExist(customFileMessage)   
    addCustomFormat(5);
    
    i = 1
    while (i <= 5):
        verifyCustomFile("CustomFormat " + str(i))
        i += 1
    
    renameCustomFormat("CustomFormat 4", "CustomTest-1920x1600@60")
    selectCustomFormat("CustomFormat 3")
    verifyCustomAdjustName("CustomTest-1920x1600@60")
     
    for j in range(5):     
        deleteCustomFormat(customDeleteBtn)
        j += 1
         
    objectExist(customFileMessage);   
