source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))


def main():   
    test.log("Verify Input Creation Feature")
    closeEmulator() 
    launchMacchia()   
    resetEmulator()
    launchEmulator()  
    connectEmulator()  
    verifyaddAllInputs("Hdmi")
    selectInput(9, 9, "asc")
    createInputs()
    verifyStatusBar("Error! Please select connectors before pressing 'Add'")