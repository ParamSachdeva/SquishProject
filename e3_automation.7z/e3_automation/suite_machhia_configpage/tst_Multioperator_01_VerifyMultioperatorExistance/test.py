source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "multioperator.py"))

def main():
    test.log("Multi Operator Existance")
    launchMacchia()
    disconnectAllSystem()    
    verifyMultioperatorNotExist() 
    launchEmulator()
    connectEmulator()
    verifyMultioperatorExist()