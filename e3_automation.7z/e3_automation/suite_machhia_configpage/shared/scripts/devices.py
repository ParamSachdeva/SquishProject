from objectmaphelper import *

barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Overlay = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "type": "Overlay", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Device_s_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objDeviceTab", "title": "Device(s)", "type": "CustomTab", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_tabbar_TabBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "tabbar", "type": "TabBar", "visible": True}

discoveredSystem =  {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objDropDownHeader", "type": "DropDownHeader", "visible": True}    
devices_Tab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "Device(s)", "type": "CustomText", "unnamed": 1, "visible": True}
deviceHeader =  {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "headerRect", "type": "Rectangle", "unnamed": 1, "visible": True}
vScrollBar = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "id": "vscrollbar", "orientation": 2, "type": "ScrollBar", "unnamed": 1, "visible": True}
IPs = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objIPAddressText","type": "CustomText"}

def verifyDiscoveryInfo(dName,sName,dIP,hostClient,sIcon,xml,mType,sType,vCount,hMac,sVersion,uID,tick):    
    test.log("verifyDiscoveryInfo")
    deviceName = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objHostnameText", "id":"objHostnameText", "type": "CustomText"}
    xmlPort = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objValueText", "type": "CustomText"}
    macType = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objValueText", "occurrence": 2, "type": "CustomText"}
    systemType = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objValueText", "occurrence": 3, "type": "CustomText"}
    vpCount = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objValueText", "occurrence": 4, "type": "CustomText"}
    hostMac = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objValueText", "occurrence": 5, "type": "CustomText"}
    swVersion = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objValueText", "occurrence": 6, "type": "CustomText"}
    unitID = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objValueText", "occurrence": 7, "type": "CustomText"}
    tickMark = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objSelectImage", "source": Wildcard("/images/mainWnd/icon_16_tick.png"),"type": "CustomImage", "visible": True}

    oc = 0;
    for i in findAllObjects(deviceName):
        oc+=1; 
        #test.log(str(oc) + "-" + str(i.text))
        if(str(i.text) == dName):      
            systemName = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objSystemText", "occurrence": oc, "type": "CustomText"}
            host = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objMasterSlaveText", "occurrence": oc+1, "type": "CustomText", "visible": True}
            deviceIP = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objIPAddressText", "occurrence": oc,"type": "CustomText"}
            statusIcon = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objDeviceStateImage", "occurrence": oc, "type": "CustomImage"}
            expandShrinkIcon = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"),"occurrence": oc, "type": "CustomImage", "visible": True}
            
            test.compare(str(waitForObject(systemName).text), sName)
            test.compare(str(waitForObject(deviceIP).text), dIP)
            compareTwoTexts(str(waitForObject(statusIcon).source.path),sIcon)
            test.compare(str(waitForObject(host).text), hostClient) 
      
            if(tick):
                objectExist(tickMark)
            click(expandShrinkIcon)                    
            test.compare(str(waitForObject(xmlPort).text), xml)
            test.compare(str(waitForObject(macType).text), mType)
            test.compare(str(waitForObject(systemType).text), sType)
            test.compare(str(waitForObject(vpCount).text), vCount)
            test.compare(str(waitForObject(hostMac).text), hMac)
            test.compare(str(waitForObject(swVersion).text), sVersion)
            test.compare(str(waitForObject(unitID).text), uID)               
            click(expandShrinkIcon)
           
    

def moveDevicesDetachableTab(direction):
    test.log("moveDevicesDetachableTab: " + direction)
    devices_Tab1 = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "title": "Device(s)", "type": "Tab", "unnamed": 1, "visible": True}
    deviceSection = {"container": devices_Tab1, "occurrence": 3, "type": "Flickable", "unnamed": 1, "visible": True}
  
    bx = str(waitForObject(deviceSection).transformOriginPoint.x)
    by = str(waitForObject(deviceSection).transformOriginPoint.y) 
    test.log("Pos before movement, bx: " + bx + ", by: " + by  )

  #.parent.childrenRect.x
  #.parent.childrenRect.y
  
  
    if direction == 'right':
        longMouseDrag(waitForObject(devices_Tab), 42, 0, 1600, 25, Qt.NoModifier, Qt.LeftButton) 
        snooze(0.5)    
        ax = str(waitForObject(deviceSection).transformOriginPoint.x)
        ay = str(waitForObject(deviceSection).transformOriginPoint.y)   
        test.log("pos: " + direction + ", ax: " + ax + ", ay: " + ay  )
        if bx == ax and by == ay :
            test.fail("No Movement Occured")
        else:
            test.compare("True", "True", "Detachable tab Moved properly")                            
    elif direction == 'left':
        longMouseDrag(waitForObject(deviceHeader), 42, 0, -817, 44, Qt.NoModifier, Qt.LeftButton)
        snooze(0.5)    
        ax = str(waitForObject(deviceSection).transformOriginPoint.x)
        ay = str(waitForObject(deviceSection).transformOriginPoint.y)
        test.log("pos: " + direction + ", ax: " + ax + ", ay: " + ay  )
        if bx == ax and by == ay :
            test.fail("No Movement Occured")
        else:
            test.compare("True", "True", "Detachable tab Moved properly")         
    elif direction == 'mid':
        longMouseDrag(waitForObject(devices_Tab), 42, 0, 1000, 61, Qt.NoModifier, Qt.LeftButton)
        snooze(0.5)    
        ax = str(waitForObject(deviceSection).transformOriginPoint.x)
        ay = str(waitForObject(deviceSection).transformOriginPoint.y)
        test.log("pos: " + direction + ", ax: " + ax + ", ay: " + ay  )
        if bx == ax and by == ay :
            test.fail("No Movement Occured")
        else:
            test.compare("True", "True", "Detachable tab Moved properly")         
    else:
        test.compare("True", "False", "Provide direction to move")
     
    
       
def  closeDevicesDetachableTab():
        test.log("closeDevicesDetachableTab")
        deviceCloseBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objImg", "source": Wildcard("/images/mainWnd/icon_16_close.png"), "type": "CustomImage", "visible": True}
        mouseClick(waitForObject(deviceCloseBtn), 4, 5, Qt.LeftButton)