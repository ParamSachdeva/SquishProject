import os

sd = os.path.abspath("..\..\suite_shared\shared\scripts") 
test.log("Shared Directory Path " + os.path.abspath("..\..\suite_shared\shared\scripts")) 
source(findFile("scripts", sd + "/common.py"))
source(findFile("scripts", sd + "/systemlevel.py"))
source(findFile("scripts", sd + "/configuration/devices.py"))
source(findFile("scripts", sd + "/configuration/system.py"))
source(findFile("scripts", sd + "/configuration/inputs.py"))
source(findFile("scripts", "destinations.py"))