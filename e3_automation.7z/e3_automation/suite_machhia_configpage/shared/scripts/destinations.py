mainWindowObj = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
tabBarObj = {"container": mainWindowObj, "objectName": "tabbar", "occurrence": 3, "type": "TabBar", "visible": True}
# destinationTab = {"container": tabBarObj, "text": "Destination", "type": "CustomText", "unnamed": 1, "visible": True}
destinationTab = {"container": tabBarObj, "text": "Output", "type": "CustomText", "unnamed": 1, "visible": True}
# destTabInnerArea = {"container": mainWindowObj, "id": "objCustomDestTab", "title": "Destination", "type": "CustomTab", "unnamed": 1, "visible": True}
destTabInnerArea = {"container": mainWindowObj, "id": "objCustomDestTab", "title": "Output", "type": "CustomTab", "unnamed": 1, "visible": True}
colorTab = {"container": tabBarObj, "text": "Color", "type": "CustomText", "unnamed": 1, "visible": True}
destColorTab = {"container": mainWindowObj, "id": "objColorTab", "title": "Color", "type": "CustomTab", "unnamed": 1, "visible": True}
colorTabDestinationOutputRectangle = {"container": destColorTab, "id": "objVirtualItem", "type": "Rectangle", "unnamed": 1, "visible": True}
resetAllButton = {"container": destColorTab, "text": "Reset All", "type": "CustomText", "unnamed": 1, "visible": True}
slidersInsideColorTab = {"container": destColorTab, "objectName": "objGrooveBar", "type": "ProgressBar", "visible": True}
editboxColor = {"container": destColorTab, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
outputRectange = {"container": destTabInnerArea, "id": "destOpRect", "type": "Rectangle", "unnamed": 1, "visible": True}
outputCrossButton = {"container": destTabInnerArea, "text": "x", "type": "CustomText", "unnamed": 1, "visible": True}
listOfDestinations = {"container": destTabInnerArea, "objectName": "objImg", "source":  Wildcard("/images/generalImages/g7_greenDot.png"), "type": "CustomImage", "visible": True}
addOutputCancelButton = {"container": destTabInnerArea, "text": "Cancel", "type": "CustomText", "unnamed": 1, "visible": True}
zoomAlltabObj = {"container": mainWindowObj, "id": "objCustomAdjTab", "type": "CustomTabAdj", "unnamed": 1, "visible": True}
aoiRect = {"container": mainWindowObj, "id": "objVirtualItem", "type": "Rectangle", "unnamed": 1, "visible": True}
outputTab = {"container": tabBarObj, "text": "Output", "type": "CustomText", "unnamed": 1, "visible": True}
output_objTabBar_CustomTabBar = {"container": outputTab, "id": "objTabBar", "type": "CustomTabBar", "unnamed": 1, "visible": True}
screenTypeOutput = {"container": destTabInnerArea, "id": "objTabButton", "occurrence": 1,"type": "TabButton", "unnamed": 1, "visible": True}
outputResolutionObj = {"container": destTabInnerArea, "objectName": "objFormatComboBox", "type": "BarcoSelectionBox", "visible": True}
totalHorizontalObj = {"container": destTabInnerArea, "objectName": "objTotalHorTextBox", "type": "CustomInputText", "visible": True}
totalVerticalObj = {"container": destTabInnerArea, "objectName": "objTotalVerTextBox", "type": "CustomInputText", "visible": True}
    
#####################################################################################################################

def enableDestTab(objectToBeClickedForEnabling, disabledObject):
    test.log("Enabling Object")
    if(waitForObjectExists(disabledObject).parent.enabled == False):
       click(objectToBeClickedForEnabling)
       test.verify(isObjectEnable(disabledObject))
       test.log("Object enabled successfully")
    elif(waitForObjectExists(disabledObject).parent.enabled == True):
        test.log("Object already enabled hence skipping enabling")
    else:
        test.fail("Unable to enable object")     
    
def disableDestTab(objectToBeClickedForDisabling, enabledObject):
    test.log("Disabling Object")
    if(waitForObjectExists(enabledObject).parent.enabled == True):
       click(objectToBeClickedForDisabling)
       test.verify(isObjectEnable(enabledObject))
       test.log("Object disabled successfully")
    elif(waitForObjectExists(disabledObject).parent.enabled == False):
       test.log("Object already disabled hence skipping disabling")
    else:
        test.fail("Unable to disable object")
        
def addScreenDestination(numberOfDestinations, displayType=None, resolution=None, numberOfOps=None, rotation=None):
    test.log("Adding Destinations")
    addDestContainer = {"container": mainWindowObj, "id": "objCustomDestTab", "title": "Output", "type": "CustomTab", "unnamed": 1, "visible": True}
    addDestinationExpandBtn = {"container": addDestContainer, "id": "icon", "source": Wildcard("images/svgImages/plus.svg"), "type": "Image", "unnamed": 1, "visible": True}
    addOutputBtn = {"container": addDestContainer, "id": "addOuptutButton", "type": "Rectangle", "unnamed": 1, "visible": True}
    addDestinationBtn = {"container": addDestContainer, "text": "+  Add Screen Destination", "type": "CustomText", "unnamed": 1, "visible": True}
    addDestCollapseBtn = {"container": addDestContainer, "id": "icon", "source": Wildcard("/images/svgImages/minus.svg"), "type": "Image", "unnamed": 1, "visible": True}
    for i in range (numberOfDestinations):
        existingDestLength = len(findAllObjects(listOfDestinations))
        destCenterCard = {"container": barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView, "id": "objScreenDestDetailsArea", "occurrence":i+1, "type": "Rectangle", "unnamed": 1, "visible": True}
        click(addDestinationExpandBtn)
        test.verify(isObjectDisable(addDestinationBtn))        
        if(displayType):
            selectDisplayType(displayType)
        if(resolution):
            setOutputResolution(resolution)
            if not numberOfOps:
                click(addOutputBtn)
                test.verify(waitForObjectExists(totalHorizontalObj).m_szServerText == resolution.split('x')[0])
                test.verify(waitForObjectExists(totalVerticalObj).m_szServerText == resolution.split('x')[1])
        if(numberOfOps):    
            addOutputsToDestination(numberOfOps)
        elif not (numberOfOps):
            click(addOutputBtn)
        if(rotation):
            selectRotation(rotation)
        test.verify(isObjectEnable(addDestinationBtn))
        click(addDestinationBtn)
        waitForObjectExists(destCenterCard)
        click(addDestCollapseBtn)
        if (existingDestLength >= len(findAllObjects(listOfDestinations))):
            test.fail("Unable to add destination")
            
def deleteDestinations(destinationValue):
    deleteButtonOnDestinationName = {"container": destTabInnerArea, "text": "Delete", "type": "CustomText", "unnamed": 1, "visible": True}
    if (len(findAllObjects(listOfDestinations)) == 0):
        return test.log("No destination present hence skipping delete destination step")
    j=0
    if(destinationValue.lower() == "all"):
        multiSelectList(listOfDestinations, "Destination",1)
        test.log("Deleting "+str(len(findAllObjects(listOfDestinations)))+" destinations")
        click(deleteButtonOnDestinationName)
        click(deleteButtonOnDestinationName)
        snooze(1)
        if not (len(findAllObjects(listOfDestinations)) == 0):
            test.fail("Unable to delete the destination")
            raise Exception("Unable to delete the destination")
        else:
            test.log("Destination(s) deleted successfully")  
    
    
    elif(destinationValue.lower() == "allonebyone"):
        lengthOfDestinations = len(findAllObjects(listOfDestinations))
        if(len(findAllObjects(listOfDestinations)) != 0):
            for i in findAllObjects(listOfDestinations):
                j=j+1
                lengthOfDestinations = lengthOfDestinations-1;
                click(waitForObject(i))
                click(deleteButtonOnDestinationName)
                click(deleteButtonOnDestinationName)
                snooze(1)
                if(j%15==0 or len(findAllObjects(listOfDestinations))==1):
                    snooze(.5)
                if(len(findAllObjects(listOfDestinations)) != lengthOfDestinations):
                    test.fail("Unable to delete the destination")
                    raise Exception("Unable to delete the destination")
                else:
                    test.log("Destination(s) deleted successfully")                 
        else:
            test.fail("Unable to fetch the list, please check the locator or list size")
            raise Exception("Unable to fetch the list, please check the locator or list size")
    
    elif(destinationValue.lower() != "null"):
        lengthOfDestinations = len(findAllObjects(listOfDestinations))-1
        destinationName = {"container": mainWindowObj, "objectName": "objDisplayedText", "text": destinationValue, "type": "CustomText", "visible": True}
        test.log(str(destinationName))
        if(len(findAllObjects(listOfDestinations)) != 0):
            i=1    
            while(i<10):
                try:
                    click(destinationName)
                    break
                except:
                    scrollListInsideTab("Destination", "vertical", "down", 360)
                    i=i+1
            click(deleteButtonOnDestinationName)
            click(deleteButtonOnDestinationName)
            if(len(findAllObjects(listOfDestinations)) != lengthOfDestinations):
                    test.fail("Unable to delete the destination")
                    raise Exception("Unable to delete the destination")
            else:
                    test.log("Destination(s) deleted successfully")  
        
    else:
        test.fail("Invalid destination value, acceptable parameters are \'all\' or \'destination name\' or \'allonebyone\'")
        raise Exception("Invalid destination value, acceptable parameters are \'all\' or \'destination name\' or \'allonebyone\'")
    
def deleteExistingOutputs():
    test.log("Deleting destination outputs")
    if not (object.exists(outputRectange)):
        test.log("No outputs present")
    else:
        while(object.exists(outputRectange)):
            if not (object.exists(outputCrossButton)):
                click(outputRectange)
            click(outputCrossButton)
    
def selectScreenDestination(destinationNumber, position):
    if(position.lower() == "center"):
        screenDestination = {"container": barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView, "id": "objScreenDestDetailsArea", "occurrence": destinationNumber ,"type": "Rectangle", "unnamed": 1, "visible": True}
        test.log("Center")
    elif(position.lower() == "list"):
        screenDestination = {"container": destTabInnerArea, "objectName": "objDisplayedText", "occurrence": destinationNumber, "type": "CustomText", "visible": True}
    else:
        test.fail("Invalid button type \'"+position+"\' , allowed values are \'center\' or \'list\'")
    click(screenDestination)

#commented to verify the updated function verifyZoomFunctionality() in common.py
# def verifyOutputRectangle(tabName):
#     modifiedContainer = {"container": mainWindowObj, "title": tabName, "type": "CustomTab", "unnamed": 1, "visible": True}
#     tabNameObject = {"container": tabBarObj, "text": tabName, "type": "CustomText", "unnamed": 1, "visible": True}
#     zoomValContainer ={"container": modifiedContainer, "id": "objZoomRect", "type": "ZoomRect", "unnamed": 1, "visible": True}
#     zoomVal = {"container": zoomValContainer, "type": "CustomText", "unnamed": 1, "visible": True}
#     outerRectArea = {"container": modifiedContainer, "id": "scroller", "occurrence": 2, "type": "ScrollViewHelper", "unnamed": 1, "visible": True}
#     innerRectArea = {"container": modifiedContainer, "id": "objDestWide", "type": "Rectangle", "unnamed": 1, "visible": True}
#     verticalScrollbar = {"container": outerRectArea, "id": "vscrollbar", "type": "ScrollBar", "unnamed": 1, "visible": True}
#     horizontalScrollbar = {"container": outerRectArea, "id": "hscrollbar", "type": "ScrollBar", "unnamed": 1, "visible": True}
#     click(tabNameObject)
#     compareTwoTexts("100",str(waitForObjectExists(zoomVal).text).split(" ")[0])
#     
#     possibleMinusVal = ["75", "50", "25", "0"]
#     for i in possibleMinusVal:
#         xPos = waitForObjectExists(innerRectArea).transformOriginPoint.x
#         yPos = waitForObjectExists(innerRectArea).transformOriginPoint.y
#         
#         clickPlusOrMinusButton(tabName, "-", 1, 1)
#         
#         newXPos = waitForObjectExists(innerRectArea).transformOriginPoint.x
#         newYPos = waitForObjectExists(innerRectArea).transformOriginPoint.y
#             
#         if(i == "0"):
#             compareTwoTexts("25",str(waitForObjectExists(zoomVal).text).split(" ")[0])
#             test.verify(xPos==newXPos, "Zoom out successful")
#             test.verify(yPos==newYPos, "Zoom out successful")
#         else:
#             compareTwoTexts(i,str(waitForObjectExists(zoomVal).text).split(" ")[0])
#             test.verify(xPos>newXPos, "Zoom out successful")
#             test.verify(yPos>newYPos, "Zoom out successful")
#         
#     possiblePlusVal = ["50","75","100","125", "150", "175", "200", "225"]
#     for i in possiblePlusVal:
#         xPos = waitForObjectExists(innerRectArea).transformOriginPoint.x
#         yPos = waitForObjectExists(innerRectArea).transformOriginPoint.y
#         
#         clickPlusOrMinusButton(tabName, "+", 1, 1)
#         
#         newXPos = waitForObjectExists(innerRectArea).transformOriginPoint.x
#         newYPos = waitForObjectExists(innerRectArea).transformOriginPoint.y
#         if(builtins.int(i.split(" ")[0])>100):
#             objectExist(verticalScrollbar)
#             objectExist(horizontalScrollbar)
#         else:
#             objectNotExist(verticalScrollbar)
#             objectNotExist(horizontalScrollbar)
#     
#             
#         if(i == "225"):
#             compareTwoTexts("200",str(waitForObjectExists(zoomVal).text).split(" ")[0])
#             test.verify(xPos==newXPos, "Zoom in successful")
#             test.verify(yPos==newYPos, "Zoom in successful")
#         else:
#             compareTwoTexts(i,str(waitForObjectExists(zoomVal).text).split(" ")[0])
#             test.verify(xPos<newXPos, "Zoom in successful")
#             test.verify(yPos<newYPos, "Zoom in successful")
#     
#     i=0
#     while(str(waitForObjectExists(zoomVal).text).split(" ")[0]!="100"):
#         i+=1
#         clickPlusOrMinusButton(tabName, "-", 1, 1)
#         if(i>5):
#             test.fail("unable to reset the zoom settings")
#             break;
            
def verifyDestinationSubTabSectionEnabledDisabled(tabName, objectToBeVerified, objectToBeClickedForEnablingOrDisabling):
    test.log("Verifying the enabled and disabled values inside the "+ tabName +" tab")
    tab = {"container": tabBarObj, "text": tabName, "type": "CustomText", "unnamed": 1, "visible": True}   
    click(tab)
    enableDestTab(objectToBeClickedForEnablingOrDisabling, objectToBeVerified)
    test.verify(isObjectEnable(objectToBeVerified))
    click(objectToBeClickedForEnablingOrDisabling)
    test.verify(isObjectDisable(objectToBeVerified))
    enableDestTab(objectToBeClickedForEnablingOrDisabling, objectToBeVerified)
    
def setSliderPosition(sliderObject, sliderMaxorMinPosition):
    if(sliderMaxorMinPosition.lower() == "max"):
        drag(waitForObject(sliderObject), 172, 0)
    elif(sliderMaxorMinPosition.lower() == "min"):
        drag(waitForObject(sliderObject), -141, 0)
    else:
        test.fail("Invalid value \'"+sliderMaxorMinPosition+"\' only possible values are \'max\' or \'min\'")

def verifyAdjustmentUsingSliderValues():
    test.log("Verifying the extreme possible slider values")
    enableDestTab(colorTabDestinationOutputRectangle,resetAllButton)
    for i in range(1,len(findAllObjects(slidersInsideColorTab))+1,1):
        sliderObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i, "type": "ProgressBar", "visible": True}
        sliderTextboxObject = {"container": destColorTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        if not i==(len(findAllObjects(slidersInsideColorTab))):
            sliderNextObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i+1, "type": "ProgressBar", "visible": True}
            scrollTillObjVisible(sliderNextObject, "Color", "vertical", "down", 300)
        #Slider names are as follows on the basis of indexing:
            #Contrast
                #Overall ====> 1
                #Red ========> 2
                #Green ======> 3
                #Blue =======> 4
            #Brightness    
                #Overall ====> 5
                #Red ========> 6
                #Green ======> 7
                #Blue =======> 8
                #Gamma => 9
                #Hue ========> 10
                #Saturation ======> 11
        if(i==1 or i==5):
            setSliderPosition(sliderObject, "max")
            verifyText(sliderTextboxObject, str(150))
            setSliderPosition(sliderObject, "min")
            verifyText(sliderTextboxObject, str(50))
        elif(i==9):
            setSliderPosition(sliderObject, "max")
            snooze(1)
            verifyText(sliderTextboxObject, "3.30")
            setSliderPosition(sliderObject, "min")
            verifyText(sliderTextboxObject, "0.30")
        elif(i==10):
            setSliderPosition(sliderObject, "max")
            verifyText(sliderTextboxObject, str(90))
            setSliderPosition(sliderObject, "min")
            verifyText(sliderTextboxObject, str(-90))
        elif(i==11):
            setSliderPosition(sliderObject, "max")
            verifyText(sliderTextboxObject, str(150))
            setSliderPosition(sliderObject, "min")
            verifyText(sliderTextboxObject, str(0))
        else:
            setSliderPosition(sliderObject, "max")
            verifyText(sliderTextboxObject, str(150))
            setSliderPosition(sliderObject, "min")
            verifyText(sliderTextboxObject, str(25))

def verifyColorTabResttedValues():
    for i in range(1,len(findAllObjects(slidersInsideColorTab))+1,1):
        sliderTextboxObject = {"container": destColorTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        scrollTillObjVisible(sliderTextboxObject, "Color", "vertical", "down", 220)
        mouseMove(sliderTextboxObject)
        if(i==10):
            verifyText(sliderTextboxObject, str(0))
        elif(i==9):
            verifyText(sliderTextboxObject, str(1))
        else:    
            verifyText(sliderTextboxObject, str(100))                 

def verifyResetAllFunctionality(sliderMaxorMinPosition):
    test.log("Verifying the reset all functionality of destination color tab for "+sliderMaxorMinPosition+" value")
    scrollListInsideTab("Color","vertical","up",260)
    enableDestTab(colorTabDestinationOutputRectangle,resetAllButton)
    for i in range(1,len(findAllObjects(slidersInsideColorTab))+1,1):
        sliderObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i, "type": "ProgressBar", "visible": True}
        if not i==(len(findAllObjects(slidersInsideColorTab))):
            sliderNextObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i+1, "type": "ProgressBar", "visible": True}
            scrollTillObjVisible(sliderNextObject, "Color", "vertical", "down", 300)
        setSliderPosition(sliderObject, sliderMaxorMinPosition)
    click(resetAllButton)
    scrollListInsideTab("Color","vertical","up",260)
    verifyColorTabResttedValues()

def verifyResetContrastFunctionality(sliderMaxorMinPosition):
    test.log("Verifying the reset contrast functionality of destination color tab for "+sliderMaxorMinPosition+" value")
    scrollListInsideTab("Color","vertical","up",260)
    resetContrastButton = {"container": destColorTab, "text": "Reset", "type": "CustomText", "unnamed": 1, "visible": True}    
    enableDestTab(colorTabDestinationOutputRectangle,resetAllButton)
    for i in range(1,len(findAllObjects(slidersInsideColorTab))+1,1):
        sliderObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i, "type": "ProgressBar", "visible": True}
        if not i==(len(findAllObjects(slidersInsideColorTab))):
            sliderNextObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i+1, "type": "ProgressBar", "visible": True}
            scrollTillObjVisible(sliderNextObject, "Color", "vertical", "down", 300)
        setSliderPosition(sliderObject, sliderMaxorMinPosition)
    scrollTillObjVisible(resetContrastButton, "Color", "vertical", "up", 220)
    click(resetContrastButton)
    for i in range(1,len(findAllObjects(slidersInsideColorTab))+1,1):
        sliderTextboxObject = {"container": destColorTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        if not i==(len(findAllObjects(slidersInsideColorTab))):
            sliderNextObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i+1, "type": "ProgressBar", "visible": True}
            scrollTillObjVisible(sliderNextObject, "Color", "vertical", "down", 300)
        mouseMove(sliderTextboxObject)
        if(i<5):
            verifyText(sliderTextboxObject, str(100))
        elif(i==5):
            if(sliderMaxorMinPosition == "max"):
                verifyText(sliderTextboxObject, str(150))
            else:
                verifyText(sliderTextboxObject, str(50))  
        elif(i==10):
            if(sliderMaxorMinPosition == "max"):
                verifyText(sliderTextboxObject, str(90))
            else:
                verifyText(sliderTextboxObject, str(-90))    
        elif(i==9):
            if(sliderMaxorMinPosition == "max"):
                verifyText(sliderTextboxObject, "3.30")
            else:
                verifyText(sliderTextboxObject, "0.30") 
        elif(i==11):
            if(sliderMaxorMinPosition == "max"):    
                verifyText(sliderTextboxObject, str(150))
            else:
                verifyText(sliderTextboxObject, str(0))
        else:
            if(sliderMaxorMinPosition == "max"):    
                verifyText(sliderTextboxObject, str(150))
            else:
                verifyText(sliderTextboxObject, str(25))   

def verifyResetBrightnessFunctionality(sliderMaxorMinPosition):
    test.log("Verifying the reset brightness functionality of destination color tab for "+sliderMaxorMinPosition+" value")
    scrollListInsideTab("Color","vertical","up",260)
    resetBrightnessButton = {"container": destColorTab, "occurrence": 2, "text": "Reset", "type": "CustomText", "unnamed": 1, "visible": True}
    enableDestTab(colorTabDestinationOutputRectangle,resetAllButton)
    for i in range(1,len(findAllObjects(slidersInsideColorTab))+1,1):
        sliderObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i, "type": "ProgressBar", "visible": True}
        if not i==(len(findAllObjects(slidersInsideColorTab))):
            sliderNextObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i+1, "type": "ProgressBar", "visible": True}
            scrollTillObjVisible(sliderNextObject, "Color", "vertical", "down", 300)
        setSliderPosition(sliderObject, sliderMaxorMinPosition)
    scrollTillObjVisible(resetBrightnessButton, "Color", "vertical", "down", 220)
    click(resetBrightnessButton)
    scrollListInsideTab("Color", "vertical", "up", 220)
    for i in range(1,len(findAllObjects(slidersInsideColorTab))+1,1):
        sliderTextboxObject = {"container": destColorTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        scrollTillObjVisible(sliderTextboxObject, "Color", "vertical", "down", 220)
        mouseMove(sliderTextboxObject)
        if(i<5):
            if(sliderMaxorMinPosition == "max"):
                verifyText(sliderTextboxObject, str(150))
            else:
                if(i==1):
                    verifyText(sliderTextboxObject, str(50))
                else:
                    verifyText(sliderTextboxObject, str(25))
        elif(i==9):
            if(sliderMaxorMinPosition == "max"):
                verifyText(sliderTextboxObject, "3.30")
            else:
                verifyText(sliderTextboxObject, "0.30")
        elif(i==10):
            if(sliderMaxorMinPosition == "max"):
                verifyText(sliderTextboxObject, str(90))
            else:
                verifyText(sliderTextboxObject, str(-90))
        elif(i==11):
            if(sliderMaxorMinPosition == "max"):
                verifyText(sliderTextboxObject, str(150))
            else:
                verifyText(sliderTextboxObject, str(0))
        else:
            verifyText(sliderTextboxObject, str(100)) 

            
def clickPlusOrMinusButton(tabName, buttonType, numberOfTimestoBeClicked, occurrenceValue):
    modifiedContainer = {"container": mainWindowObj, "title": tabName, "type": "CustomTab", "unnamed": 1, "visible": True}
    plusButton = {"container": modifiedContainer, "id": "icon", "source": Wildcard("images/svgImages/plus.svg"),"occurrence": occurrenceValue, "type": "Image", "unnamed": 1, "visible": True}
    minusButton = {"container": modifiedContainer, "id": "icon", "source": Wildcard("images/svgImages/minus.svg"), "occurrence": occurrenceValue, "type": "Image", "unnamed": 1, "visible": True}

    for i in range(numberOfTimestoBeClicked):
        if(buttonType == "+"):
            scrollTillObjVisible(plusButton, tabName, "vertical", "down", 220)
            click(plusButton)
        elif(buttonType == "-"):
            scrollTillObjVisible(minusButton, tabName, "vertical", "down", 220)
            click(minusButton)

                
def verifyPlusMinusButtonAdjustmentValues(buttonType):
    test.log("Verifying the values from + and - buttons")
    scrollListInsideTab("Color","vertical","up",260)
    enableDestTab(colorTabDestinationOutputRectangle,resetAllButton)
    click(resetAllButton)
    verifyColorTabResttedValues()
    scrollListInsideTab("Color","vertical","up",260)
    for i in range(1,len(findAllObjects(slidersInsideColorTab))+1,1):
        sliderTextboxObject = {"container": destColorTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        if not i==(len(findAllObjects(slidersInsideColorTab))):
            sliderNextObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i+1, "type": "ProgressBar", "visible": True}
            scrollTillObjVisible(sliderNextObject, "Color", "vertical", "down", 300)
        if(buttonType == "-"):
            clickPlusOrMinusButton("Color", buttonType, 2,i+1)
            if(i==10):
                verifyText(sliderTextboxObject, str(-2))
            elif(i==9):
                verifyText(sliderTextboxObject, str(0.98))
            else:    
                verifyText(sliderTextboxObject, str(98))
        elif(buttonType == "+"): 
            clickPlusOrMinusButton("Color", buttonType, 3,i+1)
            if(i==10):
                verifyText(sliderTextboxObject, str(3))
            elif(i==9):
                verifyText(sliderTextboxObject, str(1.03))
            else:    
                verifyText(sliderTextboxObject, str(103))
        else:
            test.fail("Invalid button type \'"+buttonType+"\' , allowed values are \'+\' or \'-\'")  

                        
def verifyAdjustmentsUsingeditboxColor():
    test.log("Verifying adjustments using Edit Box")
    scrollListInsideTab("Color","vertical","up",260)
    enableDestTab(colorTabDestinationOutputRectangle,resetAllButton)
    click(resetAllButton) 
    verifyColorTabResttedValues()
    scrollListInsideTab("Color","vertical","up",120)
    for i in range(1,len(findAllObjects(slidersInsideColorTab))+1,1):
        sliderTextboxObject = {"container": destColorTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        if not i==(len(findAllObjects(slidersInsideColorTab))):
            sliderNextObject = {"container": destColorTab, "objectName": "objGrooveBar", "occurrence": i+1, "type": "ProgressBar", "visible": True}
            scrollTillObjVisible(sliderNextObject, "Color", "vertical", "down", 300)
        if(str(waitForObjectExists(sliderTextboxObject).text) == str(100)):
            click(sliderTextboxObject)
            updateText(editboxColor, str(50))
            verifyText(sliderTextboxObject, str(50))
        elif(str(waitForObjectExists(sliderTextboxObject).text) == str(0)):
            click(sliderTextboxObject)
            updateText(editboxColor, str(2))
            verifyText(sliderTextboxObject, str(2))
        elif(str(waitForObjectExists(sliderTextboxObject).text) == str(1)):
            click(sliderTextboxObject)
            updateText(editboxColor, str(3))
            verifyText(sliderTextboxObject, str(3))  

#####################################################################################################################
#Timing Tab Specific Verifications
#####################################################################################################################

allTabsParentWindow = {"container": mainWindowObj, "id": "headerRect", "type": "Rectangle", "unnamed": 1, "visible": True}
allTabsParentWindowCloseButton = {"container": mainWindowObj, "objectName": "objImg", "source": Wildcard("images/mainWnd/icon_16_close.png"), "type": "CustomImage", "visible": True}
barco_Inc_Event_Master_Toolset_Timing_CustomTab = {"container": mainWindowObj, "id": "objTimingTab", "title": "Timing", "type": "CustomTab", "unnamed": 1, "visible": True}
timingTab = {"container": tabBarObj, "text": "Timing", "type": "CustomText", "unnamed": 1, "visible": True}
fieldsInsideTimingTab ={"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "objectName": "objHeadingText", "type": "CustomText", "visible": True} 
slidersInsideTimingTab = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "objectName": "objGrooveBar", "type": "ProgressBar", "visible": True}
#####################################################################################################################

def verifyWindowDragging(windowObject):
    test.log("Verifying Dragging of Destination Window")
    drag(waitForObject(windowObject), -994, 0)
    if(waitForObjectExists(windowObject).parent.x < 10):
        test.log("Dragged Successfully")
    else:
        test.fail("Not Dragged Successfully")
    drag(waitForObjectExists(windowObject), 1031, 0)
    if(waitForObjectExists(windowObject).parent.x > 10):
        test.log("Dragged Successfully")
    else:
        test.fail("Not Dragged Successfully")


def verifycloseAndReopenWindow(windowObject, parentWindow):
    test.log("Verifying Closing and Reopening of Destination Window")
    click(windowObject)
    objectNotExist(parentWindow)
    selectScreenDestination(1,"list")
    objectExist(parentWindow)
    
    
def verifyFieldsInTimingTab():
    scrollListInsideTab("Timing","vertical","up",260)
    test.log("Verifying fields inside the Destination Window Timing Tab")
    click(timingTab)
    fields = ["H Total" , "H Front Porch", "H Active", "H Sync", "H Polarity", "V Total", "V Front Porch", "V Active", "V Sync", "V Rate", "V Polarity"]
    for i in fields:
        fieldName = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "text": i, "type": "CustomText", "visible": True}
        scrollTillObjVisible(fieldName, "Timing", "vertical", "down", 220)
        objectExist(fieldName)

        
def verifyPlusMinusButtonAdjustmentValuesOfTimingTab(buttonType):
    test.log("Verifying the values from + and - buttons from timing tab")
    scrollListInsideTab("Timing","vertical","down",260)
    
    for i in range(1,len(findAllObjects(slidersInsideTimingTab))+1,1):
        sliderTextboxObject = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        if(buttonType == "-"):
            clickPlusOrMinusButton("Timing", buttonType, 1,i+1)
        elif(buttonType == "+"): 
            clickPlusOrMinusButton("Timing", buttonType, 1,i+1)
        else:
            test.fail("Invalid button type \'"+buttonType+"\' , allowed values are \'+\' or \'-\'")  


def verifyPolarityRadioButtons():
    test.log("Verifying the H Polarity and V Polarity Radio buttons")    
    click(timingTab)
    scrollListInsideTab("Timing","vertical","down",260)
    polarityRadioButton = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "id": "objRadioButton", "type": "RadioButton", "unnamed": 1, "visible": True}
    for i in range (1,len(findAllObjects(polarityRadioButton))+1,1):
        radioBtn = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "id": "objRadioButton", "occurrence": i, "type": "RadioButton", "unnamed": 1, "visible": True}
        click(radioBtn)
        if(i==1):
            isRadioButtonChecked(radioBtn,True)
            radioBtn = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "id": "objRadioButton", "occurrence": i+1, "type": "RadioButton", "unnamed": 1, "visible": True}   
            isRadioButtonChecked(radioBtn,False)
        elif(i==2):
            isRadioButtonChecked(radioBtn,True)
            radioBtn = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "id": "objRadioButton", "occurrence": i-1, "type": "RadioButton", "unnamed": 1, "visible": True}   
            isRadioButtonChecked(radioBtn,False)
        elif(i==3):
            isRadioButtonChecked(radioBtn,True)
            radioBtn = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "id": "objRadioButton", "occurrence": i+1, "type": "RadioButton", "unnamed": 1, "visible": True}   
            isRadioButtonChecked(radioBtn,False)
        elif(i==4):
            isRadioButtonChecked(radioBtn,True)
            radioBtn = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "id": "objRadioButton", "occurrence": i-1, "type": "RadioButton", "unnamed": 1, "visible": True}   
            isRadioButtonChecked(radioBtn,False)
    
#####################################################################################################################
#Settings Tab Specific Verifications
#####################################################################################################################
settingTabCustomObj = {"container": mainWindowObj, "id": "objSettingTab", "title": "Settings", "type": "CustomTab", "unnamed": 1, "visible": True}
settingsTab = {"container": tabBarObj, "text": "Settings", "type": "CustomText", "unnamed": 1, "visible": True}
hdmiConnectSettingColorSampleBitDropdown = {"container": settingTabCustomObj, "id": "objEnabledGradRect", "occurrence": 3, "type": "Rectangle", "unnamed": 1, "visible": True}
colorSpaceDropdown = {"container": settingTabCustomObj, "id": "objEnabledGradRect", "occurrence": 4, "type": "Rectangle", "unnamed": 1, "visible": True}
colorimetryDropdown = {"container": settingTabCustomObj, "id": "objEnabledGradRect", "occurrence": 5, "type": "Rectangle", "unnamed": 1, "visible": True}
gammafxDropdown = {"container": settingTabCustomObj, "id": "objEnabledGradRect", "occurrence": 6, "type": "Rectangle", "unnamed": 1, "visible": True}
HDRMetaDataFileDropdown = {"container": settingTabCustomObj, "id": "objEnabledGradRect", "occurrence": 7, "type": "Rectangle", "unnamed": 1, "visible": True}
hdcpModetoggle = {"container": settingTabCustomObj, "objectName": "objToggleHdcpMode", "type": "CustomToggleButton", "visible": True}
layerExpansionDropdown = {"container": settingTabCustomObj, "id": "objEnabledGradRect", "occurrence": 8, "type": "Rectangle", "unnamed": 1, "visible": True}
settingsTabDestinationOutputRectangle = {"container": settingTabCustomObj,  "id": "objVirtualItem", "type": "Rectangle", "unnamed": 1, "visible": True}
addOutputRectandleInEditDestination = {"container": destTabInnerArea, "id": "addOuptutButton", "type": "Rectangle", "unnamed": 1, "visible": True}
addOutputApplyChangesButton = {"container": destTabInnerArea, "text": "Apply Changes", "type": "CustomText", "unnamed": 1, "visible": True}
autoConfigureOutputFormatButton = {"container": settingTabCustomObj, "text": "Auto Configure Output Format", "type": "CustomText", "unnamed": 1, "visible": True}
saveEDIDasFileButton = {"container": settingTabCustomObj, "text": "Save EDID as File", "type": "CustomText", "unnamed": 1, "visible": True}
slidersInsideSettingsTab = {"container": settingTabCustomObj, "objectName": "objGrooveBar", "type": "ProgressBar", "visible": True}
settingsTabeditBox = {"container": settingTabCustomObj, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
unlockButton = {"container": settingTabCustomObj, "id": "icon", "source": Wildcard("images/svgImages/unlock.svg"), "type": "Image", "unnamed": 1, "visible": True}
lockButton = {"container": settingTabCustomObj, "id": "icon", "source": Wildcard("images/svgImages/lock.svg"), "type": "Image", "unnamed": 1, "visible": True}

#####################################################################################################################

def renameDestinationScreen(newDestinationName, destinationNumber):
    test.log("Renaming Destination to "+newDestinationName)   
    screenDestination = {"container": destTabInnerArea, "objectName": "objDisplayedText", "occurrence": destinationNumber, "type": "CustomText", "visible": True}
    editedScreenDestination = {"backgroundcolor": "#2d2d2d", "container": destTabInnerArea, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    updatedDestination = {"container": destTabInnerArea, "objectName": "objDisplayedText", "text": newDestinationName, "type": "CustomText", "visible": True}
    doubleClick(screenDestination)
    waitForObjectExists(editedScreenDestination)
    updateText(waitForObject(editedScreenDestination), newDestinationName)
    objectExist(updatedDestination)  

def verifyDestinationScreenNameOnOpenedTab(expectedDestinationName):
    test.log("Checking the destination to be "+expectedDestinationName)
    destinationNameOnTopOfAllTabs = {"container": mainWindowObj, "text": expectedDestinationName, "type": "CustomText", "unnamed": 1, "visible": True}
    objectExist(destinationNameOnTopOfAllTabs)
      
def addOutputsToDestination(numberOfOutputs,destinationNumber=None):
    test.log("Adding outputs to destination")   
    if not object.exists(addOutputApplyChangesButton):
        if(destinationNumber):
            destinationScreenPropertiesEditButton = {"container": destTabInnerArea, "id": "icon", "occurrence": destinationNumber, "source": Wildcard("images/svgImages/edit.svg"), "type": "Image", "unnamed": 1, "visible": True}
            click(destinationScreenPropertiesEditButton)
            deleteExistingOutputs()
            isObjectDisable(addOutputApplyChangesButton)
    k=0
    for i in range(numberOfOutputs):
        k+=1
        newCreatedOutputRectange = {"container": destTabInnerArea, "id": "destOpRect", "occurrence": i+1, "type": "Rectangle", "unnamed": 1, "visible": True}
        opCard = {"container": barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView, "id": "objSlotDelegateItem", "occurrence": 4, "type": "SlotDelegate", "unnamed": 1, "visible": True}
        outputConnector = {"container": opCard, "objectName": "objConnSelectionRect", "occurrence":k, "type": "Rectangle", "visible": True}
        click(addOutputRectandleInEditDestination)
        click(newCreatedOutputRectange)
        click(outputConnector)
        if(destinationNumber):
            isObjectEnable(addOutputApplyChangesButton)    
    if(destinationNumber):
        click(addOutputApplyChangesButton)
        click(addOutputCancelButton)

def verifyNumberOfOutputsOnSettingsTab(destinationNumber, numberOfOutputs):
    test.log("Verifying that the added outputs are reflected on setting tab")
    screenDestination = {"container": destTabInnerArea, "objectName": "objDisplayedText", "occurrence": destinationNumber, "type": "CustomText", "visible": True}
    numberOfOutputsText = {"container": settingTabCustomObj, "text": 0, "type": "CustomText", "unnamed": 1, "visible": True}
    destinationScreenPropertiesEditButton = {"container": destTabInnerArea, "id": "icon", "occurrence": destinationNumber, "source": Wildcard("images/svgImages/edit.svg"), "type": "Image", "unnamed": 1, "visible": True}
    dimesionsHvalue = {"container": settingTabCustomObj, "text": 0, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}
    
    click(destinationScreenPropertiesEditButton)
    deleteExistingOutputs()
    click(screenDestination)
    click(settingsTab)
    objectExist(numberOfOutputsText)
    objectExist(dimesionsHvalue)
    
    addOutputsToDestination(numberOfOutputs,destinationNumber)
    numberOfOutputsText = {"container": settingTabCustomObj, "text": numberOfOutputs, "type": "CustomText", "unnamed": 1, "visible": True}
    dimesionsHvalue = {"container": settingTabCustomObj, "text": numberOfOutputs, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}
    click(screenDestination)
    click(settingsTab)
    objectExist(numberOfOutputsText)
    objectExist(dimesionsHvalue)
    
def verifySettingTabAreaOfInterest(): 
    test.log("Verifying the extreme possible slider values of Area of Interest in settings Tab")
    enableDestTab(settingsTabDestinationOutputRectangle, hdmiConnectSettingColorSampleBitDropdown)
    scrollListInsideTab("Settings","vertical","up",260)
    objectExist(lockButton)
    for i in range(1,len(findAllObjects(slidersInsideSettingsTab))+1,1):
        sliderObject = {"container": settingTabCustomObj, "objectName": "objGrooveBar", "occurrence": i, "type": "ProgressBar", "visible": True}
        sliderTextboxObject = {"container": settingTabCustomObj, "objectName": "objDisplayedText", "occurrence": i+2, "type": "CustomText", "visible": True}
        scrollTillObjVisible(sliderObject, "Color", "vertical", "down", 220)
        if(i==1):
            setSliderPosition(sliderObject, "max")
            verifyText(sliderTextboxObject, str(3840))
        else:
            setSliderPosition(sliderObject, "max")
            verifyText(sliderTextboxObject, str(2160))
               
        setSliderPosition(sliderObject, "min")
        verifyText(sliderTextboxObject, str(1))
    
    click(lockButton)
    objectExist(unlockButton)
    
def verifyPlusMinusButtonAdjustmentValuesOfSettingsTab(buttonType):
    test.log("Verifying the values from + and - buttons from timing tab")
    scrollListInsideTab("Settings","vertical","up",260)
    
    for i in range(1,len(findAllObjects(slidersInsideSettingsTab))+1,1):
        if(buttonType == "-"):
            clickPlusOrMinusButton("Settings", buttonType, 1,i+1)
        elif(buttonType == "+"): 
            clickPlusOrMinusButton("Settings", buttonType, 1,i+1)
        else:
            test.fail("Invalid button type \'"+buttonType+"\' , allowed values are \'+\' or \'-\'")
            
def verifyColorSampleBitComboboxValues():
    scrollListInsideTab("Settings","vertical","up",260)
    enableDestTab(settingsTabDestinationOutputRectangle, hdmiConnectSettingColorSampleBitDropdown)
    scrollTillObjVisible(hdmiConnectSettingColorSampleBitDropdown, "Settings", "vertical", "down", 220)
    click(hdmiConnectSettingColorSampleBitDropdown)
    fields = ["RGB/4:4:4/4:2:2", "YCbCr/4:4:4/4:2:2", "YCbCr/4:2:2/Invalid", "YCbCr/4:2:0/4:2:2"]
    for i in fields:
        fieldName = {"container": objScrollView_ScrollView, "text": i, "type": "CustomText", "unnamed": 1, "visible": True}
        mouseMove(fieldName)
        objectExist(fieldName)
    click(hdmiConnectSettingColorSampleBitDropdown)    

def verifySpaceValues():
    scrollListInsideTab("Settings","vertical","up",260)
    enableDestTab(settingsTabDestinationOutputRectangle, hdmiConnectSettingColorSampleBitDropdown)
    scrollTillObjVisible(colorSpaceDropdown, "Settings", "vertical", "down", 220)
    click(colorSpaceDropdown)
    fields = ["RGB, Full Range", "RGB, Reduced Range", "SMPTE, Full Range", "SMPTE, Reduced Range"]
    for i in fields:
        fieldName = {"container": objScrollView_ScrollView, "text": i, "type": "CustomText", "unnamed": 1, "visible": True}
        mouseMove(fieldName)
        objectExist(fieldName)
    click(colorSpaceDropdown)
        
def verifyColorimetryValues():
    scrollListInsideTab("Settings","vertical","up",260)
    enableDestTab(settingsTabDestinationOutputRectangle, hdmiConnectSettingColorSampleBitDropdown)
    scrollTillObjVisible(colorimetryDropdown, "Settings", "vertical", "down", 220)
    click(colorimetryDropdown)
    fields = ["BT.601", "BT.709", "BT.2020", "DCI-P3"]
    for i in fields:
        fieldName = {"container": objScrollView_ScrollView, "text": i, "type": "CustomText", "unnamed": 1, "visible": True}
        mouseMove(fieldName)
        objectExist(fieldName)
    click(colorimetryDropdown)
        
def verifyGammaFxValues():
    scrollListInsideTab("Settings","vertical","up",260)
    enableDestTab(settingsTabDestinationOutputRectangle, hdmiConnectSettingColorSampleBitDropdown)
    scrollTillObjVisible(gammafxDropdown, "Settings", "vertical", "down", 220)
    click(gammafxDropdown)
    fields = ["SDR","HLG","PQ/HDR10"]
    for i in fields:
        fieldName = {"container": objScrollView_ScrollView, "text": i, "type": "CustomText", "unnamed": 1, "visible": True}
        mouseMove(fieldName)
        objectExist(fieldName)
    click(gammafxDropdown)
    
def verifyHDRMetadataFileValues():
    scrollListInsideTab("Settings","vertical","up",260)
    enableDestTab(settingsTabDestinationOutputRectangle, hdmiConnectSettingColorSampleBitDropdown)
    scrollTillObjVisible(HDRMetaDataFileDropdown, "Settings", "vertical", "down", 220)
    click(HDRMetaDataFileDropdown)
    fields = ["None"]
    for i in fields:
        fieldName = {"container": objScrollView_ScrollView, "text": i, "type": "CustomText", "unnamed": 1, "visible": True}
        mouseMove(fieldName)
        objectExist(fieldName)
    click(HDRMetaDataFileDropdown)
    
def verifyHDCPModeToggle():
    scrollListInsideTab("Settings","vertical","up",260)
    scrollTillObjVisible(layerExpansionDropdown, "Settings", "vertical", "down", 220)
    if not (waitForObjectExists(hdcpModetoggle).m_bEnabled == False):
        click(hdcpModetoggle)
    test.verify(waitForObjectExists(hdcpModetoggle).m_bEnabled == False)
    click(hdcpModetoggle)
    test.verify(waitForObjectExists(hdcpModetoggle).m_bEnabled == True)
    
def verifyLayerExpansionValues():
    scrollListInsideTab("Settings","vertical","up",260)
    enableDestTab(settingsTabDestinationOutputRectangle, hdmiConnectSettingColorSampleBitDropdown)
    scrollTillObjVisible(layerExpansionDropdown, "Settings", "vertical", "down", 220)
    click(layerExpansionDropdown)
    fields = ["1","2"]
    for i in fields:
        fieldName = {"container": objScrollView_ScrollView, "text": i, "type": "CustomText", "unnamed": 1, "visible": True}
        mouseMove(fieldName)
        objectExist(fieldName)
    click(layerExpansionDropdown)
    
def setDimensions(Hvalue,Vvalue):
    for i in range(1,3,1):
        textbox = {"container": settingTabCustomObj, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        click(textbox)
        if(i==1):
            updateText(settingsTabeditBox,Hvalue)
        elif(i==2):
            updateText(settingsTabeditBox,Vvalue)  

#####################################################################################################################
#Wide Tab Specific Verifications
#####################################################################################################################
wideTab = {"container": tabBarObj, "text": "Wide", "type": "CustomText", "unnamed": 1, "visible": True}
wideTabFieldsParent = {"container": mainWindowObj, "id": "objWideTab", "title": "Wide", "type": "CustomTab", "unnamed": 1, "visible": True}
wideTabDestinationOutputRectangle = {"container": wideTabFieldsParent,  "id": "objVirtualItem", "type": "Rectangle", "unnamed": 1, "visible": True}
dataDoubleFirstTextBox = {"container": wideTabFieldsParent, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}
dataDoubleRadioButton = {"container": wideTabFieldsParent, "id": "objRadioButton", "type": "RadioButton", "unnamed": 1, "visible": True}
slidersInsideWideTab = {"container": wideTabFieldsParent, "objectName": "objGrooveBar", "type": "ProgressBar", "visible": True}
wideTabUnlockButton = {"container": wideTabFieldsParent, "id": "objIconImage", "source": Wildcard("images/generalImages/g22_unlock16x16.png"), "type": "Image", "unnamed": 1, "visible": True}
wideTabLockButton = {"container": wideTabFieldsParent, "id": "objIconImage", "source": Wildcard("images/generalImages/g22_lock16x16.png"), "type": "Image", "unnamed": 1, "visible": True}
wideTabCustomScrollView = {"container": mainWindowObj, "id": "objWideScreenScrollView", "type": "CustomScrollView", "unnamed": 1, "visible": True}
featheringToggle = {"container": wideTabFieldsParent, "objectName": "objToggleFeathering", "type": "CustomToggleButton", "visible": True}
featheringRadioBtnParent = {"container": wideTabFieldsParent, "id": "objFeatheringCheckBox", "type": "CustomRadioButton", "unnamed": 1, "visible": True}
featheringRadioBtn = {"container": featheringRadioBtnParent, "id": "objRadioButton", "type": "RadioButton", "unnamed": 1, "visible": True}
wideTabZoomBtn = {"container": mainWindowObj, "id": "objIconImage", "source": Wildcard("images/svgImages/zoom.svg"), "type": "Image", "unnamed": 1, "visible": True}
wideScreenWindow = {"container": mainWindowObj, "id": "wideScreenWindowRoot", "type": "Item", "unnamed": 1, "visible": True}
featheringBtns = {"container": wideTabFieldsParent, "id": "objFeatherButton", "type": "CustomBorderIconButton", "unnamed": 1, "visible": True}
featheringResetBtn = {"container": wideTabFieldsParent, "text": "Reset", "type": "CustomText", "unnamed": 1, "visible": True}
#####################################################################################################################

def verifyDataDoubleAndFeatheringRadioButtons():
    test.log("Verifying the Data Double and Feathering Radio buttons")    
    click(wideTab)
    radioButtons = {"container": wideTabFieldsParent, "id": "objRadioButton", "type": "RadioButton", "unnamed": 1, "visible": True}
    test.log(str(len(findAllObjects(radioButtons))))
    for i in range (1,len(findAllObjects(radioButtons))+1,1):
        radioBtn = {"container": wideTabFieldsParent, "id": "objRadioButton", "occurrence": i, "type": "RadioButton", "unnamed": 1, "visible": True}
        click(radioBtn)
        if(i==1):
            isRadioButtonChecked(radioBtn, True)
            radioBtn = {"container": wideTabFieldsParent, "id": "objRadioButton", "occurrence": i+1, "type": "RadioButton", "unnamed": 1, "visible": True}   
            isRadioButtonChecked(radioBtn, False)
            
        elif(i==2):
            isRadioButtonChecked(radioBtn, True)
            radioBtn = {"container": wideTabFieldsParent, "id": "objRadioButton", "occurrence": i-1, "type": "RadioButton", "unnamed": 1, "visible": True}   
            isRadioButtonChecked(radioBtn, False)
        

def verifyFieldsInDataDoubleWideTab():
    test.log("Verifying fields inside the Destination Window Timing Tab")
    click(wideTab)
    click(dataDoubleRadioButton)
    fields = ["Area of interest", "H Size", "V Size" ,"H Position", "V Position", "H Overlap", "H Offset", "V Overlap", "V Offset"]
    for i in fields:
        if(i=="Area of interest"):
            fieldName = {"container": wideTabFieldsParent, "text": i, "type": "CustomText", "unnamed": 1, "visible": True}
        else:
            fieldName = {"container": wideTabFieldsParent, "text": i, "objectName": "objHeadingText", "type": "CustomText", "visible": True}
        mouseMove(fieldName)
        objectExist(fieldName)

def verifyPlusMinusButtonAdjustmentValuesOfWideTab(buttonType):
    test.log("Verifying the values from + and - buttons from wide tab")
    click(wideTab)
    click(dataDoubleRadioButton)
    for i in range(1,len(findAllObjects(slidersInsideWideTab))+1,1):
        if(buttonType == "-"):
            clickPlusOrMinusButton("Wide", buttonType, 1,i)
        elif(buttonType == "+"): 
            clickPlusOrMinusButton("Wide", buttonType, 1,i)
        else:
            test.fail("Invalid button type \'"+buttonType+"\' , allowed values are \'+\' or \'-\'")
            
def verifyLockAndUnlockButton():
    test.log("Verifying the lock-unlock button from wide tab")
    click(wideTab)
    click(dataDoubleRadioButton)
    objectExist(wideTabLockButton)
    click(wideTabLockButton)
    objectExist(wideTabUnlockButton) 
    
def verifyFeatheringSlider():
    test.log("Verifying feathering slider values")
    for i in range(1,len(findAllObjects(slidersInsideWideTab))+1,1):
        sliderObject = {"container": wideTabFieldsParent, "objectName": "objGrooveBar", "occurrence": i, "type": "ProgressBar", "visible": True}
        sliderTextboxObject = {"container": wideTabFieldsParent, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        #Slider names are as follows on the basis of indexing:
                #Feathering Gamma ====> 1
                #Feathering Width ========> 2         
        if(i==1):
            setSliderPosition(sliderObject, "max")
            verifyText(sliderTextboxObject, str(5))
            setSliderPosition(sliderObject, "min")
            verifyText(sliderTextboxObject, str(1))
        elif(i==2):
            setSliderPosition(sliderObject, "max")
            verifyText(sliderTextboxObject, str(1920))
            setSliderPosition(sliderObject, "min")
            verifyText(sliderTextboxObject, str(0))
                    
def verifyWideSubWindow():
    test.log("Verifying the sub window wide tab")
    click(wideTabZoomBtn)
    objectExist(wideScreenWindow)
    
def verifyFeatheringUpdates():
    test.log("Verifying all available featherings")
    outputTopLeft = {"container": wideTabCustomScrollView, "occurrence": 1, "type": "DestWideFeatheringDelegate", "unnamed": 1, "visible": True}
    aoioutputTopLeft = {"container": wideTabFieldsParent, "occurrence": 1, "type": "DestWideFeatheringDelegate", "unnamed": 1, "visible": True}
    outputBottomLeft = {"container": wideTabCustomScrollView, "occurrence": 2, "type": "DestWideFeatheringDelegate", "unnamed": 1, "visible": True}
    aoioutputBottomLeft = {"container": wideTabFieldsParent, "occurrence": 2, "type": "DestWideFeatheringDelegate", "unnamed": 1, "visible": True}
    outputTopRight = {"container": wideTabCustomScrollView, "occurrence": 3, "type": "DestWideFeatheringDelegate", "unnamed": 1, "visible": True}
    aoioutputTopRight = {"container": wideTabFieldsParent, "occurrence": 3, "type": "DestWideFeatheringDelegate", "unnamed": 1, "visible": True}
    outputBottomRight = {"container": wideTabCustomScrollView, "occurrence": 4, "type": "DestWideFeatheringDelegate", "unnamed": 1, "visible": True}
    aoioutputBottomRight = {"container": wideTabFieldsParent, "occurrence": 4, "type": "DestWideFeatheringDelegate", "unnamed": 1, "visible": True}
    
    objectExist(featheringBtns)
    for i in findAllObjects(featheringBtns):
        featheringType = str(i.refImage.source.path)
        if(i.bSelected == False):
            click(i)
        if "Outline" in featheringType:
            verifyOutline([outputTopLeft,aoioutputTopLeft],["True","False","False","True"])
            verifyOutline([outputBottomLeft,aoioutputBottomLeft],["False","False","True","True"])
            verifyOutline([outputTopRight,aoioutputTopRight],["True","True","False","False"])
            verifyOutline([outputBottomRight,aoioutputBottomRight],["False","True","True","False"])
              
        elif "Inside" in featheringType:
            verifyOutline([outputTopLeft,aoioutputTopLeft],["False","True","True","False"])
            verifyOutline([outputBottomLeft,aoioutputBottomLeft],["True","True","False","False"])
            verifyOutline([outputTopRight,aoioutputTopRight],["False","False","True","True"])
            verifyOutline([outputBottomRight,aoioutputBottomRight],["True","False","False","True"])
              
          
        elif "TopEdge" in featheringType:
            verifyOutline([outputTopLeft,aoioutputTopLeft],["True","False","False","False"])
            verifyOutline([outputBottomLeft,aoioutputBottomLeft],["False","False","False","False"])
            verifyOutline([outputTopRight,aoioutputTopRight],["True","False","False","False"])
            verifyOutline([outputBottomRight,aoioutputBottomRight],["False","False","False","False"])
  
          
        elif "bottomEdge" in featheringType:
            verifyOutline([outputTopLeft,aoioutputTopLeft],["False","False","False","False"])
            verifyOutline([outputBottomLeft,aoioutputBottomLeft],["False","False","True","False"])
            verifyOutline([outputTopRight,aoioutputTopRight],["False","False","False","False"])
            verifyOutline([outputBottomRight,aoioutputBottomRight],["False","False","True","False"])            
          
        elif "LeftEdge" in featheringType:
            verifyOutline([outputTopLeft,aoioutputTopLeft],["False","False","False","True"])
            verifyOutline([outputBottomLeft,aoioutputBottomLeft],["False","False","False","True"])
            verifyOutline([outputTopRight,aoioutputTopRight],["False","False","False","False"])
            verifyOutline([outputBottomRight,aoioutputBottomRight],["False","False","False","False"])           
               
        elif "RightEdge" in featheringType:
            verifyOutline([outputTopLeft,aoioutputTopLeft],["False","False","False","False"])
            verifyOutline([outputBottomLeft,aoioutputBottomLeft],["False","False","False","False"])
            verifyOutline([outputTopRight,aoioutputTopRight],["False","True","False","False"])
            verifyOutline([outputBottomRight,aoioutputBottomRight],["False","True","False","False"])             
               
        elif "VerticleMiddle" in featheringType:
            verifyOutline([outputTopLeft,aoioutputTopLeft],["False","True","False","False"])
            verifyOutline([outputBottomLeft,aoioutputBottomLeft],["False","True","False","False"])
            verifyOutline([outputTopRight,aoioutputTopRight],["False","False","False","True"])
            verifyOutline([outputBottomRight,aoioutputBottomRight],["False","False","False","True"])             
               
        elif "HorizontalMiddle" in featheringType:
            verifyOutline([outputTopLeft,aoioutputTopLeft],["False","False","True","False"])
            verifyOutline([outputBottomLeft,aoioutputBottomLeft],["True","False","False","False"])
            verifyOutline([outputTopRight,aoioutputTopRight],["False","False","True","False"])
            verifyOutline([outputBottomRight,aoioutputBottomRight],["True","False","False","False"])

def verifyOutline(obj,value):
        test.log("Verifying the outline update")
        for i in obj:
            compareTwoTexts(str(waitForObjectExists(i).objTopFeather.selected),value[0])
            compareTwoTexts(str(waitForObjectExists(i).objRightFeather.selected),value[1])
            compareTwoTexts(str(waitForObjectExists(i).objBottomFeather.selected),value[2])
            compareTwoTexts(str(waitForObjectExists(i).objLeftFeather.selected),value[3])
            
            
###########################################################
########################COMMON#############################    
###########################################################

def addOutputUsingDragDrop(destinationNumber,numberOfOutputs):
    test.log("Adding output using drag drop of connector")
    destinationScreenPropertiesEditButton = {"container": destTabInnerArea, "id": "icon", "occurrence": destinationNumber, "source": Wildcard("images/svgImages/edit.svg"), "type": "Image", "unnamed": 1, "visible": True}
    click(destinationScreenPropertiesEditButton)
    deleteExistingOutputs()
    k=0
    for i in range(numberOfOutputs):
        k+=1
        newCreatedOutputRectange = {"container": destTabInnerArea, "id": "destOpRect", "occurrence": i+1, "type": "Rectangle", "unnamed": 1, "visible": True}
        opCard = {"container": barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView, "id": "objSlotDelegateItem", "occurrence": 4, "type": "SlotDelegate", "unnamed": 1, "visible": True}
        outputConnector = {"container": opCard, "objectName": "objConnSelectionRect", "occurrence":k, "type": "Rectangle", "visible": True}
        click(outputConnector)
        dragAndDropConnector(outputConnector,addOutputRectandleInEditDestination,newCreatedOutputRectange)
        isObjectEnable(addOutputApplyChangesButton)
    click(addOutputApplyChangesButton)
    click(addOutputCancelButton)

def moveMouseBackAndForth(obj):
    # Moving mouse back and forth to ensure selection
    move_width = 20
    for i in range(move_width):
        snooze(0.05)
        mouseMove(waitForObject(obj), 5 + i, 10)
    for i in range(move_width, -1, -1):
        snooze(0.05)
        mouseMove(waitForObject(obj), 5 + i, 10)
    
def dragAndDropConnector(obj, dropLoc, droppedObj):  
    test.log("Performing drag-drop of Connector")
    mouseMove(waitForObject(obj), 5, 5)
    mousePress(waitForObject(obj), 5, 5, MouseButton.LeftButton)
    snooze(0.25)
    moveMouseBackAndForth(obj)            
    mouseMove(waitForObject(dropLoc), 5, 5)
    moveMouseBackAndForth(dropLoc)   
    mouseRelease(waitForObject(dropLoc), MouseButton.LeftButton) 
    if(len(str(droppedObj)) != 0):
        i = 0
        while(i < 11):
            i += 1
            snooze(0.25)
            if(object.exists(droppedObj)):
                test.log("Connector dragged successfully")
                break
        if(i >= 11):
            test.fail("Unable to drag Connector")
            
# def verifyDragAndPlusCombinedOutputAddtion(numberOfOutputs):
#     newCreatedOutputRectange = {"container": destTabInnerArea, "id": "destOpRect", "occurrence": i+1, "type": "Rectangle", "unnamed": 1, "visible": True}
#     opCard = {"container": barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView, "id": "objSlotDelegateItem", "occurrence": 4, "type": "SlotDelegate", "unnamed": 1, "visible": True}
#     outputConnector = {"container": opCard, "objectName": "objConnSelectionRect", "occurrence":k, "type": "Rectangle", "visible": True}
#     click(outputConnector)
#     dragAndDropConnector(outputConnector,addOutputRectandleInEditDestination,newCreatedOutputRectange)
#     isObjectEnable(addOutputApplyChangesButton)
    
def editDestination(destinationNumber):
    test.log("Editing destination")
    destinationScreenPropertiesEditButton = {"container": destTabInnerArea, "id": "icon", "occurrence": destinationNumber, "source": Wildcard("images/svgImages/edit.svg"), "type": "Image", "unnamed": 1, "visible": True}
    click(destinationScreenPropertiesEditButton)
    objectExist(addOutputApplyChangesButton)

def setTotalHortzontalVertical(HValue,VValue):
    test.log("Setting up total horizontal and total vertical value")
    textbox = {"container": destTabInnerArea, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    click(totalHorizontalObj)
    updateText(textbox,HValue)
    click(totalVerticalObj)
    updateText(textbox,VValue)
  

def setOutputResolution(resolution):
    test.log("Setting up resolution")
    o_QQuickWindowQmlImpl = {"type": "QQuickWindowQmlImpl", "unnamed": 1, "visible": True}
    searchBoxObj = {"container": o_QQuickWindowQmlImpl, "id": "objSearchRect", "type": "Rectangle", "unnamed": 1, "visible": True}
    searchEditBox = {"container": o_QQuickWindowQmlImpl, "echoMode": 0, "objectName": "objFormatComboBoxSB", "type": "TextInput", "visible": True}
    updatedResolution = {"container": destTabInnerArea, "text": Wildcard(resolution), "type": "CustomText", "unnamed": 1, "visible": True}
    click(outputResolutionObj)
    objectExist(searchBoxObj)
    click(searchBoxObj)
    updateText(searchEditBox,resolution)
    waitForObjectExists(updatedResolution)
     
def verifyNumberOfOutputs(expectedOutputs):
    test.log("Verifying the number of outputs")
    compareTwoTexts(str(expectedOutputs),str(len(findAllObjects(outputRectange))))
    isObjectEnable(addOutputApplyChangesButton)
    

def verifyNumOfOpOnSystemWindow(expectedOutputs):
    firstDestCardOutputs = {"container": mainWindowObj, "text": "Outputs: "+expectedOutputs, "type": "CustomText", "unnamed": 1, "visible": True}
    waitForObjectExists(firstDestCardOutputs)
    
def getDisplayedResolutions():
    test.log("Getting displayed outputs resolution list")
    displayedResolutions = {"container": objScrollView_ScrollView, "id": "objDropDownRect", "type": "Rectangle", "unnamed": 1, "visible": True}
    click(outputResolutionObj)
    resolution = []
    for i in findAllObjects(displayedResolutions):
        resolution.append(i.m_refDropText)
    return resolution
    
def selectDisplayType(displayType):
    test.log("Selecting display type for the destination")
    LED = {"container": destTabInnerArea, "m_refText":"LED", "type": "CustomRadioButton", "unnamed": 1, "visible": True}
    projection = {"container": destTabInnerArea, "m_refText":"Projection", "type": "CustomRadioButton", "unnamed": 1, "visible": True}
    LCD = {"container": destTabInnerArea, "m_refText":"LCD", "type": "CustomRadioButton", "unnamed": 1, "visible": True}
    if(displayType.lower()=='led'):
        radioBtn = {"container": LED, "id": "objRadioButton", "type": "RadioButton", "unnamed": 1, "visible": True}
        click(radioBtn)
        test.verify(waitForObjectExists(LED).checked == True, 'LED display selected')
        test.verify(waitForObjectExists(projection).checked == False, 'Projection display not selected')
        test.verify(waitForObjectExists(LCD).checked == False, 'LCD display not selected')
    elif(displayType.lower()=='projection'):
        radioBtn = {"container": projection, "id": "objRadioButton", "type": "RadioButton", "unnamed": 1, "visible": True}
        click(radioBtn)
        test.verify(waitForObjectExists(LED).checked == False, 'LED display not selected')
        test.verify(waitForObjectExists(projection).checked == True, 'Projection display selected')
        test.verify(waitForObjectExists(LCD).checked == False, 'LED display not selected')
    elif(displayType.lower()=='lcd'):
        radioBtn = {"container": LCD, "id": "objRadioButton", "type": "RadioButton", "unnamed": 1, "visible": True}
        click(radioBtn)
        test.verify(waitForObjectExists(LED).checked == False, 'LED display not selected')
        test.verify(waitForObjectExists(projection).checked == False, 'Projection display not selected')
        test.verify(waitForObjectExists(LCD).checked == True, 'LED display selected')
    else:
        test.fail('Display type value is not valid')
        
def selectRotation(rotation):
    test.log("Selecting destination rotation")
    if(rotation == 0 or rotation ==90 or rotation == 180 or rotation == 270):
        rotationBtn = {"container": destTabInnerArea, "id": "rotateButton"+str(rotation), "type": "CustomBorderIconButton", "unnamed": 1, "visible": True}
        click(rotationBtn)
        test.verify(waitForObjectExists(rotationBtn).bSelected == True, 'Rotation selected successfully')
    else:
        test.fail('Rotation value is not valid')
    