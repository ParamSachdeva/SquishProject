from objectmaphelper import *

barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_tabbar_TabBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "tabbar", "occurrence": 3, "type": "TabBar", "visible": True}
barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objCustomFormatTab", "title": "Custom Format", "type": "CustomTab", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_objScrollCustomFormatAdjustment_CustomScrollView = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objScrollCustomFormatAdjustment", "type": "CustomScrollView", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objScrollView", "type": "CustomScrollView", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Input_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objCustomIpTab", "title": "Input", "type": "CustomTab", "unnamed": 1, "visible": True}

barco_Inc_Event_Master_Toolset_EDID_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objEdidTab", "title": "EDID", "type": "CustomTab", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Destination_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objCustomDestTab", "title": "Destination", "type": "CustomTab", "unnamed": 1, "visible": True}


customTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "Custom Format", "type": "CustomText", "unnamed": 1, "visible": True}
customFile = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
customFileMessage = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "text": "There is no custom format file available", "type": "CustomText", "unnamed": 1, "visible": True}   
customDeleteBtn = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "text": "Delete", "type": "CustomText", "unnamed": 1, "visible": True}
customCancelBtn = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "text": "Cancel", "type": "CustomText", "unnamed": 1, "visible": True}
customScroll = {"container": barco_Inc_Event_Master_Toolset_objScrollCustomFormatAdjustment_CustomScrollView, "id": "vscrollbar", "type": "ScrollBar", "unnamed": 1, "visible": True}

ipRightTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "occurrence": 2, "type": "Rectangle", "unnamed": 1, "visible": True}
destRightTab ={"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "Destination", "type": "CustomText", "unnamed": 1, "visible": True}

connector_0_1_0 = {"container": barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView, "objectName": "objConnSelectionRect", "occurrence": 5, "type": "Rectangle", "visible": True}


def addCustomFormat(noOfFormats):
    test.log("Inside function- addCustomFormat()")
    plusCustomButton = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "id": "icon", "source": Wildcard("/images/svgImages/plus.svg"), "type": "Image", "unnamed": 1, "visible": True}
    click(customTab)
    for noOfFormat in range(noOfFormats):
        click(plusCustomButton);
        test.log("Clicked- add custom button")
        verifyStatusBar("Custom Format is saved by the name: CustomFormat " + str(1+noOfFormat));wait(1)
    objectNotExist(customFileMessage)   
    
    
def customFileListView():
    test.log("Inside function- customFileListView()")
    customFile = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    customFileListView = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "id": "objDropDownDelegate", "type": "CustomListViewDropDownDelegate", "unnamed": 1, "visible": True}
    listView = (bool(waitForObject(customFileListView).m_refIsSelected))    
    click(customTab)
    if(listView == False):
        click(customFile)
    
    
def verifyCustomFile(customFileName):
    test.log("Inside function- verifyCustomFile()")  
    customName = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "text": customFileName ,"objectName": "objDisplayedText", "type": "CustomText", "visible": True}    
    customFileListView()
    
    objectExist(customName)
    
    
def deleteCustomFormat(btnType):
    test.log("Inside function- deleteCustomFormat()")
    delBtnEnable = bool(waitForObject(customDeleteBtn).parent.enabled)
    delete = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "text": "Delete", "type": "CustomText", "unnamed": 1, "visible": True}
    selectCustomFormat = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}    
    if (delBtnEnable == False):
        customFileListView()
        click(selectCustomFormat)       
        test.compare(bool(waitForObject(customDeleteBtn).parent.enabled), True) 
        click(delete)  
        click(btnType)  
    else:          
        test.fail("Test fail- check custom format list", "There is no custom format file available")


def renameCustomFormat(actualName, rename):   
    test.log("Inside function- renameCustomFormat()")
    existingCustomFormatName = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "text": actualName,"objectName": "objDisplayedText", "type": "CustomText", "visible": True}  
    modifiedCustomFormatName = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "text": rename, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}  
    typeCustomName = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    doubleClick(existingCustomFormatName);snooze(0.25);
    #for n in range(15):
    updateText(typeCustomName, "<Backspace>");snooze(0.25);
    updateText(typeCustomName,rename)
    #updateText(typeCustomName,"<Return>");snooze(0.25);   
    verifyText(modifiedCustomFormatName, rename)
    
def selectCustomFormat(name):
    test.log("Inside function- selectCustomFormat()")
    customFormatName = {"container": barco_Inc_Event_Master_Toolset_Custom_Format_CustomTab, "text": ""+name+"","objectName": "objDisplayedText", "type": "CustomText", "visible": True}  
    customFileListView()
    click(customFormatName)
    
    
def verifyCustomAdjustName(name):
    test.log("Inside function- verifyCustomAdjustName()")    
    selectCustomFormat(name)
    customAdjustName = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": name, "type": "CustomText", "unnamed": 1, "visible": True}
    textMatch(name, customAdjustName)


def verifyCustomAdjustDefaultValue(customFormatName):
    test.log("Inside function- verifyCustomAdjustDefaultValue()")  
    selectCustomFormat(customFormatName)
    verifyCalculateVesaFormat()
    
    defaultAdjustValue = ["VESA Calculator", "Viewable Horizontal Px", "Viewable Vertical Lines",
                          "Vertical Scan Frame Rate", "Reduce Blanking", "Yes", "No", "Calculate VESA Format",
                          "Timing", "H Total", "H Front Porch", "H Active", "H Sync", "H Polarity",
                          "V Total", "V Front Porch", "V Active", "V Sync", "V Polarity", "V Rate"]
    for i in defaultAdjustValue:       
        verifyDefaultText = {"container": barco_Inc_Event_Master_Toolset_objScrollCustomFormatAdjustment_CustomScrollView, "text": i, "type": "CustomText", "visible": True}
        textMatch(i, verifyDefaultText)
        if (i == "H Active"): 
            scrollDown(customScroll)
            
    scrollUp(customScroll)            
    plusMinusIcon = ["/images/svgImages/plus.svg", "/images/svgImages/minus.svg"]
    for x in plusMinusIcon:   
        for oc in range(1,12):   
            verifyDefaultIcon = {"container": barco_Inc_Event_Master_Toolset_objScrollCustomFormatAdjustment_CustomScrollView, "id": "icon", "occurrence": oc, "source": "qrc:"+x+"", "type": "Image", "unnamed": 1, "visible": True}    
            sourceMatch(x, verifyDefaultIcon)
            if (oc == 6): 
                scrollDown(customScroll)                 
        scrollUp(customScroll)  
    
    scrollUp(customScroll)             
    sliderDisplayText = ["objDisplayedText", "objSlider"]
    sliderDisplayType = ["CustomText", "Slider"]
    z=1        
    for y in sliderDisplayText:       
        for oc in range(1,12):
            verifyDefaultSliderRadio = {"container": barco_Inc_Event_Master_Toolset_objScrollCustomFormatAdjustment_CustomScrollView, "objectName": y, "occurrence": oc, "type": sliderDisplayType[z-1], "visible": True}
            objectNameMatch(y,  verifyDefaultSliderRadio)
            if (oc == 6): 
                scrollDown(customScroll) 
        scrollUp(customScroll)       
        z += 1    
        

def verifyCalculateVesaFormat():
    test.log("Inside function- verifyCalculateVesaFormat()")   
    calVesaBtn = {"container": barco_Inc_Event_Master_Toolset_objScrollCustomFormatAdjustment_CustomScrollView, "text": "Calculate VESA Format", "type": "CustomText", "unnamed": 1, "visible": True}
        
    if (isButtonEnable(calVesaBtn) == True):
        click(calVesaBtn)     
    else:
        test.fail("Button Object not Enabled")
        
        
def saveCustomFormat(selectCustomName):
    test.log("Inside Function - saveCustomFormat()")
    saveCustomFormatBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Save Custom Format", "type": "CustomText", "unnamed": 1, "visible": True}
    selectCustomFormat(selectCustomName)
    if (isButtonEnable(saveCustomFormatBtn) == True):
        click(saveCustomFormatBtn)
    else:
        test.fail("save custom format button not enabled")
                     
 
def saveCustomFormatFromInput():
    inputEdidTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "EDID", "type": "CustomText", "unnamed": 1, "visible": True}
    saveCustomFormatBtn = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "text": "Save Custom Format", "type": "CustomText", "unnamed": 1, "visible": True}
    click(inputEdidTab)
    click(saveCustomFormatBtn) 
    
def selectTab(name):
    tab ={"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": name, "type": "CustomText", "unnamed": 1, "visible": True}
    click(tab)


def selectDestination(name):
    selectTab("Destination")
    y= {"container": barco_Inc_Event_Master_Toolset_Destination_CustomTab, "objectName": "objDisplayedText", "text": name, "type": "CustomText", "visible": True}
    click(y)
        
    
def saveCustomFormatFromDest():
    destTimingTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "Timing", "type": "CustomText", "unnamed": 1, "visible": True}
    saveCustomFormatBtn = {"container": barco_Inc_Event_Master_Toolset_Timing_CustomTab, "text": "Save Custom Format", "type": "CustomText", "unnamed": 1, "visible": True}
    click(destTimingTab)
    click(saveCustomFormatBtn)
    

def objectNameMatch(objElementName, obj):
    test.log(str(waitForObjectExists(obj).objectName))
    if objElementName in str(waitForObjectExists(obj).objectName): 
        test.compare("true", "true", "Object Text Match: " + str(waitForObject(obj).objectName))
    else:
        test.fail("Object Text not Match: " + str(waitForObject(obj).objectName))  
          

# objPropMatch          
def sourceMatch(path, obj):
    test.log(str(waitForObjectExists(obj).source.path))
    if path in str(waitForObjectExists(obj).source.path): 
        test.compare("true", "true", "Object Text Match: " + str(waitForObject(obj).source.path))
    else:
        test.fail("Object Text not Match: " + str(waitForObject(obj).source.path)) 
        
        
def isButtonEnable(obj):
    test.log("Inside Function- isButtonEnable()")
    if (waitForObjectExists(obj).parent.enabled == True):
        test.compare("true", "true", "Button Object Enabled: " + str(obj))
    else:
        test.fail("Button Object not Enabled: " + str(obj))
    return True
    
def isButtonDisable(obj):
    test.log("isButtonDisable")
    if (waitForObjectExists(obj).parent.enabled == False):
        test.compare("true", "true", "Button Object Disable: " + str(obj))
    else:
        test.fail("Button Object Enabled: " + str(obj))         
    return False   


def scrollDown(obj):
    snooze(1)
    if (object.exists(obj)):
        mouseClick(waitForObjectExists(obj), 3, 606, Qt.LeftButton)    
        snooze(0.5)
    else:
        test.fail("No scroll bar exist")   
        snooze(0.5)
                

def scrollUp(obj):
    snooze(1)
    if (object.exists(obj)):
        mouseClick(waitForObjectExists(obj), 2, 2, Qt.LeftButton)    
        snooze(0.5)
    else:
        test.fail("No scroll bar exist")   
        snooze(0.5)  
          
        
# def selectInputList(type):
#     test.log("Inside Function - expandInputHdmiList()")
#     click(ipRightTab)
#     if(type == "hdmi"):
#         hdmiExpand = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg", "type": "CustomImage", "visible": True}          
#         click(hdmiExpand) 
#     elif(type == "dp"):
#         dpExpand =  {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objImg", "occurrence": 2, "source": Wildcard("/images/svgImages/downArrow.svg", "type": "CustomImage", "visible": True}
#         click(dpExpand)                  
#     elif(type == "sdi"):
#         sdiExpand = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objImg", "occurrence": 3, "source": Wildcard("/images/svgImages/downArrow.svg", "type": "CustomImage", "visible": True}
#         click(sdiExpand)                             
#     else:
#         test.fail("Type not defined")         
          
# def getConnectorObjectName(vpId, slotIndex, connectorIndex):
#     return str("connector_"+str(vpId)+"_"+str(slotIndex)+"_"+str(connectorIndex))
#     
#      
# def selectConnector(vpId, slotIndex, connectorIndex):
#     test.log("Inside Function - selectConnector")    
#     mouseClick(waitForObject(getConnectorObjectName(vpId, slotIndex, connectorIndex)))
#     snooze(0.5);
#     #test.log("Clicked - Connector_" + vpid + "_" + slotIndex + "_" + connectorIndex + "")
