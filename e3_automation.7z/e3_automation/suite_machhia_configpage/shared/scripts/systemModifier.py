from objectmaphelper import *

barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_tabbar_TabBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "tabbar", "occurrence": 3, "type": "TabBar", "visible": True}
barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "firstScrollView", "type": "CustomScrollView", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "secondScrollViewPanel", "type": "CustomScrollView", "unnamed": 1, "visible": True}

defaultSystemNativeRateList= [23.98, 24, 25, 29.97, 30, 47.95, 48, 50, 59.94, 60, 100, 119.98, 120]
defaultPresetConflictModeList = ["Force Recall", "Auto", "User Confirm", "Off"]
defaultGenlockTypeList = ["Freerun", "Lock to External", "Lock to Unit Id"]


def expandSystemModifier(): 
    test.log("Inside Function - selectSystemModifier()")    
    systemModiferBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "hamIcon", "source": Wildcard("/images/iconHamburger.png"), "type": "Image", "visible": True}
 
    if(object.exists(systemModiferBtn) == True):
        click(systemModiferBtn)
        test.log("Clicked - System modifier hamburger icon")
        return True
    else:
        test.fail("Hamburger Icon not preset")
        return False
        
def verifySystemModifierDefaultValue():
    test.log("Inside Function - verifySystemModifierDefaultValue()")
    systemModifierTextList = ["System native rate(Hz)", "Preset conflict mode", "Preset conflict time(fps)",
                                "Genlock", "Genlock status", "H Offset", "V Offset", "Genlock unit ID", "External sync(Hz)"]    
    i = 0;   
    for systemModifierList in systemModifierTextList:
        defaultFirstScrollView =  {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "text": systemModifierList, "type": "CustomText", "visible": True}
        defaultSecondScrollView = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "text": systemModifierList, "type": "CustomText", "visible": True}
        elementList = [defaultFirstScrollView, defaultSecondScrollView]            
        verifyText(elementList[i], systemModifierList)
        if (systemModifierList == "Preset conflict time(fps)"):  
            i +=1
            

def setSystemNativeRate(rate):
    test.log("Inside Function - setSystemNativeRate()")
    nativeRateArrowObj = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True} 
    systemNativeRateComboBox = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "id": "objEnabledGradRect", "type": "Rectangle", "unnamed": 1, "visible": True}
    verifySelectedSystemNativeRate = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "text": rate, "type": "CustomText", "unnamed": 1, "visible": True}
    
    if (isObjectEnable(systemNativeRateComboBox) == True): 
        click(nativeRateArrowObj) 
        selectNativeRate = getComboBoxElement(rate)
        click(selectNativeRate);
        verifyText(verifySelectedSystemNativeRate, rate)
        return True
    else:
        test.fail("Test fail - System native rate combo box disabled")    
        return False
    
def setPresetConflictMode(modeName):
    test.log("Inside Function - setPresetConflictMode()")
    presetConflictArrowObj = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "objectName": "objImg", "occurrence": 2, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    presetConflictModeComboBox = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "id": "objEnabledGradRect", "occurrence": 2, "type": "Rectangle", "unnamed": 1, "visible": True}
    verifySelectedPresetConflictMode = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "text": modeName, "type": "CustomText", "unnamed": 1, "visible": True}
    
    if (isObjectEnable(presetConflictModeComboBox) == True): 
        click(presetConflictArrowObj) 
        selectPresetMode = getComboBoxElement(modeName)
        click(selectPresetMode);
        verifyText(verifySelectedPresetConflictMode, modeName)
        return True
    else:
        test.fail("Test fail - System native rate combo box disabled")    
        return False
    
    
def setPresetConflictTime(timeValue):
    test.log("Inside Function - setPresetConflictTime()")
    presetConflictTimeEditBox = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}      
    presetConflictProxyObj = {"container": barco_Inc_Event_Master_Toolset_firstScrollView_CustomScrollView, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    if (isObjectEnable(presetConflictTimeEditBox) == True): 
        click(presetConflictTimeEditBox)
        updateText(presetConflictProxyObj, timeValue);snooze(1.5);
        textMatch(timeValue, presetConflictTimeEditBox)
        return True
    else:
        test.fail("Test fail - preset conflict time box not enabled")       
        return False

def setGenlock(genlockType):
    test.log("Inside Function - setGenlock()")
    genlockArrowObj = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    verifySelectedGenlock = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "text": genlockType, "type": "CustomText", "unnamed": 1, "visible": True}
    genlockComboBox = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "id": "objEnabledGradRect", "type": "Rectangle", "unnamed": 1, "visible": True}  
    if (isObjectEnable(genlockComboBox) == True): 
        click(genlockArrowObj)
        selectGenlockType = getComboBoxElement(genlockType) 
        click(selectGenlockType)
        verifyText(verifySelectedGenlock, genlockType)
        return True
    else:
        test.fail("Test fail - Genlock combo box disabled")   
        return False 
    

def setGenlockUnitId(unitId):
    test.log("Inside Function - setGenlockUnitId()")
    genlockUnitIdEditBox = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "objectName": "objLabelRect", "type": "Rectangle", "visible": True}
    genlockUnitIdProxyObj = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    applyBtn = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "text": "Apply", "type": "CustomText", "unnamed": 1, "visible": True}
    if (isObjectEnable(genlockUnitIdEditBox) == True): 
        click(genlockUnitIdEditBox)
        updateText(genlockUnitIdProxyObj, unitId);snooze(1.5);
        click(applyBtn)
        textMatch(unitId, genlockUnitIdEditBox)
        return True
    else:
        test.fail("Test fail - Genlock unit id box not enabled")   
        return False 
    
    
def setHorizontalOffset(value):
    hOffsetEditBox = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "objectName": "objDisplayedText", "occurrence": 4, "type": "CustomText", "visible": True}
    vOffsetProxyObj = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    if (isObjectEnable(hOffsetEditBox) == True): 
        click(hOffsetEditBox)
        updateText(vOffsetProxyObj, value)
        textMatch(value, hOffsetEditBox)
        return True
    else:
        test.fail("Test fail - set Horizontal Offset edit box not enabled")  
        return False
    
def setVerticalOffset(value):
    vOffsetEditBox = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "objectName": "objDisplayedText", "occurrence": 5, "type": "CustomText", "visible": True}
    hOffsetProxyObj = {"container": barco_Inc_Event_Master_Toolset_secondScrollViewPanel_CustomScrollView, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    if (isObjectEnable(vOffsetEditBox) == True): 
        click(vOffsetEditBox)
        updateText(hOffsetProxyObj, value)
        textMatch(value, vOffsetEditBox)
        return True
    else:
        test.fail("Test fail - set vertical Offset edit box not enabled")
        return False