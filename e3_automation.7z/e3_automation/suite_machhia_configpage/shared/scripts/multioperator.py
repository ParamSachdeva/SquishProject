from objectmaphelper import *

barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Overlay = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "type": "Overlay", "unnamed": 1, "visible": True}
multiOperator= {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objOperatorImage", "source": Wildcard("/images/multiOperator/icon"), "type": "CustomImage", "visible": True}
closeBtnMuOp = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objOperatorImage", "source": Wildcard("/images/mainWnd/icon_16_close.png"), "type": "CustomImage", "visible": True}
showPassword = {"container": barco_Inc_Event_Master_Toolset_Overlay, "source": Wildcard("/images/svgImages/ShowPassword.svg"), "type": "Image", "unnamed": 1, "visible": True}
hidePassword = {"container": barco_Inc_Event_Master_Toolset_Overlay, "source": Wildcard("/images/svgImages/HidePassword.svg"), "type": "Image", "unnamed": 1, "visible": True}
passwordObj  = {"container": barco_Inc_Event_Master_Toolset_Overlay, "echoMode": 0, "objectName": "objDisplayedText", "type": "CustomTextInput", "visible": True}
hiddenpasswordObj = {"container": barco_Inc_Event_Master_Toolset_Overlay, "echoMode": 2, "objectName": "objDisplayedText", "passwordCharacter": "●", "type": "CustomTextInput", "visible": True}
arrowBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
opHeading = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": Wildcard("Operator*"), "type": "CustomText", "unnamed": 1, "visible": True}
opEditBox = {"container": barco_Inc_Event_Master_Toolset_Overlay, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
arrowUp   = {"container": barco_Inc_Event_Master_Toolset_Overlay, "id": "icon", "source": Wildcard("/images/multiOperator/icon_up_arrow.png"), "type": "Image", "unnamed": 1, "visible": True}

def verifyMultioperatorExist(): 
    test.log("verifyMultioperatorExist")   
    objectExist(multiOperator)


def verifyMultioperatorNotExist():
    test.log("verifyMultioperatorNotExist")   
    objectNotExist(multiOperator)


def launchMultioperator():
    test.log("launchMultioperator") 
    click(multiOperator)
    wait(0.25)
    objectExist(closeBtnMuOp)
    
    
def closeMultioperator():
    click(closeBtnMuOp)
    objectNotExist(closeBtnMuOp)
      
    
def enableOperator(opNum):
    opObj = {"container": barco_Inc_Event_Master_Toolset_Overlay, "id": "objToggleBtn", "occurrence": opNum, "type": "CustomToggleButton", "unnamed": 1, "visible": True}
    if (waitForObjectExists(opObj).m_bEnabled == False):
        click(opObj)
         
    if (waitForObjectExists(opObj).m_bEnabled == True):
        test.compare("true", "true","Object Enabled: " + str(opObj))
    else:
        test.fail("Object not Enabled: " + str(opObj))


def disableOperator(opNum):
    opObj = {"container": barco_Inc_Event_Master_Toolset_Overlay, "id": "objToggleBtn", "occurrence": opNum, "type": "CustomToggleButton", "unnamed": 1, "visible": True}
    if (waitForObjectExists(opObj).m_bEnabled == True):
        click(opObj)
         
    if (waitForObjectExists(opObj).m_bEnabled == False):
        test.compare("true", "true","Object Disabled: " + str(opObj))
    else:
        test.fail("Object still Enabled: " + str(opObj))
    
def renameOperator(opNum,new):    
    if(opNum ==1):
        ocuurance = 1
    elif (opNum ==2):
        ocuurance = 4
    elif (opNum ==3):
        ocuurance = 7
    else:
        test.fail("Wrong operator number")
    
    opName = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objDisplayedText", "occurrence": ocuurance, "type": "CustomText", "visible": True}
    
    click(opName) 
    updateText(opEditBox,new)
    textMatch(new,opName)


def setPresetRange(opNum,start,end):
    if(opNum ==1):
        startOccurance = 2
        endOccurance  = 3
    elif(opNum ==2):
        startOccurance  = 5
        endOccurance  = 6
    elif(opNum ==3):
        startOccurance  = 8
        endOccurance  = 9
    
    startObj = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objDisplayedText", "occurrence": startOccurance, "type": "CustomText", "visible": True}
    endObj = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objDisplayedText", "occurrence": endOccurance, "type": "CustomText", "visible": True}
    
    click(startObj) 
    updateText(opEditBox,start)
    textMatch(str(start),startObj)    
    
    click(endObj) 
    updateText(opEditBox,end)
    textMatch(str(end),endObj)
    

def assignDestToOperator(opNum,destIndex):
    test.log("assignDestToOperator " + str(opNum) + " " + str(destIndex))
    arrowDown = {"container": barco_Inc_Event_Master_Toolset_Overlay, "id": "icon", "occurrence": opNum, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "Image", "unnamed": 1, "visible": True}
    destObj  = {"container": barco_Inc_Event_Master_Toolset_Overlay, "id": "screenDestDelegateRect", "index": destIndex, "type": "Rectangle", "unnamed": 1, "visible": True}
    click(arrowDown)    
    if(waitForObjectExists(destObj).isAdd == False):
        click(destObj)
    click(arrowUp) 

def unAssignDestToOperator(opNum,destIndex):
    test.log("unAssignDestToOperator " + str(opNum) + " " + str(destIndex))
    arrowDown = {"container": barco_Inc_Event_Master_Toolset_Overlay, "id": "icon", "occurrence": opNum, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "Image", "unnamed": 1, "visible": True}
    destObj  = {"container": barco_Inc_Event_Master_Toolset_Overlay, "id": "screenDestDelegateRect", "index": destIndex, "type": "Rectangle", "unnamed": 1, "visible": True}
    click(arrowDown)    
    if(waitForObjectExists(destObj).isAdd == True):
        click(destObj)
    click(arrowUp) 

def updateOperatorPassword(password):  
    click(passwordObj) 
    updateText(opEditBox,password)   
    textMatch(password,passwordObj)


def verifyShowHidePassword():
    click(showPassword)
    textMatch("password",passwordObj)
    snooze(1)
    click(hidePassword)
    snooze(0.25)
    compareTwoTexts("●●●●●●●●",str(waitForObjectExists(hiddenpasswordObj).displayText))    
    click(showPassword)
    
def switchOperator(opNum):
    opObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "opRect", "occurrence": opNum, "type": "Rectangle", "unnamed": 1, "visible": True}
    click(arrowBtn)
    click(opObj)    
    textMatch("Operator " + str(opNum),opHeading)

def switchSuperOperator(password):
    opObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "superOpRect", "type": "Rectangle", "unnamed": 1, "visible": True}
    superOpHeading = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Super Operator", "type": "CustomText", "unnamed": 1, "visible": True}
    loginBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Login", "type": "CustomText", "unnamed": 1, "visible": True}
    loginError = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Login Error! Wrong Password", "type": "CustomText", "unnamed": 1, "visible": True}

    showPass = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "source": Wildcard("/images/svgImages/ShowPassword.svg"), "type": "Image", "unnamed": 1, "visible": True}
    hidePass = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "source": Wildcard("/images/svgImages/HidePassword.svg"), "type": "Image", "unnamed": 1, "visible": True}

    click(arrowBtn)
    click(opObj)
    click(showPass)    
    updateText(passwordObj,password)
    snooze(1)
    click(hidePass) 
    click(hiddenpasswordObj)
    compareTwoTexts("●●●●●●●●",str(waitForObjectExists(hiddenpasswordObj).displayText))    
       
    click(loginBtn)  
    objectNotExist(loginError)   
        
    if (waitForObjectExists(superOpHeading).text  == "Super Operator"):
        test.compare("true", "true","Switched to super operator")
    else:
        test.fail("Not Switched to super operator")     