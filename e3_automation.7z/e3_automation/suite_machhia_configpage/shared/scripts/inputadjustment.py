from objectmaphelper import *


barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_tabbar_TabBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "tabbar", "occurrence": 2, "type": "TabBar", "visible": True}
barco_Inc_Event_Master_Toolset_Settings_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objSettingTab", "title": "Settings", "type": "CustomTab", "unnamed": 1, "visible": True}
o_QQuickWindowQmlImpl = {"type": "QQuickWindowQmlImpl", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Input_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objCustomIpTab", "title": "Input", "type": "CustomTab", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_EDID_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objEdidTab", "title": "EDID", "type": "CustomTab", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Format_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objFormatTab", "title": "Format", "type": "CustomTab", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Color_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objColorTab", "title": "Color", "type": "CustomTab", "unnamed": 1, "visible": True}
contrastOverallText     =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objDisplayedText", "occurrence": 1, "type": "CustomText", "visible": True}
inputObj = {"container": o_QQuickWindowQmlImpl, "echoMode": 0, "objectName": "objVideoformatToolSB", "type": "TextInput", "visible": True}
formatSettingObj = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": RegularExpression("1920x1080p*"), "type": "CustomText", "unnamed": 1, "visible": True}
freqSettingObj = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": "59.94", "type": "CustomText", "unnamed": 1, "visible": True}
applySettingBtn = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": "Apply", "type": "CustomText", "unnamed": 1, "visible": True}
inputName = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}
  
 
def verifySettingTabSection():
    settingTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "Settings", "type": "CustomText", "unnamed": 1, "visible": True}
    syncStatus = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objDisplayedText", "occurrence": 2, "type": "CustomText", "visible": True}
    videoStatus = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objDisplayedText", "occurrence": 3, "type": "CustomText", "visible": True}
    colorSpace = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": "RGB, Full Range", "type": "CustomText", "unnamed": 1, "visible": True}
    colorSpaceDropDown = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objImg", "occurrence": 3, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    colorimeter = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": "BT.709", "type": "CustomText", "unnamed": 1, "visible": True}
    dropdownSearchBox = {"backgroundcolor": "#2d2d2d", "container": o_QQuickWindowQmlImpl, "echoMode": 0, "objectName": "objColorimetrySelectionBoxSB", "type": "TextInput", "visible": True}
    dropdownSearchBtn = {"container": o_QQuickWindowQmlImpl, "id": "objSearchIcon", "source": Wildcard("/images/otherImages/searchIcon.png"), "type": "Image", "unnamed": 1, "visible": True}
    gammaFX = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objDisplayedText", "occurrence": 4, "type": "CustomText", "visible": True}
    saveHDRAsFile = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objDisplayedText", "occurrence": 4, "type": "CustomText", "visible": True}
    colorDepth = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objDisplayedText", "occurrence": 5, "type": "CustomText", "visible": True}
    colorAdjustAutoAquire = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "type": "CustomToggleButton", "unnamed": 1, "visible": True}
    hdcpMode = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": "Off", "type": "CustomText", "unnamed": 1, "visible": True}
    hdcpmodeDropDown = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objImg", "occurrence": 5, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    status = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objDisplayedText", "occurrence": 6, "type": "CustomText", "visible": True}
    connectorMapping = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": "Unit 0\nSlot 3\nIn 2\nTri Combo Gen2", "type": "CustomText", "unnamed": 1, "visible": True}
    connectormapVscroll = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "id": "vscrollbar", "occurrence": 2, "orientation": 2, "type": "ScrollBar", "unnamed": 1, "visible": True}
    connectormapHscroll = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "id": "hscrollbar", "orientation": 1, "type": "ScrollBar", "unnamed": 1, "visible": True}
    settingSave = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": "Save", "type": "CustomText", "unnamed": 1, "visible": True}
    settingCancel = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": "Cancel", "type": "CustomText", "unnamed": 1, "visible": True}
    
    click(settingTab)    
    textMatch("HDMI", inputName)
    isObjectDisable(syncStatus)
    verifyText(syncStatus, "Invalid")
    isObjectDisable(videoStatus)
    verifyText(videoStatus, "Invalid")
    verifyText(formatSettingObj, "1920x1080p")
    verifyText(freqSettingObj, "59.94")
    verifyText(colorSpace, "RGB, Full Range")
    verifyText(colorimeter, "BT.709")
    verifyText(gammaFX, "SDR")
    verifyText(colorDepth, "N/A") 
    verifyText(hdcpMode, "Off")  
    scrollDown()
    verifyText(status, "N/A")
    textMatch("Unit 0", connectorMapping)

    
def verifyEDIDTabSection():
    edidTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "EDID", "type": "CustomText", "unnamed": 1, "visible": True}
    edidFileName = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "text": "None", "type": "CustomText", "unnamed": 1, "visible": True}
    conocterAdjustAutoAquire = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "type": "CustomToggleButton", "unnamed": 1, "visible": True}
    currentEDID = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}
    edidFormat = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": RegularExpression("1920x1080p*"), "type": "CustomText", "unnamed": 1, "visible": True}
    freq = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "text": "59.94", "type": "CustomText", "unnamed": 1, "visible": True}
    applyBtn = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "text": "Apply", "type": "CustomText", "unnamed": 1, "visible": True}
    bitDepth = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "text": 12, "type": "CustomText", "unnamed": 1, "visible": True}
    bitdepthDropDown = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objImg", "occurrence": 4, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    hTotal = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "occurrence": 2, "type": "CustomText", "visible": True}
    hFrontPorch = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "occurrence": 3, "type": "CustomText", "visible": True}
    hActive = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "occurrence": 4, "type": "CustomText", "visible": True}
    hSync = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "occurrence": 5, "type": "CustomText", "visible": True}
    hPolarity = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "occurrence": 2, "type": "CustomToggleButton", "unnamed": 1, "visible": True}
    vTotal = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "occurrence": 6, "type": "CustomText", "visible": True}
    vFrontPorch = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "occurrence": 7, "type": "CustomText", "visible": True}
    vActive = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "occurrence": 8, "type": "CustomText", "visible": True}
    vSync = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "occurrence": 9, "type": "CustomText", "visible": True}
    vPolarity = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "occurrence": 3, "type": "CustomToggleButton", "unnamed": 1, "visible": True}
    applyBtn2 = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "occurrence": 2, "text": "Apply", "type": "CustomText", "unnamed": 1, "visible": True}
    applyToAllInput = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "occurrence": 4, "type": "CustomToggleButton", "unnamed": 1, "visible": True}
    status = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objDisplayedText", "occurrence": 10, "type": "CustomText", "visible": True}
    saveCustomFormat = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "text": "Save Custom Format", "type": "CustomText", "unnamed": 1, "visible": True}
    cancel = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "text": "Save Custom Format", "type": "CustomText", "unnamed": 1, "visible": True}
    
    click(edidTab)
    verifyText(edidFileName, "None")
    verifyText(currentEDID, "1920x1080p @59.94")
    verifyText(edidFormat, "1920x1080p")
    verifyText(freq, "59.94")
    verifyText(bitDepth, "12")
    verifyText(hTotal, "2200")
    verifyText(hFrontPorch, "88")
    verifyText(hActive, "1920")
    scrollDown()
    verifyText(vTotal, "2200")
    verifyText(vFrontPorch, "4")
    verifyText(vActive, "1080")
    verifyText(vSync, "5")
    verifyText(status, "Not intialized")
    IsObjectDisable(status)
    IsObjectEnable(saveCustomFormat)
    IsObjectDisable(cancel)
    
def verifyFormatTabSection():
    formatTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "Format", "type": "CustomText", "unnamed": 1, "visible": True}
    edidFormat = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "text": "1920x1080p ", "type": "CustomText", "unnamed": 1, "visible": True}
    edidFreq = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "text": "59.94", "type": "CustomText", "unnamed": 1, "visible": True}
    applyBtn = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "text": "Apply", "type": "CustomText", "unnamed": 1, "visible": True}
    hTotal = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}
    hFrontPorch = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "objectName": "objDisplayedText", "occurrence": 2, "type": "CustomText", "visible": True}
    hActive = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "objectName": "objDisplayedText", "occurrence": 3, "type": "CustomText", "visible": True}
    hSync = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "objectName": "objDisplayedText", "occurrence": 4, "type": "CustomText", "visible": True}
    vTotal = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "objectName": "objDisplayedText", "occurrence": 5, "type": "CustomText", "visible": True}
    vFrontPorch = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "objectName": "objDisplayedText", "occurrence": 6, "type": "CustomText", "visible": True}
    vActive = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "objectName": "objDisplayedText", "occurrence": 7, "type": "CustomText", "visible": True}
    vSync = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "objectName": "objDisplayedText", "occurrence": 8, "type": "CustomText", "visible": True}
    saveCustomFormat = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "text": "Save Custom Format", "type": "CustomText", "unnamed": 1, "visible": True}
    cancel = {"container": barco_Inc_Event_Master_Toolset_Format_CustomTab, "text": "Save Custom Format", "type": "CustomText", "unnamed": 1, "visible": True}
    contrastOverallDragger = {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objGrooveBar", "type": "ProgressBar", "visible": True}
    
    click(formatTab)
    verifyText(edidFormat, "1920x1080p")
    verifyText(edidFreq, "59.94")
    verifyText(hTotal, "2200")
    verifyText(hFrontPorch, "88")
    verifyText(hActive, "1920")
    verifyText(hSync, "88")
    verifyText(vTotal, "2200")
    verifyText(vFrontPorch, "4")
    verifyText(vActive, "1080")
    verifyText(vSync, "5")
    
def verifyColorTabSection():
    
    colorTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "Color", "type": "CustomText", "unnamed": 1, "visible": True}   
    click(colorTab)
    
    i=1
    j=1
    k=2
    powerSignal =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objImg", "occurrence": i, "source": Wildcard("/images/connectorImages/PowerWhite.png"), "type": "CustomImage", "visible": True}
    resetBtn    =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "text": "Reset", "occurrence": i, "type": "CustomText", "unnamed": 1, "visible": True}
    ColorBar    =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objGrooveBar", "occurrence": i, "type": "ProgressBar", "visible": True}
    ColorIpBox  =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
    ColorMinusBtn =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "id": "objBackgroundLayerImage", "occurrence": j, "source": Wildcard("/images/buttonBgNormalSmall.png"), "type": "BorderImage", "unnamed": 1, "visible": True}
    ColorPlusBtn =    {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "id": "objBackgroundLayerImage", "occurrence": k, "source": Wildcard("/images/buttonBgNormalSmall.png"), "type": "BorderImage", "unnamed": 1, "visible": True}
     
    isObjectEnable(powerSignal)
    isObjectEnable(resetBtn)
    isObjectEnable(ColorBar)
    verifyText(ColorIpBox, "112")
    isObjectEnable(ColorMinusBtn)
    isObjectEnable(ColorPlusBtn)
    
    i=2
    j=3
    k=4
    powerSignal =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objImg", "occurrence": i, "source": Wildcard("/images/connectorImages/PowerWhite.png"), "type": "CustomImage", "visible": True}
    resetBtn    =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "text": "Reset", "occurrence": i, "type": "CustomText", "unnamed": 1, "visible": True}
    ColorBar    =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objGrooveBar", "occurrence": i, "type": "ProgressBar", "visible": True}
    ColorIpBox  =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
    ColorMinusBtn =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "id": "objBackgroundLayerImage", "occurrence": j, "source": Wildcard("/images/buttonBgNormalSmall.png"), "type": "BorderImage", "unnamed": 1, "visible": True}
    ColorPlusBtn =    {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "id": "objBackgroundLayerImage", "occurrence": k, "source": Wildcard("/images/buttonBgNormalSmall.png"), "type": "BorderImage", "unnamed": 1, "visible": True}
  
    isObjectEnable(powerSignal)
    isObjectEnable(resetBtn)
    isObjectEnable(ColorBar)
    verifyText(ColorIpBox, "100")
    isObjectEnable(ColorMinusBtn)
    isObjectEnable(ColorPlusBtn)    
    scrollDown()
    
    i=3
    j=5
    k=6    
    ColorBar    =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objGrooveBar", "occurrence": i, "type": "ProgressBar", "visible": True}
    ColorIpBox  =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
    ColorMinusBtn =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "id": "objBackgroundLayerImage", "occurrence": j, "source": Wildcard("/images/buttonBgNormalSmall.png"), "type": "BorderImage", "unnamed": 1, "visible": True}
    ColorPlusBtn =    {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "id": "objBackgroundLayerImage", "occurrence": k, "source": Wildcard("/images/buttonBgNormalSmall.png"), "type": "BorderImage", "unnamed": 1, "visible": True}
   
    isObjectEnable(ColorBar)
    verifyText(ColorIpBox, "100")
    isObjectEnable(ColorMinusBtn)
    isObjectEnable(ColorPlusBtn)
    
       
    
def verifyFormats(formats):
    arrowFormatObj = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    for format in formats:
        searchSelectFromDropDown(arrowFormatObj,inputObj,format)
        verifyText(formatSettingObj, format)
        isObjectEnable(applySettingBtn)
   
def verifyFrequencies(frequencies):
    arrowFreqObj = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objImg", "occurrence": 2, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    for frequency in frequencies:
        searchSelectFromDropDown(arrowFreqObj,inputObj,frequency)
        verifyText(freqSettingObj,frequency)
        isObjectEnable(applySettingBtn)
     
def verifyColorSpaces(colorspaces):
    arrowcolorObj = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objImg", "occurrence": 3, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    for colorspace in colorspaces:
        colorspacedrobdownText = {"container": objScrollView_ScrollView, "text": colorspace, "type": "CustomText", "unnamed": 1, "visible": True}
        colorspaceSettingObj =  {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": colorspace, "type": "CustomText", "unnamed": 1, "visible": True}
        click(arrowcolorObj)
        click(colorspacedrobdownText)     
        verifyText(colorspaceSettingObj,colorspace)
    
def verifyColorimeters(colorimeters):
    arrrowColorimeter = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objImg", "occurrence": 3, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    for colorimeter in colorimeters:
        colorimeterdrobdownText = {"container": objScrollView_ScrollView, "text": colorimeter, "type": "CustomText", "unnamed": 1, "visible": True}
        colorimeterSettingObj =  {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": colorimeter, "type": "CustomText", "unnamed": 1, "visible": True}
        click(arrrowColorimeter)
        click(colorimeterdrobdownText)     
        verifyText(colorimeterSettingObj,colorimeter)

def verifyHDCPModes(hdcpModes):   
    arrowHDCPModeObj = {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "objectName": "objImg", "occurrence": 5, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    for hdcpMode in hdcpModes:
        hdcpModedrobdownText = {"container": objScrollView_ScrollView, "text": hdcpMode, "type": "CustomText", "unnamed": 1, "visible": True}
        hdcpModeSettingObj =  {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": hdcpMode, "type": "CustomText", "unnamed": 1, "visible": True}
        click(arrowHDCPModeObj)
        click(hdcpModedrobdownText)     
        verifyText(hdcpModeSettingObj,hdcpMode)

def verifyBitDepths(bitdepths):
    arrowbitdeptObj = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objImg", "occurrence": 4, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    for bitdepth in bitdepths:
        bitdepthdrobdownText = {"container": objScrollView_ScrollView, "text": bitdepth, "type": "CustomText", "unnamed": 1, "visible": True}
        bitdepthSettingObj =  {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": bitdepth, "type": "CustomText", "unnamed": 1, "visible": True}
        click(arrowbitdeptObj)
        click(bitdepthdrobdownText)     
        verifyText(bitdepthSettingObj,bitdepth)

def verifySDITypes(sdiTypes):
    arrowsditypeObj = {"container": barco_Inc_Event_Master_Toolset_EDID_CustomTab, "objectName": "objImg", "occurrence": 4, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    for sdiType in sdiTypes:
        sdiTypedrobdownText = {"container": objScrollView_ScrollView, "text": sdiType, "type": "CustomText", "unnamed": 1, "visible": True}
        sdiTypeSettingObj =  {"container": barco_Inc_Event_Master_Toolset_Settings_CustomTab, "text": sdiType, "type": "CustomText", "unnamed": 1, "visible": True}
        click(arrowsditypeObj)
        click(sdiTypedrobdownText)     
        verifyText(sdiTypeSettingObj,sdiType)
        
def verifyDraggerColorTab():
    sn=1
    while (sn < 12):  
        if (sn == 5):
            scrollDown()
        sn = sn + 1 
        contrastOverallDragger  =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "objectName": "objGrooveBar", "occurrence": sn, "type": "ProgressBar", "visible": True}
        verifyDragger(contrastOverallText,contrastOverallDragger)
    
def verifyDragger(textobj,draggerObj):
    before = str(waitForObjectExists(textobj).text)
    test.log("Before dragger right" + before)    
    moveDragger(draggerObj,"right")
    after = str(waitForObjectExists(textobj).text)
    test.log("After dragger right" + after)  
    if(before == after):
        test.compare(True, False, "Dragger did'nt work")
    else:
        test.compare(True, True, "Dragger working fine")
        
def verifyPlusMinusColorTab():   
    sn=1
    while (sn < 12):  
        if (sn == 5):
            scrollDown()
        sn = sn + 1 
        minusBtn =   {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "id": "objBackgroundLayerImage", "occurrence": sn, "source": Wildcard("/images/buttonBgNormalSmall.png"), "type": "BorderImage", "unnamed": 1, "visible": True}
        plusBtn  =    {"container": barco_Inc_Event_Master_Toolset_Color_CustomTab, "id": "objBackgroundLayerImage", "occurrence": sn, "source": Wildcard("/images/buttonBgNormalSmall.png"), "type": "BorderImage", "unnamed": 1, "visible": True}
        verifyPlusMinus(contrastOverallText,minusBtn)
        verifyPlusMinus(contrastOverallText,plusBtn)
        

def verifyPlusMinus(textobj,plusMinusObj):
    before = str(waitForObjectExists(textobj).text)
    test.log("Before Plus Minus right" + before)    
    click(plusMinusObj)
    click(plusMinusObj)
    after = str(waitForObjectExists(textobj).text)
    test.log("After Plus Minus right" + after)  
    if(before == after):
        test.compare(True, False, "Plus Minus did'nt work")
    else:
        test.compare(True, True, "Plus Minus working fine")
        