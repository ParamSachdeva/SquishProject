source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "destinations.py"))


def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(destinationTab)
    deleteDestinations("all")
    addScreenDestination(1)
    addOutputsToDestination(4, 1)
    selectScreenDestination(1,"list")
    click(settingsTab)
    setDimensions(2,2)
    click(wideTab)
    click(featheringRadioBtn)
    click(featheringToggle)
    verifyDestinationSubTabSectionEnabledDisabled("Wide", featheringResetBtn, featheringBtns)
    verifyFeatheringSlider()
    verifyWideSubWindow()
    verifyFeatheringUpdates()
    