source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "devices.py"))


def main():
    test.log("Case will verify in case of real hardware")
    ##########################################
#     launchMacchia()
#     launchEmulator()  
#     connectEmulator()
#     objectNotExist(noDevice)    
#     disconnectInternet() 
#     objectExist(noDevice)
#     connectInternet()   
#     objectNotExist(noDevice)      
#     closeApp()   