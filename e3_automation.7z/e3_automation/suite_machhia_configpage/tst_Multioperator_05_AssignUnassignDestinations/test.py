source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "multioperator.py"))


def main():
    test.log("Multi Operator Assign/Unassign Destination")
    launchMacchia()
    launchEmulator()
    connectEmulator()
    launchMultioperator()
    enableOperator(1)
    enableOperator(2)
    enableOperator(3)    
    #Assign
    assignDestToOperator(1,0)
    assignDestToOperator(2,0)
    assignDestToOperator(3,0)
    unAssignDestToOperator(1,0)    
    unAssignDestToOperator(2,0)
    unAssignDestToOperator(3,0)
    #Un Assign
    assignDestToOperator(1,1)
    assignDestToOperator(2,1)
    assignDestToOperator(3,1)
    unAssignDestToOperator(1,1)    
    unAssignDestToOperator(2,1)
    unAssignDestToOperator(3,1)
    
    disableOperator(1)
    disableOperator(2)
    disableOperator(3)