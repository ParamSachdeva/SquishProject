source(findFile("scripts", "initialize.py"))

def main():

    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(outputTab)
    click(screenTypeOutput)
    deleteDestinations("allonebyone")
    #verification of single output addition using dummy output
    addScreenDestination(1)
    deleteDestinations("all")
    #verification of two output - two destination addition using dummy output
    addScreenDestination(2)
    deleteDestinations("all")
    #verification of two output addition using dummy output - single destination
    addScreenDestination(1)
    addOutputsToDestination(2,1)
    deleteDestinations("all")
    #verification of output addition using drag drop - single output
    addScreenDestination(1)
    addOutputUsingDragDrop(1,1)
    deleteDestinations("all")
    #verification of output addition using drag drop - two output
    addScreenDestination(1)
    addOutputUsingDragDrop(1,2)
#    verifyDragAndPlusCombinedOutputAddtion()