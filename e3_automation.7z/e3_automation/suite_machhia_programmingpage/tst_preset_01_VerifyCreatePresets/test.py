source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(programmingTab)
    
    createPreset(1,"Complete",True,False,"PVW")
    createPreset(1,"Complete",False,True,"PVW")
    createPreset(1,"Complete",False,False,"PVW")
    createPreset(1,"Complete",True,True,"PVW") 
    createPreset(2,"Relative",True,True,"PVW")
    createPreset(2,"Relative",True,False,"PVW")
    createPreset(2,"Relative",False,True,"PVW")
    createPreset(2,"Relative",False,False,"PVW")
 
    createPreset(1,"Complete",True,False,"PGM")
    createPreset(1,"Complete",False,True,"PGM")
    createPreset(1,"Complete",False,False,"PGM")
    createPreset(1,"Complete",True,True,"PGM")
     
    createPreset(2,"Relative",True,True,"PGM")
    createPreset(2,"Relative",True,False,"PGM")
    createPreset(2,"Relative",False,True,"PGM")
    createPreset(2,"Relative",False,False,"PGM")
