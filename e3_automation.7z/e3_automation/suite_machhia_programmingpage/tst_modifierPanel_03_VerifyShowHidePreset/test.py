source(findFile("scripts", "initialize.py"))

def main():    
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(programmingTab)
    click(viewAllObj)
    
    
    createPreset(1,"Complete",True,False,"PVW")      
    createPreset(2,"Relative",False,True,"PVW")
    createPreset(1,"Complete",True,True,"PGM")
    createPreset(1,"Relative",False,False,"PGM")
    selectPreset(1)
    
    
    
    isObjectDisable(trans)
    isObjectDisable(cut)
    isObjectDisable(arm)
    isObjectDisable(matchPGM)
    isObjectDisable(clear)             
    selectViewType("Input","list")
    expandList("Input")    
    dragToPrev(destinationObjArea,1)
    isObjectEnable(trans)
    isObjectEnable(cut)
    isObjectEnable(arm)
    isObjectEnable(matchPGM)
    isObjectEnable(clear)     
    click(clear)
    isObjectDisable(trans)
    isObjectDisable(cut)
    isObjectDisable(arm)
    isObjectDisable(matchPGM)
    isObjectDisable(clear) 
    
    