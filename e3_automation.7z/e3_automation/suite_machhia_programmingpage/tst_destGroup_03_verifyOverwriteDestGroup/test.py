source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(programmingTab)
    #deleteAllGroup()
    createAndVerifyDestGroup(2)
    #list = getListOfAllDestGroup()
    #list.append(selectDestination(1))
    selectDestination(1)
    #overwriteGroup(str(getListOfAllDestGroup()[0]))
    overwriteGroup("DestGroup 1",1)
    #verifyoverwriteGroup("DestGroup 1",1*2,list)
    verifyoverwriteGroup("DestGroup 1",1*2)
    