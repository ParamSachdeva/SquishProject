source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(programmingTab)
    click(viewAllObj)
    deleteallPreset()
    
    createPreset(1,"Complete",True,False,"PVW")
    createPreset(2,"Relative",False,True,"PVW")
    createPreset(1,"Complete",True,True,"PGM")
    createPreset(1,"Relative",False,False,"PGM")
    
    enableReorderPreset(5)
    moveAndVerifyPreset(1,4,3.01)
    