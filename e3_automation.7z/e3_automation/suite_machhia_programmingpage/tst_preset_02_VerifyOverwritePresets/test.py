source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(programmingTab)
    deleteallPreset()
    
    createPreset(1,"Complete",True,False,"PVW")
    createPreset(2,"Relative",False,True,"PVW")
    createPreset(1,"Complete",True,True,"PGM")
    createPreset(1,"Relative",False,False,"PGM")
    
    selectDestination("ScreenDest1","arm/unarm")
    #update
    #run argument according
    
    overwritePreset(1,"PVW",True)
    overwritePreset(2,"PVW",False)
    overwritePreset(3,"PGM",False)
    overwritePreset(4,"PGM",True)