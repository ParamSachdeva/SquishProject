source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(programmingTab)
    verifyDefaultLayout()    
    createAndVerifyLayouts(11)
    clickAndVerifyAllBlankLayouts()