source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(programmingTab)
    expandList("Input")
    setAllBackupsToNone()
    collapseBackupList()
    verifyInputBackupFields("all")
    collapseBackupList()
    verifyBackupVals()