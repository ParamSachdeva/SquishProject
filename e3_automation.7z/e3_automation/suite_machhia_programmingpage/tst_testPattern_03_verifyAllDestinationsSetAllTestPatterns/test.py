source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    openTestPattern()     
    destlist = ["ScreenDest0","ScreenDest1"]
    for dest in destlist:
        selectDestinationForTestPattern(dest)  
    closeTestPattern()     
    
    selectScreenDestination(1,"List")
    renameDestinationScreen("Automation",1)
    verifyDestinationScreenNameOnOpenedTab("Automation")
    selectScreenDestination(2,"List")
    renameDestinationScreen("Testing",2)
    verifyDestinationScreenNameOnOpenedTab("Testing")

   
    openTestPattern()
    destlist = ["Automation","Testing"]
    for dest in destlist:
        selectDestinationForTestPattern(dest)  