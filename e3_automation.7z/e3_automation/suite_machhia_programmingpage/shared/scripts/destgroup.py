from objectmaphelper import *

barco_Inc_Event_Master_Toolset_Overlay = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "type": "Overlay", "unnamed": 1, "visible": True}
defaultDestGroupLabel = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDefaultText", "type": "CustomText", "visible": True}
destgroupPlusBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objAddButton", "type": "CustomBorderIconButton", "visible": True}
destgroupListObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objGroupTab", "type": "Rectangle", "visible": True}
deleteGroup = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Delete Group", "type": "CustomText", "unnamed": 1, "visible": True}
overwriteGroup = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Overwrite Group", "type": "CustomText", "unnamed": 1, "visible": True}
duplicateGroup = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Duplicate Group", "type": "CustomText", "unnamed": 1, "visible": True}
renameGroup = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Rename Group", "type": "CustomText", "unnamed": 1, "visible": True}
editModeGroup = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}


def verifyDefaultDestGroup():
    objectExist(defaultDestGroupLabel)

def createAndVerifyDestGroup(numberofDestGroup):
    for i in range(1,numberofDestGroup+1):
        oc = len(findAllObjects(destgroupListObj)) + 1
        destgroupObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objGroupTab", "occurrence": oc, "type": "Rectangle", "visible": True}
        click(destgroupPlusBtn)
        if(oc < 11):
            objectExist(destgroupObj)
        else:
            verifyStatusBar("Max dest group limit reached")

def clickAndVerifyAllBlankDestGroup():
    oc = len(findAllObjects(destgroupListObj))
    pgmallDestObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objProgramCanvasAreaRoot", "type": "ProgramCanvasArea", "visible": True}
    pvwallDestObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "type": "PreviewCanvasArea", "unnamed": 1, "visible": True}
    
    destcountPGM = len(findAllObjects(pgmallDestObj))
    destcountPVW = len(findAllObjects(pvwallDestObj))

    while(oc > 0):
        destgroupObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objGroupTab", "occurrence": oc, "type": "Rectangle", "visible": True}
        oc -= 1
        click(destgroupObj)
        test.compare(len(findAllObjects(pgmallDestObj)), destcountPGM)
        test.compare(len(findAllObjects(pvwallDestObj)), destcountPVW)
    
    click(viewAllObj)
    test.compare(len(findAllObjects(pgmallDestObj)), destcountPGM)
    test.compare(len(findAllObjects(pvwallDestObj)), destcountPVW)
    
def deleteGroup(groupName):
    groupNameObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "text": str(groupName), "type": "CustomText", "visible": True}
    oc = getObjectPropety(groupNameObj, "occurrence")
    arrowObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "icon", "source": Wildcard("images/svgImages/downArrow.svg"),"occurrence": str(oc), "type": "Image", "unnamed": 1, "visible": True}
    click(arrowObj)   
    click(deleteGroup) 
    objectNotExist(groupNameObj)
        
def deleteAllGroup():
    if not (objectExist(defaultDestGroupLabel)):
        arrowListObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "icon", "source": Wildcard("images/svgImages/downArrow.svg"), "type": "Image", "unnamed": 1, "visible": True}
        oc = len(findAllObjects(arrowListObj))   
        while(oc > 0):
            arrowObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "icon", "source": Wildcard("images/svgImages/downArrow.svg"),"occurrence": str(oc), "type": "Image", "unnamed": 1, "visible": True}
            oc -= 1
            click(arrowObj)
            snooze(1)
            click(deleteGroup)  
        verifyDefaultDestGroup()
       
def overwriteGroup(groupName,groupNumber):
    groupNameObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "text": str(groupName), "type": "CustomText", "visible": True}
    click(groupNameObj)
    arrowObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objArrowbtn", "occurrence": str(groupNumber), "type": "CustomBorderIconButton", "visible": True}
    click(arrowObj)   
    click(overwriteGroup) 

#def verifyoverwriteGroup(groupName,destCount,list):
def verifyoverwriteGroup(groupName,destCount):
    pgmallDestObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objProgramCanvasAreaRoot", "type": "ProgramCanvasArea", "visible": True}
    pvwallDestObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "type": "PreviewCanvasArea", "unnamed": 1, "visible": True}
    groupNameObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "text": str(groupName), "type": "CustomText", "visible": True}

    destcountPGM = len(findAllObjects(pgmallDestObj))
    destcountPVW = len(findAllObjects(pvwallDestObj))
    
    click(viewAllObj)
    test.compare(len(findAllObjects(pgmallDestObj)), destcountPGM)
    test.compare(len(findAllObjects(pvwallDestObj)), destcountPVW)
    
    click(groupNameObj)
    test.compare(len(findAllObjects(pgmallDestObj)), destCount)
    test.compare(len(findAllObjects(pvwallDestObj)), destCount)
           
def duplicateGroup(groupName):
    groupNameObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "text": str(groupName), "type": "CustomText", "visible": True}
    oc = getObjectPropety(groupNameObj, "occurrence")
    arrowObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "icon", "source": Wildcard("images/svgImages/downArrow.svg"),"occurrence":oc, "type": "Image", "unnamed": 1, "visible": True}
    click(arrowObj)   
    click(duplicateGroup) 
    groupName = "Copy of " + groupName
    groupNameObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "text": str(groupName), "type": "CustomText", "visible": True}
    objectExist(groupNameObj)
    
def renameGroup(groupName,mode):        
    groupNameObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "text": str(groupName), "type": "CustomText", "visible": True}
    oc = getObjectPropety(groupNameObj, "occurrence")
    arrowObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "icon", "source": Wildcard("images/svgImages/downArrow.svg"),"occurrence":oc, "type": "Image", "unnamed": 1, "visible": True}
    if(str(mode).lower() == "viamenu"):            
        click(arrowObj)   
        click(renameGroup)
        click(editModeGroup)        
    elif(str(mode).lower() == "viadoubleclick"):
        doubleClick(groupNameObj)
    else:
        test.fail("mode undefined")    
    renamegroupName = "rename_" + groupName    
    updateText(editModeGroup,renamegroupName)
    objectNotExist(groupNameObj)
    renamegroupNameObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "text": str(renamegroupName), "type": "CustomText", "visible": True}
    objectExist(renamegroupNameObj)
    
def getListOfAllDestGroup():
    groupList = []
    oc = len(findAllObjects(destgroupListObj))
    while(oc > 0):
        destgroupObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objGroupTab", "occurrence": oc, "type": "Rectangle", "visible": True}
        #test.log(destgroupObj)
        oc -= 1
        test.log(getText(destgroupObj))
        groupList.append(getText(destgroupObj))
    return groupList

