testPatternHeader = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": Wildcard("Test*pattern"), "type": "CustomText", "unnamed": 1, "visible": True}
aoiToggleObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "aoiToggle", "type": "CustomToggleButton", "unnamed": 1, "visible": True}
opRasterToggleObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "opRasterToggle", "type": "CustomToggleButton", "unnamed": 1, "visible": True}
diagonalMotionToggleObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "diagonalMotionToggle", "type": "CustomToggleButton", "unnamed": 1, "visible": True}
o_QQuickWindowQmlImpl = {"type": "QQuickWindowQmlImpl", "unnamed": 1, "visible": True}
objTestPattern_ScrollView = {"container": o_QQuickWindowQmlImpl, "id": "objScrollView", "type": "ScrollView", "unnamed": 1, "visible": True}
objTestPatternInnerScrollBar = {"container": objTestPattern_ScrollView, "id": "vscrollbar", "orientation": 2, "type": "ScrollBar", "unnamed": 1, "visible": True}
testPatternDropDown = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objEnabledGradRect", "occurrence": 3, "type": "Rectangle", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_objOpScrollView_CustomScrollView = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objOpScrollView", "type": "CustomScrollView", "unnamed": 1, "visible": True}
testPatternSearchBox = {"container": o_QQuickWindowQmlImpl, "echoMode": 0, "objectName": "objTestPatternSelectionBoxSB", "type": "TextInput", "visible": True}


def openTestPattern():
    testPatternBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "testPatternBtn", "type": "Rectangle", "unnamed": 1, "visible": True}
    click(testPatternBtn)
    objectExist(testPatternHeader)
    
def closeTestPattern():
    closeTestPatternBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objImg", "source": Wildcard("images/mainWnd/icon_16_close.png"), "type": "CustomImage", "visible": True}
    closeTestPatternBtnObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objImg", "source": Wildcard("images/mainWnd/icon_16_close.png"),"occurrence": str(len(findAllObjects(closeTestPatternBtn))), "type": "CustomImage", "visible": True}
    click(closeTestPatternBtnObj)

def verifyCurrentTestPattern(pattern):
    testPatternCurrentObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": str(pattern), "type": "CustomText", "unnamed": 1, "visible": True}
    objectExist(testPatternCurrentObj) 
    
def expandShrinkTestPattern(mode):
    plusBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "icon", "occurrence": 3, "source": "qrc:/images/svgImages/plus.svg", "type": "Image", "unnamed": 1, "visible": True}
    minusBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "icon", "occurrence": 2, "source": "qrc:/images/svgImages/minus.svg", "type": "Image", "unnamed": 1, "visible": True}
    
    if(str(mode).strip().lower() == "expand"):
        if(objectExist(plusBtn)):
            click(plusBtn)     
    elif(str(mode).strip().lower() == "shrink"):
        if(objectExist(minusBtn)):
            click(minusBtn)     
    else:
        test.fail("mode undefined")

     
def setAndVerifyTestPattern(pattern):
    expandShrinkTestPattern("expand")
    testPatterns = {"container": objScrollView_ScrollView, "text": Wildcard(""), "type": "CustomText", "unnamed": 1, "visible": True}
    test.log(str(pattern))
    click(testPatternDropDown)         
    test.log("Total Test Patterns Count:" + str(len(findAllObjects(testPatterns))))
    for t in findAllObjects(testPatterns):
        #testPatternCurrentObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": str(t.text), "type": "CustomText", "unnamed": 1, "visible": True}
        test.log(str(t.text))              
        if(str(t.text) == "Vertical Steps"):
            #scrollTillObjVisible() // try once            
            mouseClick(waitForObject(objTestPatternInnerScrollBar), 7, 245, Qt.LeftButton)                
            test.log(str(t.text))
        if(str(t.text) == str(pattern)):
            if(str(t.text) == "Off"):
                mouseClick(waitForObject(objTestPatternInnerScrollBar), 7, 145, Qt.LeftButton)                
            click(t)
            click(testPatternDropDown)
            verifyCurrentTestPattern(str(t.text)) 
            return True
        else:
            click(t)
            click(testPatternDropDown)
            verifyCurrentTestPattern(str(t.text))

def selectDestinationForTestPattern(destname):
        expandShrinkTestPattern("expand")
        destOuterScrollBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objEnabledGradRect", "occurrence": 2, "type": "Rectangle", "unnamed": 1, "visible": True}
        destinationCollection = {"container": objScrollView_ScrollView, "text": Wildcard("*Dest*"), "type": "CustomText", "unnamed": 1, "visible": True}
        test.log(str(destname))
        click(destOuterScrollBar)         
        test.log("Total Destination Count:" + str(len(findAllObjects(destinationCollection))))
        for t in findAllObjects(destinationCollection): 
            test.log(str(t.text))         
            if(str(t.text) == str(destname)):
                click(t)
                return True            

def searchAndVerifyTestPattern(testPatternSearchBox, pattern):
    expandShrinkTestPattern("expand")
    #testPatternCurrentObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": str(pattern), "type": "CustomText", "unnamed": 1, "visible": True}
    test.log(str(pattern))
    click(testPatternOuterScrollBar) 
    click(testPatternSearchBox) 
    updateText(testPatternSearchBox, str(pattern))    
    verifyCurrentTestPattern(str(pattern))
       
def verifyAllOff():
    allOffObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objAllOff", "type": "Rectangle", "visible": True}
    testPatternOffObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Off", "type": "CustomText", "unnamed": 1, "visible": True}
    click(allOffObj)  
    objectExist(testPatternOffObj)
    
def verifyCircleAlignmentSettings(): 
    ledMode = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "ledToggle", "type": "CustomToggleButton", "unnamed": 1, "visible": True}
    gridSpacing1 = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "occurrence": 5, "type": "CustomText", "visible": True}
    gridSpacing2 = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "occurrence": 6, "type": "CustomText", "visible": True}
    gridWidth1pixel = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objRadioButton", "type": "RadioButton", "unnamed": 1, "visible": True}
    gridWidth2pixel = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objRadioButton", "type": "RadioButton", "occurrence": 2, "unnamed": 1, "visible": True}
    gridColorObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objEnabledGradRect", "occurrence": 4, "type": "Rectangle", "unnamed": 1, "visible": True}
    gridOrientationObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objEnabledGradRect", "occurrence": 5, "type": "Rectangle", "unnamed": 1, "visible": True}
    opEditBox = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    enableDisableToggle(ledMode,True)
    enableDisableToggle(ledMode,False)
    
    gridSpacingValue = 3000

    click(gridSpacing1) 
    updateText(opEditBox,gridSpacingValue)
    textMatch(new,gridSpacing1)
    
    click(gridSpacing2) 
    updateText(opEditBox,gridSpacingValue)
    textMatch(new,gridSpacing2)
    
    isRadioButtonChecked(gridWidth1pixel,True)
    isRadioButtonChecked(gridWidth1pixel,False)

    isRadioButtonChecked(gridWidth2pixel,True)
    isRadioButtonChecked(gridWidth2pixel,False)
     
    gridColorList = ["White","Red","Green","Blue"]
    for gridColor in gridColorList:
        searchAndVerifyTestPattern(gridColorObj, gridColor)
    
    gridOrientationList = ["Center","Top Left"]
    for gridOrientation in gridOrientationList:
        searchAndVerifyTestPattern(gridOrientationObj, gridOrientation)
