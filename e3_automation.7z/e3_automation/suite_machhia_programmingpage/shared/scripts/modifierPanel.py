barco_Inc_Event_Master_Toolset_objPreviewCanvasScrollArea_CustomScrollView = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objPreviewCanvasScrollArea", "occurrence": 2, "type": "CustomScrollView", "visible": True}
trans = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Trans", "type": "CustomText", "unnamed": 1, "visible": True}
cut   = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Cut", "type": "CustomText", "unnamed": 1, "visible": True}
arm   = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Arm", "type": "CustomText", "unnamed": 1, "visible": True}
matchPGM = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Match PGM", "type": "CustomText", "unnamed": 1, "visible": True}
clear = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": "Clear", "type": "CustomText", "unnamed": 1, "visible": True}
destinationObjArea = {"container": barco_Inc_Event_Master_Toolset_objPreviewCanvasScrollArea_CustomScrollView, "id": "objOutputScreenDestArea", "occurrence": 1, "type": "Rectangle", "unnamed": 1, "visible": True}