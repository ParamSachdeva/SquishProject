#import builtins

mainWindow = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
programmingTab = {"container": mainWindow, "id": "icon", "source": Wildcard("images/svgImages/programming.svg"), "type": "Image", "unnamed": 1, "visible": True}
allSourcesTab = {"container": mainWindow, "id": "allSources", "title": "All Sources", "type": "CustomTab", "unnamed": 1, "visible": True}
inputSection = {"container": allSourcesTab, "type": "ProgInputDelegate", "visible": True} 
sourceList = {"container": inputSection, "objectName": "objTextSourceName", "type": "CustomInputTextWithValidator", "visible": True}
inputsList = {"container": allSourcesTab, "id": "objBackupExpand", "type": "Rectangle", "visible": True}
mvrSection = {"container": allSourcesTab, "type": "ProgMVRDelegate", "unnamed": 1, "visible": True}
    

def verifyDropdownVals(inputName):
    test.log("Verifying backup dropdown values")
    inpNames = {"container": allSourcesTab, "objectName": "objTextInputName", "type": "CustomText", "visible": True}
    
    backupDrpdowmVals = []
    for i in findAllObjects(inpNames):
        backupDrpdowmVals.append(str(i.text))
    
    fields = ["None"]
    for i in backupDrpdowmVals:
        if not (i in inputName):
            fields.append(i)   
            
    nonfields = []
    for i in backupDrpdowmVals:
        if i not in fields:
            nonfields.append(i)
 
            
    for i in fields:
        fieldName = {"container": objScrollView_ScrollView, "text": i, "type": "CustomText", "unnamed": 1, "visible": True}
        objectExist(fieldName)
        
            
    for i in nonfields:
        fieldName = {"container": objScrollView_ScrollView, "text": i, "type": "CustomText", "unnamed": 1, "visible": True}
        objectNotExist(fieldName)
 
def selectValBackupList(i):
    o_QQuickWindowQmlImpl = {"type": "QQuickWindowQmlImpl", "unnamed": 1, "visible": True}
    objScrollView_ScrollView = {"container": o_QQuickWindowQmlImpl, "id": "objScrollView", "type": "ScrollView", "unnamed": 1, "visible": True}
    backUpNameObj = {"container": objScrollView_ScrollView, "occurrence":i , "type": "CustomText", "unnamed": 1, "visible": True}
    click(backUpNameObj)   
    
    
        
def verifyAutoSwitchToggle(enableFlag, toggleObj, backupBtn, radioBtn):
    test.log("Verifying the auto toggle functionality")
    
    if(enableFlag):    
        if (waitForObjectExists(toggleObj).m_bEnabled == False):
            click(toggleObj)
        test.verify(waitForObjectExists(toggleObj).m_bEnabled == True)
    elif not enableFlag:
        if not (waitForObjectExists(toggleObj).m_bEnabled == False):
            click(toggleObj)
        test.verify(waitForObjectExists(toggleObj).m_bEnabled == False)
        test.verify(waitForObjectExists(radioBtn).checked == False)
        click(radioBtn)
        test.verify(waitForObjectExists(radioBtn).checked == True)
        objectExist(backupBtn)
        isObjectEnable(backupBtn)
        

def setAllBackupsToNone():
    test.log("Setting the backups to \'None\'")
    for i in range(1,len(findAllObjects(inputsList))+1,1):
        inputSection = {"container": allSourcesTab, "type": "ProgInputDelegate", "visible": True}
        backupExpand = {"container": inputSection, "id": "objBackupExpand", "occurrence": i, "type": "Rectangle", "unnamed": 1, "visible": True}
        subsection = {"container": inputSection, "objectName": "objInputBackupLoader", "occurrence": i, "type": "CustomLoader", "visible": True}
        backup1 = {"container": subsection, "id": "objBackupSelectionBox", "occurrence": 1, "type": "BackupComboBox", "unnamed": 1, "visible": True}
        backup2 = {"container": subsection, "id": "objBackupSelectionBox", "occurrence": 2, "type": "BackupComboBox", "unnamed": 1, "visible": True}
        backup3 = {"container": subsection, "id": "objBackupSelectionBox", "occurrence": 3, "type": "BackupComboBox", "unnamed": 1, "visible": True}                
        click(backupExpand)
        scrollTillObjVisible(backup3, "All Sources", "vertical", "down", 460)
        if not (waitForObject(backup1).m_refSELECTED_TEXT == "None"):
            click(backup1)
            selectValBackupList(1)
        if not (waitForObject(backup2).m_refSELECTED_TEXT == "None"):
            click(backup2)
            selectValBackupList(1)
        if not (waitForObject(backup3).m_refSELECTED_TEXT == "None"):
            click(backup3)
            selectValBackupList(1)
                

def collapseBackupList():
    test.log("Collapsing Backup List")
    inputSection = {"container": allSourcesTab, "type": "ProgInputDelegate", "visible": True}
    subsections = {"container": inputSection, "objectName": "objInputBackupLoader", "type": "CustomLoader", "visible": True}
    num = len(findAllObjects(subsections))
    if not (num == 0):    
        for i in range(1,len(findAllObjects(inputsList))+1,1):
            backupExpand = {"container": inputSection, "id": "objBackupExpand", "occurrence": i, "type": "Rectangle", "unnamed": 1, "visible": True}
            scrollTillObjVisible(backupExpand, "All Sources", "vertical", "up", 460)
            click(backupExpand)
            test.verify(len(findAllObjects(subsections))==num-1,"Backup collapsed successfully")
            num=num-1
    else:
        test.log("Backups already collapsed")
        
    
def verifyInputBackupFields(numOfInputs):
    test.log("Verifying the backup fields in the input sub list")
    if(numOfInputs == "all"):
        loopLength = len(findAllObjects(inputsList))+1
    else:
        loopLength = numOfInputs+1
    for i in range(1,loopLength,1):
        inputSection = {"container": allSourcesTab, "type": "ProgInputDelegate", "visible": True}
        inputName = {"container": allSourcesTab, "objectName": "objTextInputName", "occurrence": i, "type": "CustomText", "visible": True}
        backupExpand = {"container": inputSection, "id": "objBackupExpand", "occurrence": i, "type": "Rectangle", "unnamed": 1, "visible": True}
        primaryToBackupBtn = {"container": inputSection, "id": "objBackupStateBtn", "occurrence": i, "type": "AddRemoveButton", "unnamed": 1, "visible": True}
        subsection = {"container": inputSection, "objectName": "objInputBackupLoader", "occurrence": i, "type": "CustomLoader", "visible": True}
        backupText = {"container": subsection, "text": "BACKUP", "type": "CustomText", "unnamed": 1, "visible": True}
        autoToggle = {"container": subsection, "objectName": "objAutoSwitchToggle", "type": "CustomToggleButton", "visible": True}
        backup1 = {"container": subsection, "id": "objBackupSelectionBox", "occurrence": 1, "type": "BackupComboBox", "unnamed": 1, "visible": True}
        backup2 = {"container": subsection, "id": "objBackupSelectionBox", "occurrence": 2, "type": "BackupComboBox", "unnamed": 1, "visible": True}
        backup3 = {"container": subsection, "id": "objBackupSelectionBox", "occurrence": 3, "type": "BackupComboBox", "unnamed": 1, "visible": True}                
        radioBtnBackup1 = {"container": subsection, "id": "objRadioButton", "occurrence": 1, "type": "RadioButton", "unnamed": 1, "visible": True}
        radioBtnBackup2 = {"container": subsection, "id": "objRadioButton", "occurrence": 2, "type": "RadioButton", "unnamed": 1, "visible": True}
        radioBtnBackup3 = {"container": subsection, "id": "objRadioButton", "occurrence": 3, "type": "RadioButton", "unnamed": 1, "visible": True}
        click(backupExpand)
        scrollTillObjVisible(mvrSection, "All Sources", "vertical", "down", 260)
        objectExist(backupText)
        objectExist(autoToggle)
        objectExist(backup1) 
        objectExist(backup2) 
        objectExist(backup3)
        click(backup1)
        verifyDropdownVals(str(waitForObjectExists(inputName).text))
        selectValBackupList(2)               
        click(backup2)
        verifyDropdownVals(str(waitForObjectExists(inputName).text))
        selectValBackupList(3)               
        click(backup3)
        verifyDropdownVals(str(waitForObjectExists(inputName).text))
        selectValBackupList(4)               
        verifyAutoSwitchToggle(False,autoToggle,primaryToBackupBtn,radioBtnBackup1)
        verifyAutoSwitchToggle(False,autoToggle,primaryToBackupBtn,radioBtnBackup2)
        verifyAutoSwitchToggle(False,autoToggle,primaryToBackupBtn,radioBtnBackup3)
        verifyAutoSwitchToggle(True,autoToggle,primaryToBackupBtn,None)
        click(backup1)
        selectValBackupList(1)
        click(backup2)
        selectValBackupList(1)
        click(backup3)
        selectValBackupList(1)        

def verifyInputList(numOfInputs):
    test.log("Verifying input list")
    if(numOfInputs.lower() == "all"):
        loopLength = len(findAllObjects(inputsList))+1
    else:
        loopLength = numOfInputs+1
    for i in range(1,loopLength,1):
        inputListSection = {"container": allSourcesTab, "objectName": "objCompositeHeaderRow", "occurrence": i, "type": Wildcard("WithSrcViewHdrDelegate"), "visible": True}
#         inputListSection ={"container": inputSection, "objectName": "objCompositeHeaderRow", "occurrence": i, "type": "InputWithSrcViewHdrDelegate", "visible": True}
        expandArrow = {"container": inputListSection, "objectName": "objImg", "source": Wildcard("images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
        backupBtn = {"container": inputListSection, "id": "objBackupStateBtn", "type": "AddRemoveButton", "unnamed": 1, "visible": True}
        refreshBtn = {"container": inputListSection, "objectName": "objRefreshIcon", "type": "CustomBorderIconButton", "visible": True}
        snowBtn = {"container": inputListSection, "objectName": "objFreezeIcon", "type": "CustomBorderIconButton", "visible": True}
        cameraBtn = {"container": inputListSection, "objectName": "objCaptureStillIcon", "type": "CustomBorderIconButton", "visible": True}
        frameRate = {"container": inputListSection, "objectName": "objTextInputName", "type": "CustomText", "visible": True}
        addSourceBtn = {"container": inputListSection, "objectName": "objAddNewSourceIcon", "type": "CustomBorderIconButton", "visible": True}
        
        click(expandArrow)
        objectExist(backupBtn)
        objectExist(refreshBtn)
        objectExist(snowBtn)
        objectExist(cameraBtn)
        objectExist(frameRate)
        objectExist(addSourceBtn)
        
        
def verifyBackupVals():
    test.log("Verifying the input sub list")
    ipName = ""
    for i in range(1,3,1):
        inputSection = {"container": allSourcesTab, "type": "ProgInputDelegate", "visible": True}
        inputName = {"container": allSourcesTab, "objectName": "objTextInputName", "occurrence": i, "type": "CustomText", "visible": True}
        backupExpand = {"container": inputSection, "id": "objBackupExpand", "occurrence": i, "type": "Rectangle", "unnamed": 1, "visible": True}
        subsection = {"container": inputSection, "objectName": "objInputBackupLoader", "occurrence": i, "type": "CustomLoader", "visible": True}
        backup1 = {"container": subsection, "id": "objBackupSelectionBox", "occurrence": 1, "type": "BackupComboBox", "unnamed": 1, "visible": True}
        backup2 = {"container": subsection, "id": "objBackupSelectionBox", "occurrence": 2, "type": "BackupComboBox", "unnamed": 1, "visible": True}
        backup3 = {"container": subsection, "id": "objBackupSelectionBox", "occurrence": 3, "type": "BackupComboBox", "unnamed": 1, "visible": True}
        click(backupExpand)
        if(i==1):
            ipName+=(str(waitForObjectExists(inputName).text))
            click(backup1)
            selectValBackupList(2)               
            click(backup2)
            selectValBackupList(3)               
            click(backup3)
            selectValBackupList(4)
        else:
            ipName+=(str(waitForObjectExists(inputName).text))
            click(backup1)
            verifyDropdownVals(ipName)
            selectValBackupList(1)  
            click(backup2)
            verifyDropdownVals(ipName)
            selectValBackupList(1)
            click(backup3)
            verifyDropdownVals(ipName)
            selectValBackupList(1)