barco_Inc_Event_Master_Toolset_Preset_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "title": "Preset", "type": "CustomTab", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_tabbar_TabBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "tabbar", "occurrence": 2, "type": "TabBar", "visible": True}
presetTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "Preset", "type": "CustomText", "unnamed": 1, "visible": True}
deletePresetBtn = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "icon", "source": Wildcard("/images/svgImages/delete.svg"), "type": "Image", "unnamed": 1, "visible": True}
expandPreset = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "icon", "source": Wildcard("/images/svgImages/rightArrow.svg"), "type": "Image", "unnamed": 1, "visible": True}
vscrollBarPreset = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "vscrollbar", "orientation": 2, "type": "ScrollBar", "unnamed": 1, "visible": True}    



def enableReorderPreset(count):
    reorderObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "icon", "source": Wildcard("images/svgImages/reoder.svg"), "type": "Image", "unnamed": 1, "visible": True}
    enableObject(reorderObj)
    #click(reorderObj)
    test.compare(str(len(findAllObjects(reorderObj))),str(count),"enableReorderPreset count")   

def createPreset(typeNumber,creationType,rename,lock,mode):       
    click(viewAllObj)
    typeObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "text": creationType, "type": "CustomText", "unnamed": 1, "visible": True}
    typenumberObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "objRadioButton", "occurrence": typeNumber, "type": "RadioButton", "unnamed": 1, "visible": True}
    renameObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "objCheckBox", "type": "CustomCheckBox", "unnamed": 1, "visible": True}
    lockObj   = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "objCheckBox", "occurrence": 2, "type": "CustomCheckBox", "unnamed": 1, "visible": True}
 
    click(presetTab)
    if(object.exists(expandPreset)):
        click(expandPreset)    
    click(typenumberObj)
    isRadioButtonChecked(typeObj,True)       
    if(rename):
        test.log(str(waitForObjectExists(renameObj).m_bState))
        if(str(waitForObjectExists(renameObj).m_bState) == "False"):
            click(renameObj)
        else:
            test.log("rename already checked")
    else:
        if(str(waitForObjectExists(renameObj).m_bState) == "True"):
            click(renameObj)
        else:
            test.log("rename already unchecked")
    
    if(lock):
        test.log(str(waitForObjectExists(lockObj).m_bState))
        if(str(waitForObjectExists(lockObj).m_bState) == "False"):
            click(lockObj)
        else:
            test.log("lock already checked")       
    else:
        if(str(waitForObjectExists(lockObj).m_bState) == "True"):
            click(lockObj)
        else:
            test.log("lock already unchecked")

    saveAndVerifyPresetType(mode,creationType)
    verifyPresetLocked(lock)
    verifyPresetRename(rename)
    

def moveAndVerifyPreset(sourcePresetnumber,destinationPresetnumber,MovedNumber):
    presetNamesourceobj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "objectName": "objDisplayedText", "occurrence": str(sourcePresetnumber*2), "type": "CustomText", "visible": True} 
    presetNamedestinationobj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "objectName": "objDisplayedText", "occurrence": str(destinationPresetnumber*2), "type": "CustomText", "visible": True} 
    movedNamePresetNumber = destinationPresetnumber*2-2
    movedNumberPresetNumber = destinationPresetnumber*2-1
    presetNameMovedobj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "objectName": "objDisplayedText", "occurrence": movedNamePresetNumber, "type": "CustomText", "visible": True} 
    presetNumberMovedobj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "objectName": "objDisplayedText", "occurrence": movedNumberPresetNumber, "type": "CustomText", "visible": True} 

    dragAndDropObj(presetNamesourceobj, presetNamedestinationobj, "")    
    verifyText(presetNamedestinationobj,"Preset " + str(destinationPresetnumber/2) + ".00")
    verifyText(presetNameMovedobj,"Preset " + str(sourcePresetnumber/2) + ".00")
    verifyText(presetNumberMovedobj,str(MovedNumber))
     
def saveAndVerifyPresetType(mode,creationType):
    test.log("saveAndVerifyPresetType: "+ str(creationType))
    presetListObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab,"text": str(creationType[0]), "type": "CustomText", "unnamed": 1, "visible": True}
    saveObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "text": "Save from " + mode, "type": "CustomText", "unnamed": 1, "visible": True}
    oc = len(findAllObjects(presetListObj))+1         
    presetTypeObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "occurrence": oc, "text": str(creationType[0]), "type": "CustomText", "unnamed": 1, "visible": True}
    statusBarObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objStatusBarText", "type": "CustomText", "visible": True}

    click(saveObj)
    snooze(0.25)
    textMatch("Preset",statusBarObj)   
    textMatch("saved",statusBarObj) 
    objectExist(presetTypeObj)
    
def verifyPresetLocked(lock):
    test.log("verifyPresetLocked: "+ str(lock))
    locObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "icon", "source": Wildcard("images/svgImages/lock_filled2.svg"), "type": "Image", "unnamed": 1, "visible": True}
    unlockObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "icon","source": Wildcard("images/svgImages/unlock.svg"), "type": "Image", "unnamed": 1, "visible": True}
    if(lock):
        oc = len(findAllObjects(locObj))
        locObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab,"occurrence": oc, "id": "icon", "source": Wildcard("images/svgImages/lock_filled2.svg"), "type": "Image", "unnamed": 1, "visible": True}
        objectExist(locObj)
    else:
        oc = len(findAllObjects(unlockObj))
        unlockObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab,"occurrence": oc, "id": "icon","source": Wildcard("images/svgImages/unlock.svg"), "type": "Image", "unnamed": 1, "visible": True}
        objectExist(unlockObj)

def verifyPresetRename(rename):
    test.log("verifyPresetRename: "+ str(rename))
    renameObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    if(rename):
        objectExist(renameObj)
    else:
        objectNotExist(renameObj)
        
def deleteallPreset():
    click(presetTab)
    if(object.exists(expandPreset)):
        click(expandPreset)  
    presetObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "objPresetRectangle", "type": "Rectangle", "unnamed": 1, "visible": True}
    keyPress("<Ctrl>")
    test.log(str(len(findAllObjects(presetObj))))
    for i in range(1,len(findAllObjects(presetObj)),1):
        preset = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "objPresetRectangle","occurrence": i, "type": "Rectangle", "unnamed": 1, "visible": True}
        scrollDown(vscrollBarPreset)     
        click(preset)
    keyRelease("<Ctrl>")
    click(deletePresetBtn)

def selectPreset(presetNumber):
    presetObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "objPresetRectangle", "occurrence": presetNumber, "type": "Rectangle", "unnamed": 1, "visible": True}       
    click(presetObj)
    
def recallPreset(mode,state):
    recallObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "text": "Recall " + str(mode), "type": "CustomText", "unnamed": 1, "visible": True}
    if(str(state).lower() == "enable"):
        isObjectEnable(recallObj)
        click(recallObj)
    elif(str(state).lower() == "disable"):
        isObjectDisable(recallObj)
    else:
        test.fail("state undefined")

def overwritePreset(presetNumber,overwriteMode,unlock): 
    presetObj = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "id": "objPresetRectangle", "occurrence": presetNumber, "type": "Rectangle", "unnamed": 1, "visible": True}
    overwrite = {"container": barco_Inc_Event_Master_Toolset_Preset_CustomTab, "text": "Overwrite from " + str(overwriteMode), "type": "CustomText", "unnamed": 1, "visible": True}
    click(presetObj)   
    if(unlock):
        isObjectEnable(overwrite)        
        click(overwrite)
        verifyStatusBar("Preset #" +str(presetNumber) + ".00 overwritten")
        click(viewAllObj)
        recallPreset()
        isDestinationArmUnArm("ScreenDest0",True)
        isDestinationArmUnArm("ScreenDest1",False)
    else:
        isObjectDisable(presetNumber)    