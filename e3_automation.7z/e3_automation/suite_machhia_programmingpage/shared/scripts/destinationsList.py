mainWindow = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
configTab = {"container": mainWindow, "id": "icon", "source": Wildcard("images/svgImages/configuration"), "type": "Image", "unnamed": 1, "visible": True}
programmingTab = {"container": mainWindow, "id": "icon", "source": Wildcard("images/svgImages/programming.svg"), "type": "Image", "unnamed": 1, "visible": True}
allSourcesTab = {"container": mainWindow, "id": "allSources", "title": "All Sources", "type": "CustomTab", "unnamed": 1, "visible": True}
destSection = {"container": allSourcesTab, "type": "ProgDestinationsDelegate", "visible": True} 
destList = {"container": destSection, "objectName": "objCompositeHeaderRow", "type": "DestWithSrcViewHdrDelegate", "visible": True}
sourceList = {"container": destSection, "objectName": "objTextSourceName", "type": "CustomInputTextWithValidator", "visible": True}
mvrSection = {"container": allSourcesTab, "type": "ProgMVRDelegate", "unnamed": 1, "visible": True}

        
def verifyDestList(numOfInputs):
    test.log("Verifying input list")
    if(numOfInputs.lower() == "all"):
        loopLength = len(findAllObjects(inputsList)) + 1
    else:
        loopLength = numOfInputs + 1
    for i in range(1, loopLength, 1):
        destListSection = {"container": allSourcesTab, "objectName": "objCompositeHeaderRow", "occurrence": i, "type": Wildcard("WithSrcViewHdrDelegate"), "visible": True}
#         destListSection = {"container": destSection, "objectName": "objCompositeHeaderRow", "occurrence": i, "type": "DestWithSrcViewHdrDelegate", "visible": True}
        expandArrow = {"container": destListSection, "objectName": "objImg", "source": Wildcard("images/svgImages/downArrow"), "type": "CustomImage", "visible": True}
        backupBtn = {"container": destListSection, "id": "objBackupStateBtn", "type": "AddRemoveButton", "unnamed": 1, "visible": True}
        refreshBtn = {"container": destListSection, "objectName": "objRefreshIcon", "type": "CustomBorderIconButton", "visible": True}
        snowBtn = {"container": destListSection, "objectName": "objFreezeIcon", "type": "CustomBorderIconButton", "visible": True}
        cameraBtn = {"container": destListSection, "objectName": "objCaptureStillIcon", "type": "CustomBorderIconButton", "visible": True}
        frameRate = {"container": destListSection, "objectName": "objVideoFormatName", "type": "CustomText", "visible": True}
        addSourceBtn = {"container": destListSection, "objectName": "objAddNewSourceIcon", "type": "CustomBorderIconButton", "visible": True}
        
        click(expandArrow)
        objectNotExist(backupBtn)
        objectNotExist(refreshBtn)
        objectNotExist(snowBtn)
        objectNotExist(cameraBtn)
        objectExist(frameRate)
        objectExist(addSourceBtn)

        
def verifyRenameDeleteDest(myDestName, operation):
    test.log("Verifying " + operation + " operation")
    destNames = {"container": allSourcesTab, "objectName": "objTextScreenDestName", "type": "CustomText", "visible": True}
    destNameList = []
    for i in findAllObjects(destNames):
        destNameList.append(str(i.text))
    
    if(operation.lower() == "rename"):    
        if myDestName not in destNameList:
            test.fail("Renamed destination \'" + myDestName + "\' is not present in destination list")
    elif(operation.lower() == "delete"):
        if myDestName in destNameList:
            test.fail("Deleted destination \'" + myDestName + "\' is present in destination list")         

    
def selectDestination(destinationNumber):
    objDestinationCheckBox = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objCheckbox", "occurrence": destinationNumber, "type": "Rectangle", "unnamed": 1, "visible": True}
    click(objDestinationCheckBox)


def isDestinationArmUnArm(destinationName,mode):
    #previewCanvasArea = {"container": barco_Inc_Event_Master_Toolset_PreviewCanvasArea, "id": "objPreviewRectArea", "type": "PreviewRectArea", "unnamed": 1, "visible": True}
    #destinationobj = {"container": previewCanvasArea, "text": str(destinationNumber), "type": "CustomText", "unnamed": 1, "visible": True}
    destinationobj = {"container": barco_Inc_Event_Master_Toolset_PreviewCanvasArea, "text": str(destinationNumber), "type": "CustomText", "unnamed": 1, "visible": True}
    if (waitForObjectExists(destinationobj).parent.parent.parent.parent.modDestUi.isActive.value == mode):
    #if (waitForObjectExists(destinationobj).modDestUi.isActive.value == True):
        test.log("Destination isDestinationArmUnArm: " + str(mode) +  str(obj))
        return True 
    else:
        test.fail("Destination isDestinationArmUnArm: " + str(mode) +  str(obj))
        return False