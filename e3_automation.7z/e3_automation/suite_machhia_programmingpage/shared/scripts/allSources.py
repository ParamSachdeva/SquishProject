mainWindow = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
allSourcesTab = {"container": mainWindow, "id": "allSources", "title": "All Sources", "type": "CustomTab", "unnamed": 1, "visible": True}


def selectViewType(listHeaderName, viewType):
    test.log("Selecting View: "+ viewType)
    expandList(listHeaderName)
    thumbnailView = {"container": allSourcesTab, "id": "icon", "source": Wildcard("images/svgImages/thumbnail.svg"), "type": "Image", "unnamed": 1, "visible": True}
    cueView = {"container": allSourcesTab, "id": "icon", "source": Wildcard("images/svgImages/cue.svg"), "type": "Image", "unnamed": 1, "visible": True}
    thumbnailImg = {"container": allSourcesTab, "id": "objThumbImageBox", "type": "Rectangle", "unnamed": 1, "visible": True}
    
    if(viewType.lower() == "list" or viewType.lower() == "cue"):
        if (object.exists(thumbnailView)):
            click(thumbnailView)
        objectNotExist(thumbnailImg)
    elif(viewType.lower() == "thumbnail"):
        if (object.exists(cueView)):
            click(cueView)
        objectExist(thumbnailImg)       
    
    
def expandList(listHeaderName):
    test.log("Expanding List : "+ listHeaderName)    
    type = "Prog"+listHeaderName+"Delegate"
    section = {"container": allSourcesTab, "type": type, "visible": True}
    drpdwnArrow = {"container": section, "objectName": "objImg", "source": Wildcard("images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}  
    expandedColumns = {"container": section, "id": "objDropDownSubListLoader", "type": "CustomLoader", "unnamed": 1, "visible": True}
    
    
    while (object.exists(expandedColumns)):
        click(drpdwnArrow)
    objectNotExist(expandedColumns)

    if not (object.exists(expandedColumns)):
        click(drpdwnArrow)
    objectExist(expandedColumns)


def deleteSources(sourceVal,sourceList):
    deleteBtn = {"container": allSourcesTab, "id": "icon", "source": Wildcard("images/svgImages/delete.svg"), "type": "Image", "unnamed": 1, "visible": True}
    
    j=0
    if(sourceVal.lower() == "all"):
        if not (len(findAllObjects(sourceList)) == 0):
#             multiSelectList(sourceList, "All Sources",1) #commented as the multi select is not working on 09'dec'22 build
            for i in findAllObjects(sourceList):
                test.log("Deleting "+str(len(findAllObjects(sourceList)))+" sources")
                click(i)
                click(deleteBtn)
            if not (len(findAllObjects(sourceList)) == 0):
                    test.fail("Unable to delete the destination")
                    raise Exception("Unable to delete the destination")
            else:
                    test.log("Destination(s) deleted successfully")      
    elif(sourceVal.lower() != "null"):
        lengthOfSources = len(findAllObjects(sourceList))-1
        sourceNameObj = {"container": allSourcesTab, "objectName": "objDisplayedText", "text": sourceVal, "type": "CustomText", "visible": True}
        if(len(findAllObjects(sourceList)) != 0):
            i=1    
            while(i<10):
                try:
                    click(sourceNameObj)
                    break
                except:
                    scrollListInsideTab("All Sources", "vertical", "down", 360)
                    i=i+1
            click(deleteBtn)
            if(len(findAllObjects(sourceList)) != lengthOfSources):
                    test.fail("Unable to delete the destination")
                    raise Exception("Unable to delete the destination")
            else:
                    test.log("Destination(s) deleted successfully")  
        
    else:
        test.fail("Invalid destination value, acceptable parameters are \'all\' or \'destination name\'")
        raise Exception("Invalid destination value, acceptable parameters are \'all\' or \'destination name\'")       


def addCopy(obj,listObj,times,operation):
    num = 0
    for i in range (times):
        num+=1
        click(obj)
    if(operation.lower()=="add"):
        if not(len(findAllObjects(listObj)) == num):
            test.fail("Unable to add destination")
    elif(operation.lower()=="copy"):
        if not(len(findAllObjects(listObj)) == num+1):
            test.fail("Unable to copy destination")


def verifySourceList(parentObj,listObj,sourceName,operation):
    test.log("Verifying source list for "+operation+" operation")
    parentName = str((waitForObjectExists(parentObj).id))
    num=0
    skipFirst=0
    for i in findAllObjects(listObj):
        skipFirst+=1
        if "Destinations" in parentName:
            if(operation.lower() == "add"):
                num+=1
                compareTwoTexts(str(i.m_refDisplayedText.text),sourceName+"_PGM-"+str(num))
            elif(operation.lower() == "copy" and skipFirst==2):
                compareTwoTexts(str(i.m_refDisplayedText.text),sourceName+"_PGM-1"+"_copy")   
        elif "Input" in  parentName:
            if(operation.lower() == "add"):
                num+=1
                compareTwoTexts(str(i.m_refDisplayedText.text),sourceName+"-"+str(num))  
            elif(operation.lower() == "copy" and skipFirst==2):
                compareTwoTexts(str(i.m_refDisplayedText.text),sourceName+"-1_copy")
                
    
def verifyAddCopySource(parentObj,listObj, sourceName, operation,num):
    test.log("Adding/Copying source")
    for i in range(1,2,1):
        addSourceBtn = {"container": parentObj, "objectName": "objAddNewSourceIcon", "type": "CustomBorderIconButton", "visible": True}
        copySourceBtn = {"container": parentObj, "id": "icon", "source": Wildcard("images/svgImages/copy.svg"), "type": "Image", "unnamed": 1, "visible": True}
        if(operation.lower() == "add"):
            addCopy(addSourceBtn,listObj,num,operation)
            verifySourceList(parentObj,listObj,sourceName,operation)
        elif(operation.lower() == "copy"):
            addCopy(copySourceBtn,listObj,num,operation)
            verifySourceList(parentObj,listObj,sourceName,operation)
    
    