# from _winreg import *

layoutPlusBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objLayoutAddIcon", "type": "CustomBorderIconButton", "visible": True}
defaultLayoutLabel = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "layoutPlaceholderText", "type": "Label", "visible": True}
emptyLayoutHeading = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objEmptyLayoutHeading", "type": "Label", "visible": True}
emptyLayoutMsg = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objEmptyLayoutMessage", "type": "Label", "visible": True}
barco_Inc_Event_Master_Toolset_objProgramCanvasAreaRoot_ProgramCanvasArea = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objProgramCanvasAreaRoot", "type": "ProgramCanvasArea", "visible": True}
barco_Inc_Event_Master_Toolset_PreviewCanvasArea = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "type": "PreviewCanvasArea", "unnamed": 1, "visible": True}
layoutListObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objLayoutTab", "type": "Rectangle", "visible": True}


def clickLayout(oc):
    layoutObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objLayoutTab", "occurrence": oc, "type": "Rectangle", "visible": True}
    click(layoutObj)

    
def createAndVerifyLayouts(numberofLayout):
    for i in range(1,numberofLayout+1):
        oc = len(findAllObjects(layoutListObj)) + 1
        layoutObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objLayoutTab", "occurrence": oc, "type": "Rectangle", "visible": True}
            
        click(layoutPlusBtn)
        if(oc < 11):
            objectExist(layoutObj)
        else:
            verifyStatusBar("Max limit exceeded, Please delete old layout to create new one.")


def verifyDefaultLayout():
    objectExist(defaultLayoutLabel)


def clickAndVerifyAllBlankLayouts():
    oc = len(findAllObjects(layoutListObj))    
    while(oc > 0):
        layoutObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objLayoutTab", "occurrence": oc, "type": "Rectangle", "visible": True}
        oc -= 1
        click(layoutObj)
        compareTwoTexts(getText(emptyLayoutHeading), "No Destination(s) assigned")
        compareTwoTexts(getText(emptyLayoutMsg), "Drag any screen destination into this area to organise your content ") 
        compareTwoTexts(getText(emptyLayoutMsg), 'or drop at the "Layout" tabs at bottom')


def dropDestOnLayout(destName, layoutNumber, dropArea):
    destObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objTabName", "text": str(destName).strip(), "type": "CustomText", "visible": True}
    layoutObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objDisplayedText", "text": "Layout " + str(layoutNumber), "type": "CustomText", "visible": True}
            
    if(dropArea.strip().lower() == "center"):
        drag(destObj, getWidthofWindow()/2, getHightofWindow()/4)   
    elif(dropArea.strip().lower() == "layout"): 
        dragAndDropObj(destObj, layoutObj, "")
    else:
        fail("drop Area is missing")

    
def verifyallDestDroppedOnLayout(DestType, DestCount):
    pgmallDestObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objProgramCanvasAreaRoot", "type": "ProgramCanvasArea", "visible": True}
    pvwallDestObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "type": "PreviewCanvasArea", "unnamed": 1, "visible": True}

    test.compare(len(findAllObjects(pgmallDestObj)), DestCount)
    test.compare(len(findAllObjects(pvwallDestObj)), DestCount)

    for i in range(1, len(findAllObjects(pgmallDestObj)) + 1):
        pvwarea = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "occurrence": i, "type": "PreviewCanvasArea", "unnamed": 1, "visible": True}
        pgmarea = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "occurrence": i, "objectName": "objProgramCanvasAreaRoot", "type": "ProgramCanvasArea", "visible": True}
        pgmDestObj = {"container": pgmarea, "text": Wildcard(str(DestType)), "type": "CustomText", "unnamed": 1, "visible": True}
        pvwDestObj = {"container": pvwarea, "text": Wildcard(str(DestType)), "type": "CustomText", "unnamed": 1, "visible": True}
        test.verify(isObjectEnable(pgmDestObj), getText(pgmDestObj) + " enable on PGM section")
        test.verify(isObjectEnable(pvwDestObj), getText(pvwDestObj) + " enable on PVW section")

        
def verifyLayoutInRegistry(layoutNumber):
    aReg = ConnectRegistry(None, HKEY_CURRENT_USER)
    test.log("SOFTWARE\Barco Electronics Systems (P) Ltd\Macchia" + "\\" + ip_address + "\Layout_" + str(layoutNumber))
    aKey = OpenKey(aReg, r"SOFTWARE\Barco Electronics Systems (P) Ltd\Macchia" + "\\" + ip_address + "\Layout_" + str(layoutNumber) + "\\")
    for i in range(1024):
        try:
            keyname = EnumKey(aKey, i)
            asubkey = OpenKey(aKey, keyname)
            val = QueryValueEx(asubkey, "DisplayName")
            test.log(val)
        except WindowsError:
            break

        
def deleteLayoutRegistry():
    ConnectRegistry(None, HKEY_CURRENT_USER)
    test.log('SOFTWARE\Barco Electronics Systems (P) Ltd\Macchia' + '\\' + str(ip_address))
    OpenKey(HKEY_CURRENT_USER, r'SOFTWARE\Barco Electronics Systems (P) Ltd\Macchia' + '\\' + str(ip_address), 0, KEY_ALL_ACCESS)
    DeleteKey(OpenKey(HKEY_CURRENT_USER, r'SOFTWARE\Barco Electronics Systems (P) Ltd\Macchia', ip_address))
