mainWindow = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
previewArea = {"container": mainWindow, "type": "PreviewCanvasArea", "unnamed": 1, "visible": True}
programArea = {"container": mainWindow, "objectName": "objProgramCanvasAreaRoot", "type": "ProgramCanvasArea", "visible": True}
clearBtn = {"container": mainWindow, "text": "Clear", "type": "CustomText", "unnamed": 1, "visible": True}
previewScreenArea = {"container": previewArea, "id": "objPrevScrDestArea", "type": "ScreenDestArea", "unnamed": 1, "visible": True}
programScreenArea = {"container": programArea, "id": "objPgmScreenDestArea", "type": "ScreenDestArea", "unnamed": 1, "visible": True}
viewAllObj = {"container": mainWindow, "objectName": "objTabName", "text": "View All", "type": "CustomText", "visible": True}
centerPanel = {"container": mainWindow, "objectName": "objProgramCentralPanel", "type": "ProgCentralPanel", "visible": True}

def dragToProg(obj,dropLayerOcc):
    test.log("Dropping layer to Program")
    droppedLayer = {"container": previewArea, "id": "objLayerImage", "occurrence": dropLayerOcc, "source": Wildcard("/images/generalImages/g13_layerUiFront.png"), "type": "Image", "unnamed": 1, "visible": True}
    dragAndDropObj(obj,programScreenArea,droppedLayer)
     
     
def dragToPrev(obj,dropLayerOcc):
    test.log("Dropping layer to Preview")
    droppedLayer = {"container": previewArea, "id": "objLayerImage", "occurrence": dropLayerOcc, "source": Wildcard("/images/generalImages/g13_layerUiFront.png"), "type": "Image", "unnamed": 1, "visible": True}
    dragAndDropObj(obj,previewScreenArea,droppedLayer)
    
def shuffleDestination(fromDestName,onDestName):
    test.log("Shuffling layer")
    topDestList = {"container": centerPanel, "text":Wildcard("Destination"),"objectName": "objTabName", "type": "CustomText", "visible": True}
    programDestList = {"container": centerPanel,"type": "ProgramCanvasArea", "visible": True}
    previewDestList = {"container": centerPanel, "type": "PreviewCanvasArea", "visible": True}
    
    #list of destination before shuffling
    listOnTop = getDestinationList(topDestList,top=True)
    listOnProgram = getDestinationList(programDestList,program=True)
    listOnPreview = getDestinationList(previewDestList,preview=True)
    
    #performing shuffle
    fromDest = {"container": centerPanel, "objectName": "objTabName","text": fromDestName ,"type": "CustomText", "visible": True}
    onDest = {"container": centerPanel, "objectName": "objTabName","text": onDestName ,"type": "CustomText", "visible": True}
    dragAndDropObj(fromDest, onDest)
    
    #list of destination after shuffling
    updatedListOnTop = getDestinationList(topDestList,top=True)
    updatedListOnProgram = getDestinationList(programDestList,program=True)
    updatedListOnPreview = getDestinationList(previewDestList,preview=True)
    
    test.verify(listOnTop!=updatedListOnTop,"Destination List before and after shuffling not matching on top")
    test.verify(listOnProgram!=updatedListOnProgram,"Destination List before and after shuffling not matching on program")
    test.verify(listOnPreview!=updatedListOnPreview,"Destination List before and after shuffling not matching on preview")
    test.verify(updatedListOnTop==updatedListOnProgram==updatedListOnPreview,"Destination List on top, program and preview are matching")
        
def getDestinationList(commonLocator,top=None,program=None,preview=None):
    test.log("Getting list of destinations")
    list = []
    if(top):
        for i in findAllObjects(commonLocator):
            list.append(str(i.text))
        return list;
    if(program):
        for i in range(1,len(findAllObjects(commonLocator))+1,1):
            updateContainer = {"container": centerPanel,"occurrence":i,"type": "ProgramCanvasArea", "visible": True}
            destinationObj = {"container": updateContainer, "type": "CustomText", "unnamed": 1, "visible": True}
            list.append(str(waitForObject(destinationObj).text))
        return list;
    if(preview):
        for i in range(1,len(findAllObjects(commonLocator))+1,1):
            updateContainer = {"container": centerPanel,"occurrence":i,"type": "PreviewCanvasArea", "visible": True}
            destinationObj = {"container": updateContainer, "type": "CustomText", "unnamed": 1, "visible": True}
            list.append(str(waitForObject(destinationObj).text))
        return list;
   
def clickLayer(layerArea,screenOcc,layerOcc):
    if(str(layerArea) == "PVW"):            
        layerAreaObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objPreviewCanvasScrollArea", "occurrence": screenOcc, "type": "CustomScrollView", "visible": True}
    elif(str(layerArea) == "PGM"):  
        layerAreaObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objProgramCanvasScrollArea", "occurrence": screenOcc, "type": "CustomScrollView", "visible": True}
    else:
        test.fail("Define Layer Area")
    layerobj = {"container": layerAreaObj, "id": "objSelectionBorderRect", "type": "Rectangle", "occurrence": layerOcc, "unnamed": 1, "visible": True}
    click(layerobj)
    