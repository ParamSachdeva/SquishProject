source(findFile("scripts", "initialize.py"))

def main():    
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(outputTab)
    click(screenTypeOutput)
    deleteDestinations('allonebyone')
    addScreenDestination(1)
    click(programmingTab)
    selectViewType("Input","list")
    expandList("Input")    
    dragToPrev(destinationObjArea,1)
    
    #Trans Verification
    clickLayer("PVW",1,1)
    click(trans)    
    clickLayer("PGM",1,1)
    