source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    openTestPattern()  
    selectDestinationForTestPattern("ScreenDest0") 
    zoomAlltabObj = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "outputRect", "type": "Rectangle", "unnamed": 1, "visible": True}
    aoiRect = {"container": barco_Inc_Event_Master_Toolset_objOpScrollView_CustomScrollView, "id": "objVirtualItem", "type": "Rectangle", "unnamed": 1, "visible": True}
    zoomIn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objZoomInButton", "occurrence": 2, "type": "CustomBorderIconButton", "visible": True}
    percentage = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "text": Wildcard("*%"), "type": "CustomText", "unnamed": 1, "visible": True}
    
    verifyZoomFunctionality(zoomAlltabObj,aoiRect)
    click(zoomIn)
    percent = getText(percentage)
    selectDestinationForTestPattern("ScreenDest1") 
    verifyText(percentage,percent)    