source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(programmingTab)
    #deleteAllGroup()
    createAndVerifyDestGroup(2)
    #list = getListOfAllDestGroup()
    #renameGroup(str(getListOfAllDestGroup()[0]))
    renameGroup("DestGroup 1","viamenu")
    renameGroup("DestGroup 1","viadoubleclick")