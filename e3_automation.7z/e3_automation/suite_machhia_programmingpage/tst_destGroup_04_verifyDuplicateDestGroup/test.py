source(findFile("scripts", "initialize.py"))

def main():
    launchEmulator()
    launchMacchia()
    disconnectAllSystem()
    connectEmulator()
    click(programmingTab)
    #deleteAllGroup()
    createAndVerifyDestGroup(2)
    selectDestination(1)
    duplicateGroup("DestGroup 1")   
    duplicateGroup("DestGroup 2")     