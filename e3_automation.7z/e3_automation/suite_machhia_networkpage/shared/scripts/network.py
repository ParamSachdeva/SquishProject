from objectmaphelper import *
from random import *


barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Overlay = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "type": "Overlay", "unnamed": 1, "visible": True}
outgoing_XML_Log_QQuickWindowQmlImpl = {"title": "Outgoing XML Log", "type": "QQuickWindowQmlImpl", "unnamed": 1, "visible": True}
objScrollView_ScrollView = {"container": o_QQuickWindowQmlImpl, "id": "objScrollView", "type": "ScrollView", "unnamed": 1, "visible": True}

ipObj = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}
subnet = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objDisplayedText", "occurrence": 2, "type": "CustomText", "visible": True}
gateway = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objDisplayedText", "occurrence": 3, "type": "CustomText", "visible": True}
currentIP = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objDisplayedText", "occurrence": 4, "type": "CustomText", "visible": True}
macAdd = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objDisplayedText", "occurrence": 5, "type": "CustomText", "visible": True}
editBox = {"container": barco_Inc_Event_Master_Toolset_Overlay, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}

applyBtn = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Apply Changes", "type": "CustomText", "unnamed": 1, "visible": True}
restoreBtn = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Restore Default", "type": "CustomText", "unnamed": 1, "visible": True}
cancelBtn = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Cancel", "type": "CustomText", "unnamed": 1, "visible": True}
restoreBtn = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Restore Default", "type": "CustomText", "unnamed": 1, "visible": True}
cancelBtn = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Cancel", "type": "CustomText", "unnamed": 1, "visible": True}
crossBtn  = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objOperatorImage", "source": Wildcard("/images/mainWnd/icon_16_close.png"), "type": "CustomImage", "visible": True}

headerText = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objTitleText", "type": "CustomText", "visible": True}
adjustTab = {"container": barco_Inc_Event_Master_Toolset_Overlay, "text": "Adjust Settings", "type": "CustomText", "unnamed": 1, "visible": True}
networkIcon = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objTitleImage", "source": Wildcard("/images/icon_24_network.png"), "type": "CustomImage", "visible": True}

outgoingXML = {"container": outgoing_XML_Log_QQuickWindowQmlImpl, "type": "Rectangle", "unnamed": 1, "visible": True}

def openNetworkPage():
    networkBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objNetworkButtonAddRemoveImageButton", "type": "Rectangle", "visible": True}
    click(networkBtn)

    
def closeNetworkPage():
    closeNetworkBtn = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objOperatorImage", "source": Wildcard("/images/mainWnd/icon_16_close.png"), "type": "CustomImage", "visible": True}
    click(closeNetworkBtn)


def networkRowDataValidation(rowNum, name, slot, connector, dhcpStatic, ip, bandwidth):    
    start = (rowNum*6)+ 1    
    list = [name, slot, connector, dhcpStatic, ip, bandwidth]
    for ls in list:         
        obj = {"container": barco_Inc_Event_Master_Toolset_Overlay, "occurrence": start, "type": "CustomText", "unnamed": 1, "visible": True}
        #test.log(str(waitForObjectExists(obj).text))
        #test.log(str(ls))
        start+=1
        verifyText(obj, str(ls))   

def setIPmode(mode):
    ipmodeDropDown = {"container": barco_Inc_Event_Master_Toolset_Overlay, "objectName": "objImg", "source": Wildcard("images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
    modeObj = {"container": objScrollView_ScrollView, "text": mode, "type": "CustomText", "unnamed": 1, "visible": True}
    click(ipmodeDropDown)
    click(modeObj) 
    wait(0.25)  
    

def randomIP():
    ip = "192.98." + str(randint(1, 255)) + "." + str(randint(1, 255)) 
    return str(ip)

def updateNetworkIP(obj,newIP):
    click(obj)    
    updateText(editBox,newIP) 
    textMatch(newIP, obj)