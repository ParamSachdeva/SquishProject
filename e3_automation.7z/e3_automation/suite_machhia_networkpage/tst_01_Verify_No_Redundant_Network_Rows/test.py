source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "network.py"))


def main():
    test.log("Verify Network Page rows Data")
    launchMacchia() 
    launchEmulator()  
    connectEmulator()   

    openNetworkPage()
    networkRowDataValidation(0, "Name", "Slot", "Connector", "DHCP/Static", "Current IP", "Bandwidth")
    networkRowDataValidation(1, "Control", "-", "1", "Static", ip_address, "NC")
    networkRowDataValidation(2, "Control", "-", "2", "Static", ip_address, "NC")
    #networkRowDataValidation(2, "Control", "-", "2", "N/A", ip_address, "N/A")