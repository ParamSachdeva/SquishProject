source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "network.py"))


def main():
    test.log("Verify_Syntax_And_Icons")
    launchMacchia()
    openNetworkPage()
    verifyText(headerText,"Network Settings")
    verifyText(adjustTab,"Adjust Settings")
    objectExist(networkIcon)