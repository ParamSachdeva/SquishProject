source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "network.py"))


def main():
    test.log("Verify_Restore_Default_Button_Feature")
    launchMacchia()
    openNetworkPage()
    setIPmode("Static")  
    click(restoreBtn)    
    isObjectDisable(restoreBtn)
    closeNetworkPage()
    openNetworkPage()    
    setIPmode("DHCP")  
    click(restoreBtn)    
    isObjectDisable(restoreBtn)