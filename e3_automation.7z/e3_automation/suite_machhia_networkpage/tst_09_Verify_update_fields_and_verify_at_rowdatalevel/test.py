source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "network.py"))


def main():
    test.log("Verify_update_fields_and_verify_at_rowdatalevel")
    launchMacchia() 
    launchEmulator()  
    connectEmulator()   
    openNetworkPage()
    setIPmode("Static") 
    click(applyBtn)
    #networkRowDataValidation(1, "Control", "-", "1", "Static", ip_address, "NC")
       
    rowNums = [1,2]
    for rowNum in rowNums:
        start = (rowNum*6)+ 1 
        randomIp = randomIP()
        obj = {"container": barco_Inc_Event_Master_Toolset_Overlay, "occurrence": start, "type": "CustomText", "unnamed": 1, "visible": True}
        click(obj)
        setIPmode("Static")      
        updateNetworkIP(ipObj,randomIp)
        updateNetworkIP(subnet,randomIp)
        updateNetworkIP(gateway,randomIp)
        click(applyBtn)
        networkRowDataValidation(rowNum, "Control", "-", str(rowNum), "Static", str(randomIp), "NC")
