source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "network.py"))


def main():
    test.log("Verify_when_network_mode_is_DHCP_then_other_fields_non_modifiable")
    launchMacchia()
    openNetworkPage()   
    setIPmode("DHCP")
    setIPmode("Static") 
    setIPmode("DHCP") 
    isObjectDisable(ipObj)
    isObjectDisable(subnet)
    isObjectDisable(gateway)
    isObjectDisable(currentIP)
    isObjectDisable(macAdd)