source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "network.py"))


def main():
    test.log("Verify_when_network_mode_is_Static_then_few_fields_non_modifiable")
    launchMacchia()
    openNetworkPage()
    setIPmode("Static") 
    setIPmode("DHCP") 
    setIPmode("Static") 
    isObjectEnable(ipObj)
    isObjectEnable(subnet)
    isObjectEnable(gateway)
    isObjectDisable(currentIP)
    isObjectDisable(macAdd)