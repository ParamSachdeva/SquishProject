source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "network.py"))


def main():
    test.log("Verify_Cancel_Button_Feature")
    launchMacchia()
    openNetworkPage()
    setIPmode("Static")  
    randomIp = randomIP()          
    updateNetworkIP(ipObj,randomIp)   
    objectExist(cancelBtn)
    click(cancelBtn)    
    objectNotExist(cancelBtn)