source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "network.py"))


def main():
    test.log("Verify_Cross_Button_Feature")
    launchMacchia()
    openNetworkPage()
    wait(0.25)
    objectExist(crossBtn)
    click(crossBtn)    
    objectNotExist(crossBtn)