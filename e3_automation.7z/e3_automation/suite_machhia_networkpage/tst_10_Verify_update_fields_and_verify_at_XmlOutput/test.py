source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "network.py"))


def main():
    test.log("Verify_update_fields_and_verify_at_XmlOutput")
    launchMacchia() 
    launchEmulator()  
    connectEmulator()   
    openNetworkPage()
    #networkRowDataValidation(1, "Control", "-", "1", "Static", ip_address, "NC")
    setIPmode("Static")
   
    randomIp = randomIP()    
    updateNetworkIP(ipObj,randomIp)
    updateNetworkIP(subnet,randomIp)
    updateNetworkIP(gateway,randomIp)

    openOutgoingXML() 
    click(applyBtn)
    
    outPutXML = str(waitForObject(outgoingXML).parent.text)    
    test.log(outPutXML)
    
    compareTwoTexts(outPutXML, "<StaticIP>" + randomIp + "</StaticIP>")
    compareTwoTexts(outPutXML, "<StaticMask>" + randomIp + "</StaticMask>")
    compareTwoTexts(outPutXML, "<StaticGateway>" + randomIp + "</StaticGateway>")
    compareTwoTexts(outPutXML, "<DhcpMode>0</DhcpMode>")
    compareTwoTexts(outPutXML, "<Reset>1</Reset>")
