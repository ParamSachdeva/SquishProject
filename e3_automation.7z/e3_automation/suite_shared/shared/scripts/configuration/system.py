from objectmaphelper import *

import socket

barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
objConfirmationWindow_QQuickWindowQmlImpl = {"name": "objConfirmationWindow", "type": "QQuickWindowQmlImpl", "visible": True}

hostname = socket.gethostname()
ip_address = socket.gethostbyname(hostname)

    
def disconnectAllSystem():                       
    test.log("disconnectAllSystem")   
    crossBtn = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objImg", "source": Wildcard("/images/mainWnd/icon_16_close.png"), "type": "CustomImage", "visible": True}
    closeConfirmbtn = {"container": objConfirmationWindow_QQuickWindowQmlImpl, "text": "Ok", "type": "CustomText", "unnamed": 1, "visible": True}
    
    while(1):    
        if(object.exists(crossBtn)):
            click(crossBtn)   
            snooze(.5)  
            click(closeConfirmbtn)    
        else:
            return 0     


def addSystem(ip):   
    barco_Inc_Event_Master_Toolset_Device_s_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objDeviceTab", "title": "Device(s)", "type": "CustomTab", "unnamed": 1, "visible": True}
    test.log("Add system IP: " + ip)
    newdevice_addNewDeviceButton = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "text": "+ Add new device", "type": "CustomText", "unnamed": 1, "visible": True}
    newdevice_displayText = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}
    newdevice_textInput = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "echoMode": 0, "objectName": "objProxy", "type": "TextInput", "visible": True}
    newdevice_addButton = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "text": "Add", "type": "CustomText", "unnamed": 1, "visible": True}
    
    click(newdevice_addNewDeviceButton)
    click(newdevice_displayText)
    type(waitForObject(newdevice_textInput), "<Ctrl+A>")
    wait(0.25)
    type(waitForObject(newdevice_textInput), ip)
    type(waitForObject(newdevice_textInput), "<NumPadEnter>")   
    click(newdevice_addButton)
    wait(0.25)


def connectEmulator():    
    disconnectAllSystem()   
    test.log(ip_address)
    addSystem(ip_address)