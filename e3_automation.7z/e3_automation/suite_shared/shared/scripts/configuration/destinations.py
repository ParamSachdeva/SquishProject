def addDestination(count):        
    return True


def addDestination(config):
    return True
