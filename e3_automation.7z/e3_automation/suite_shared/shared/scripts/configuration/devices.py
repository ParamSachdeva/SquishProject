from objectmaphelper import *

barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Device_s_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objDeviceTab", "title": "Device(s)", "type": "CustomTab", "unnamed": 1, "visible": True}


def systemDrop():
    test.log("systemDrop")
    system = {"container": barco_Inc_Event_Master_Toolset_Device_s_CustomTab, "objectName": "objDropDownHeader", "type": "DropDownHeader", "visible": True}
    mouseDrag(waitForObject(system), 161, 21, 314, 94, Qt.NoModifier, Qt.LeftButton)  
