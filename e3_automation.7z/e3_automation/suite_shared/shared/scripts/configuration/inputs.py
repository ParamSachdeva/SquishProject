from objectmaphelper import *

barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objScrollView", "type": "CustomScrollView", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_tabbar_TabBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "tabbar", "occurrence": 3, "type": "TabBar", "visible": True}
barco_Inc_Event_Master_Toolset_Input_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objCustomIpTab", "title": "Input", "type": "CustomTab", "unnamed": 1, "visible": True}

ipRightTab = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": "Input", "type": "CustomText", "unnamed": 1, "visible": True}
connectorObj = {"container": barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView, "objectName": "objConnSelectionRect", "type": "Rectangle", "visible": True}
    
def verifyaddAllInputs(type):
    connectorNumber = 0
    for s in findAllObjects(connectorObj): 
        connectorNumber+=1
        if (str(type)+"White" in str(s.parent.m_connImgSrc.path)):
            selectInput(connectorNumber,connectorNumber, "asc")
            createInputs()
            verifyInput("hdmi")
    
    

def createInputs():
    test.log("createInputs")
    barco_Inc_Event_Master_Toolset_Input_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objCustomIpTab", "title": "Input", "type": "CustomTab", "unnamed": 1, "visible": True}
    addBtn = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "text": "Add", "type": "CustomText", "unnamed": 1, "visible": True}
    #click(ipRightTab)
    click(addBtn)    
   
def createMultipleInputs(count):
    i = 5
    count = i+count
    while i < count:
        selectInput(i, i, "asc")
        createInputs()
        i += 1
                   
def selectInput(start, end, order):  
    test.log("select input: " + str(start) + ", " + str(end) + ", " + order)
    if(order == "asc"):
        while (start <= end):   
            connector = {"container": barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView, "objectName": "objConnSelectionRect", "occurrence": start, "type": "Rectangle", "visible": True}
            start = start + 1
            click(connector)                       
    elif(order == "desc"):
        while (start >= end):   
            connector = {"container": barco_Inc_Event_Master_Toolset_objScrollView_CustomScrollView, "objectName": "objConnSelectionRect", "occurrence": start, "type": "Rectangle", "visible": True}
            start = start - 1
            click(connector)               
    else:
        test.fail("Order not defined")

def verifyInput(type):
    test.log("verifyInput: " + type)
    click(ipRightTab)
    if(type == "hdmi"):
        hdmiExpand = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objImg", "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}          
        click(hdmiExpand) 
        inputName = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objDisplayedText", "type": "CustomText", "visible": True}
        test.compare(str(waitForObject(inputName).text).split("Input")[0], "HDMI") 
        click(hdmiExpand)                              
    elif(type == "dp"):
        dpExpand =  {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objImg", "occurrence": 2, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
        click(dpExpand) 
        inputName = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objDisplayedText", "occurrence": 2, "type": "CustomText", "visible": True}
        test.compare(str(waitForObject(inputName).text).split("Input")[0], "DP")       
        click(dpExpand)                      
    elif(type == "sdi"):
        sdiExpand = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objImg", "occurrence": 2, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
        click(sdiExpand) 
        inputName = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objDisplayedText", "occurrence": 3, "type": "CustomText", "visible": True}
        test.compare(str(waitForObject(inputName).text).split("Input")[0], "SDI")     
        click(sdiExpand)                            
    else:
        test.fail("Type not defined")
      
        
def deleteAllInputs(ipCount,typeCount):      
    #Code need to modify as per the dynamic list
    deleteBtn = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "text": "Delete", "type": "CustomText", "unnamed": 1, "visible": True}
    confirmDeleteBtn = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "text": "Delete", "type": "CustomText", "unnamed": 1, "visible": True}
    
    i = 1
    while(i <= typeCount):
        arrowObj = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objImg", "occurrence": i, "source": Wildcard("/images/svgImages/downArrow.svg"), "type": "CustomImage", "visible": True}
        click(arrowObj)
        i+=1
    
    keyPress("<Ctrl>")
    i = 1
    while(i <= ipCount):
        inputObj = {"container": barco_Inc_Event_Master_Toolset_Input_CustomTab, "objectName": "objDisplayedText", "occurrence": i, "type": "CustomText", "visible": True}
        click(inputObj)        
        i+=1
    keyRelease("<Ctrl>")

    click(deleteBtn)
    click(confirmDeleteBtn)
    snooze(0.25)