from objectmaphelper import *

import shutil

barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
e_2_QQuickWindowQmlImpl = {"title": "E-2", "type": "QQuickWindowQmlImpl", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Settings_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objSettingTab", "title": "Settings", "type": "CustomTab", "unnamed": 1, "visible": True}
barco_Inc_Event_Master_Toolset_Device_s_CustomTab = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objDeviceTab", "title": "Device(s)", "type": "CustomTab", "unnamed": 1, "visible": True}
o_QQuickWindowQmlImpl = {"type": "QQuickWindowQmlImpl", "unnamed": 1, "visible": True}
objScrollView_ScrollView = {"container": o_QQuickWindowQmlImpl, "id": "objScrollView", "type": "ScrollView", "unnamed": 1, "visible": True}
objAppStatusBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objStatusBarText", "type": "CustomText", "visible": True}
objAppTitleBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objActionBar", "type": "Rectangle", "unnamed": 1, "visible": True}

def getpid(process_name):
    return [item.split()[1] for item in os.popen('tasklist').read().splitlines()[4:] if process_name in item.split()]

def launchMacchia(): 
    test.log("Start Application..")   
    testSettings.logScreenshotOnFail = True
    testSettings.logScreenshotOnError = True
    startApplication("EventMaster")  
    wait(0.25)      
    #maximizeMachhia()

def closeApp():
    closeApp_yesButton = {"container": e_2_QQuickWindowQmlImpl, "text": "Yes", "type": "CustomText", "unnamed": 1, "visible": True}
    test.log("Close Application..")
    closeWindow(barco_Inc_Event_Master_Toolset_WindowUI)
    wait(1)
    click(closeApp_yesButton)
    

def verifyStatusBar(msg):
    test.log("verifyStatusBar")
    statusBarText = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "objStatusBarText", "type": "CustomText", "visible": True}
    test.compare(str(waitForObject(statusBarText).text), msg)                                 


def launchEmulator():
    pid = getpid("mvp.exe")    
    if(pid):       
        test.log("Emulator already launched with process ID: " + str(pid))
    else:    
        test.log("launchEmulator")      
        os.chdir("C:\Automation\TestSetup\Installer\mvp")
        os.startfile("mvp.bat")
        snooze(10)
    

def resetEmulator():
    dir = 'C:/Automation/TestSetup/Installer/mvp/mvp_9876/xml'
    shutil.rmtree(dir)
        
def closeEmulator(): 
    test.log("closeEmulator")
    os.system('wmic process where name="' + "mvp.exe" + '" delete')
    os.system('wmic process where name="' + "mvp.bat" + '" delete')
    os.system('wmic process where name="' + "Emulator.exe" + '" delete')

def maximizeMachhia():
    maximizeIcon = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "id": "objIconImage", "source": Wildcard("/images/otherImages/normal20x20.png"), "type": "Image", "unnamed": 1, "visible": True}
    click(maximizeIcon)
    wait(.25)

def scrollDown(Obj):
    if(object.exists(Obj)):
        mouseClick(waitForObjectExists(Obj), 3, 606, Qt.LeftButton)    
        snooze(0.25)
   

def moveDragger(draggerObj,direction):
    if(direction == "right"):
        mouseDrag(waitForObject(draggerObj), 79, 2, 19, 0, Qt.NoModifier, Qt.LeftButton)
    elif(direction == "left"):
        mouseDrag(waitForObject(draggerObj), 79, 2, -29, 0, Qt.NoModifier, Qt.LeftButton)
    else:
        test.fail("Direction not defined")

def searchSelectFromDropDown(arrowObj,inputObj,text):
    searchedItem =   {"container": objScrollView_ScrollView, "id": "objHoverRect", "type": "Rectangle", "unnamed": 1, "visible": True}
    click(arrowObj)
    click(inputObj)    
    updateText(waitForObject(inputObj),text)
    click(searchedItem)
    
    
def openOutgoingXML():
        updateText(waitForObject(barco_Inc_Event_Master_Toolset_WindowUI), "<Ctrl+O>");snooze(1)
        
