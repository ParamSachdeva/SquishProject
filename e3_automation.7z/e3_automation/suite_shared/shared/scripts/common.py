import time
from toplevelwindow import *

def click(obj):    
    mouseClick(waitForObject(obj))
    wait(0.25)

def doubleClick(obj):    
    doubleClick(waitForObject(obj))
    wait(0.25)

def wait(time):
    snooze(time)

def getObjectPropety(obj, prop):
    #test.log(obj)
    #test.log(prop)  
    property = str(prop) 
    #test.log(str(waitForObject(obj).prop))
    value = str(waitForObject(obj).property)
    return value 

def updateText(obj, text):
    type(waitForObject(obj), "<Ctrl+A>")
    snooze(.25)
    type(waitForObject(obj), text)    
    snooze(.25)
    type(waitForObject(obj), "<Return>")
    snooze(.25)

def textMatch(text, obj):
    test.log(str(waitForObjectExists(obj).text))
    if text in str(waitForObjectExists(obj).text): 
        test.compare("true", "true", "Object Text Match: " + str(waitForObject(obj).text))
        return True
    else:
        test.fail("Object Text not Match: " + str(waitForObject(obj).text))
        return False

def compareTwoTexts(text1, text2):
    if text2 in text1: 
        test.compare("true", "true", "Object Text Match: " + text2)
        return True
    else:
        test.fail("Object Text not Match: " + text2)
        return False

def objPropMatch(obj, prop, value):
    test.log("objPropMatch " + prop + " " + value)
    if value in str(waitForObjectExists(obj).prop): 
        return True
    else:
        test.fail("Object Text not Match: " + str(waitForObject(obj).prop))
        return False
   
def objPropNotMatch(obj, prop, value):
    test.log("objPropNotMatch" + prop + value)
    if value in str(waitForObjectExists(obj).prop): 
        test.fail("Object Text not Match: " + str(waitForObject(obj).prop))
        return False
    else:
        # test.compare("true", "true", "Object Text not Match: " + str(waitForObject(obj).prop))
        return True

def objectExist(obj):   
    if(object.exists(obj)):
        test.compare("True", "True", str(obj) + "obj Exist") 
        return True            
    else:
        test.fail(str(obj) + "obj Not Exist")
        return False
       
def objectNotExist(obj):   
    if(object.exists(obj)):
        test.fail(str(obj) + "obj  Exist")           
    else:
        test.compare("True", "True", str(obj) + "obj Not Exist")    

def getText(obj):
    test.log("getText")
    return str(waitForObject(obj).text)
        
def verifyText(obj, text):      
    test.log(str(waitForObjectExists(obj).text))
    if (text == str(waitForObjectExists(obj).text)): 
        test.compare("true", "true", "Object Text Match: " + str(waitForObjectExists(obj).text))
        return True
    else:
        test.fail("Object Text not Match: " + str(waitForObjectExists(obj).text))
        return False
    
def isObjectEnable(obj):    
    if (waitForObjectExists(obj).parent.enabled == True):
        test.log("Object Enabled: " + str(obj))
        return True 
    else:
        test.fail("Object not Enabled: " + str(obj))
        return False 

def isObjectDisable(obj):
    if (waitForObjectExists(obj).parent.enabled == False):
        test.log("Object Disabled: " + str(obj))
        return True 
    else:
        test.fail("Object not Disabled: " + str(obj))
        return False 

def drag(obj, xPos, yPos):
    mouseDrag(waitForObject(obj), 5, 5, xPos, yPos, Qt.NoModifier, Qt.LeftButton)

def fetchList(objDropDown):
    log("fetchList")

def verifyobjProperty(obj, property):
    log("verifyobjProperty")

def scrollListInsideTab(tabName, scrollType, direction, scrollVal): 
    test.log("Scrolling the list inside " + tabName + " tab")
    # creating custom locator
    customizedlocatorContainer = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "title": tabName, "type": "CustomTab", "unnamed": 1, "visible": True}
    scrollObjectLocator = {"container": customizedlocatorContainer, "id": "vscrollbar", "orientation": 2, "type": "ScrollBar", "unnamed": 1, "visible": True} 
    
    # commented below code to check if this piece of code is actially needed
    # currently occurrence is considered because there is no unique identifier for the left, center and right side tab bars
    #     barco_Inc_Event_Master_Toolset_tabbar_TabBar = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "tabbar", "occurrence": 3, "type": "TabBar", "visible": True}
    #     tabNameObject = {"container": barco_Inc_Event_Master_Toolset_tabbar_TabBar, "text": tabName, "type": "CustomText", "unnamed": 1, "visible": True}
    
    #     mouseClick(waitForObject(tabNameObject))
    # scrolling based on vertical direction
    if(scrollType.lower() == "vertical"):
        mouseWheel(waitForObject(scrollObjectLocator), 5, 30, 0, -600, Qt.NoModifier)
        if(direction.lower() == "down"):
            # dragging down
            mouseWheel(waitForObject(scrollObjectLocator), 5, 30, 0, -scrollVal, Qt.NoModifier)

        elif(direction.lower() == "up"):
            # dragging up
            mouseWheel(waitForObject(scrollObjectLocator), 5, 30, 0, scrollVal, Qt.NoModifier)
        else:
            test.fail("Invalid value \'" + direction + "\'. \'Direction\' for vertical scrolling can either be \'up\' or \'down\'")
     
    # scrolling based on horizontal direction    
    elif(scrollType.lower() == "horizontal"):
        mouseWheel(waitForObject(scrollObjectLocator), 5, 30, -600, 0, Qt.NoModifier)
        if(direction.lower() == "right"):
            # dragging right
            mouseWheel(waitForObject(scrollObjectLocator), 5, 30, scrollVal, 0, Qt.NoModifier)
        if(direction.lower() == "left"):
            # dragging left
            mouseWheel(waitForObject(scrollObjectLocator), 5, 30, -scrollVal, 0, Qt.NoModifier)
        else:
            test.fail("Invalid value \'" + direction + "\'. \'Direction\' for horizontal scrolling can either be \'right\' or \'left\'")
    
    else:
        test.fail("Invalid value \'" + scrollType + "\'. \'Scroll Type\' can either be \'horizontal\' or \'vertical\'")

def isRadioButtonChecked(obj, isChecked):
    if(isChecked):    
        if (waitForObjectExists(obj).parent.checked == True):
            test.compare("true", "true", "Radio Button Checked: " + str(waitForObject(obj).text))
            return True 
        else:
            test.fail("Radio Button not Checked: " + str(obj))
            return False
    elif not (isChecked):
        if (waitForObjectExists(obj).parent.checked == False):
            test.compare("true", "true", "Radio Button Unchecked: " + str(waitForObject(obj).text))
            return True 
        else:
            test.fail("Radio Button Checked: " + str(obj))
            return False

def enableDisableToggle(toggleObj,flag):
    if(flag):    
        if(waitForObjectExists(toggleObj).m_bEnabled == False):
            click(toggleObj)
            test.verify(waitForObjectExists(toggleObj).m_bEnabled == True)
    else:
        if(waitForObjectExists(toggleObj).m_bEnabled == True):
            click(toggleObj)
            test.verify(waitForObjectExists(toggleObj).m_bEnabled == False)

def enableObject(disabledObject):
    test.log("Enabling Object")
    if(waitForObjectExists(disabledObject).parent.enabled == False):
       click(disabledObject)
       test.verify(isObjectEnable(disabledObject))
       test.log("Object enabled successfully")
    elif(waitForObjectExists(disabledObject).parent.enabled == True):
        test.log("Object already enabled hence skipping enabling")
    else:
        test.fail("Unable to enable object")     
    
def disableObject(enabledObject):
    test.log("Disabling Object")
    if(waitForObjectExists(enabledObject).parent.enabled == True):
        click(enabledObject)
        test.verify(isObjectEnable(enabledObject))
        test.log("Object disabled successfully")
    elif(waitForObjectExists(enabledObject).parent.enabled == False):
        test.log("Object already disabled hence skipping disabling")

    else:
        test.fail("Unable to disable object")

def multiSelectList(listToBeClicked, tabName, startIndexOfList):
    test.log("Multi-selecting list")
    j = 1
    try:
        i = startIndexOfList
        if(len(findAllObjects(listToBeClicked)) != 0):
            keyPress('<Ctrl>')
            for i in findAllObjects(listToBeClicked):
                if(j % 10 == 0):
                    if(len(findAllObjects(listToBeClicked)) > 40):
                        scrollListInsideTab(tabName, "vertical", "down", 200)
                    else:
                        scrollListInsideTab(tabName, "vertical", "down", 120)
                click(i)
                j = j + 1
            keyRelease('<Ctrl>')
        else:
            test.fail("Unable to fetch the list, please check the locator")
    # Finally will release the <Ctrl> key if there is failure post pressing the key due to any runtime exception
    finally:
        keyRelease('<Ctrl>')
        
# old function, kept for analysis
# def moveDetachableTab(tabName, sourceOccurrence, sourceSide, destinationOccurrence, destinationSide):
#     test.log("Moving : "+tabName+ "  from  "+ sourceSide +"  to  " +destinationSide)
#     
#     barco_Inc_Event_Master_Toolset_WindowUI = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
#     sourceWindow = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "tabbar", "occurrence": sourceOccurrence, "type": "TabBar", "visible": True}
#     destinationWindow = {"container": barco_Inc_Event_Master_Toolset_WindowUI, "objectName": "tabbar", "occurrence": destinationOccurrence, "type": "TabBar", "visible": True}
#     tabObjectSource = {"container": sourceWindow, "text": tabName, "type": "CustomText", "unnamed": 1, "visible": True}    
#     tabObjectDestination = {"container": destinationWindow, "text": tabName, "type": "CustomText", "unnamed": 1, "visible": True} 
#     
#     win = ToplevelWindow.focused()
#     geom = win.geometry
#     width  = geom.width
#     height = geom.height
#      
#     if(sourceSide == "Left"):
#          
#         if(destinationSide == "Right"):
#             xPos = int(width/1.06)
#             yPos = (height/40)
#         
#         elif(destinationSide == "Center1"):
#            xPos = int(width/6.8)
#            yPos = (height/40)
#             
#         elif(destinationSide == "Center2"):
#            xPos = int(width/5.5)
#            yPos = (height/40)
#          
#         elif(destinationSide == "Center3"):
#            xPos = int(width/2.3)
#            yPos = (height/40)
#          
#         elif(destinationSide == "Center4"):
#            xPos = int(width/1.55)
#            yPos = (height/40)
#         
#         else:
#             test.fail("Invalid value of destination, please re-check the value")
#  
#             
#     elif(sourceSide == "Right"):
#         if(destinationSide == "Left"):
#            xPos = int(-width/1.22)
#            yPos = (height/40)
#             
#         elif(destinationSide == "Center1"):
#            xPos = int(-width/1.5)
#            yPos = (height/40)
#             
#         elif(destinationSide == "Center2"):
#            xPos = int(-width/1.95)
#            yPos = (height/40)
#          
#         elif(destinationSide == "Center3"):
#            xPos = int(-width/2.50)
#            yPos = (height/40)
#          
#         elif(destinationSide == "Center4"):
#            xPos = int(-width/5.5)
#            yPos = (height/40)
#         
#         else:
#             test.fail("Invalid value of destination, please re-check the value")
#      
#             
#     elif(sourceSide == "Center1"):
#         if(destinationSide == "Right"):
#             xPos = int(width/1.5)
#             yPos = (height/40)
#             
#         elif(destinationSide == "Left"):
#            xPos = int(-width/6.1)
#            yPos = (height/40)
#            
#         else:
#             test.fail("Invalid value of destination, please re-check the value")
#             
#     elif(sourceSide == "Center2"):
#         if(destinationSide == "Right"):
#             xPos = int(width/1.8)
#             yPos = (height/40)
#             
#         elif(destinationSide == "Left"):
#            xPos = int(-width/4)
#            yPos = (height/40)
#         
#         else:
#             test.fail("Invalid value of destination, please re-check the value")
#             
#     elif(sourceSide == "Center3"):
#         if(destinationSide == "Right"):
#             xPos = int(width/3.1)
#             yPos = (height/40)
#             
#         elif(destinationSide == "Left"):
#            xPos = int(-width/2.2)
#            yPos = (height/40)
#         
#         else:
#             test.fail("Invalid value of destination, please re-check the value")
#             
#     elif(sourceSide == "Center4"):
#         if(destinationSide == "Right"):
#             xPos = int(width/4.2)
#             yPos = (height/40)
#             
#         elif(destinationSide == "Left"):
#            xPos = int(-width/1.8)
#            yPos = (height/40)
#            
#         else:
#             test.fail("Invalid value of destination, please re-check the value")
#     
#     else:
#         test.fail("Invalid value of source, please re-check the value")
#  
#     mousePress(tabObjectSource)
#     drag(tabObjectSource, xPos, yPos)
#     objectExist(tabObjectDestination)


def moveDetachableTab(tabName, sourceOccurrence, xPos, yPos, destinationOccurrence):
  
    mainWindowContainer = {"title": "Barco Inc | Event Master Toolset", "type": "WindowUI", "unnamed": 1, "visible": True}
    sourceWindow = {"container": mainWindowContainer, "objectName": "tabbar", "occurrence": sourceOccurrence, "type": "TabBar", "visible": True}
    destinationWindow = {"container": mainWindowContainer, "objectName": "tabbar", "occurrence": destinationOccurrence, "type": "TabBar", "visible": True}
    tabObjectSource = {"container": sourceWindow, "text": tabName, "type": "CustomText", "unnamed": 1, "visible": True}    
    tabObjectDestination = {"container": destinationWindow, "text": tabName, "type": "CustomText", "unnamed": 1, "visible": True} 
    
    mousePress(tabObjectSource)
    drag(tabObjectSource, xPos, yPos)
    objectExist(tabObjectDestination)

        
def scrollTillObjVisible(obj, tabName, scrollType, direction, scrollVal):
    k = 0;
    while(k < 20):
        k += 1
        try:
            mouseMove(obj)
            break;
        except RuntimeError as e:
            scrollListInsideTab(tabName, scrollType, direction, scrollVal)
    if(k >= 20):
        test.fail("Unable to find object in the list : " + str(obj))    
            

def verifyZoomFunctionality(newContainer, rectAreaObj):
    test.log("Verifying zoom functionality")
    zoomValContainer = {"container": newContainer, "id": "objZoomRect", "type": "ZoomRect", "unnamed": 1, "visible": True}
    zoomVal = {"container": zoomValContainer, "type": "CustomText", "unnamed": 1, "visible": True}
    plusButton = {"container": zoomValContainer, "id": "icon", "source": Wildcard("images/svgImages/plus.svg"), "type": "Image", "unnamed": 1, "visible": True}
    minusButton = {"container": zoomValContainer, "id": "icon", "source": Wildcard("images/svgImages/minus.svg"), "type": "Image", "unnamed": 1, "visible": True}
    compareTwoTexts("100", str(waitForObjectExists(zoomVal).text).split(" ")[0])
    
    possibleMinusVal = ["75", "50", "25", "0"]
    for i in possibleMinusVal:
        xPos = waitForObjectExists(rectAreaObj).transformOriginPoint.x
        yPos = waitForObjectExists(rectAreaObj).transformOriginPoint.y
        
        click(minusButton)
        
        newXPos = waitForObjectExists(rectAreaObj).transformOriginPoint.x
        newYPos = waitForObjectExists(rectAreaObj).transformOriginPoint.y
            
        if(i == "0"):
            compareTwoTexts("25", str(waitForObjectExists(zoomVal).text).split(" ")[0])
            test.verify(xPos == newXPos, "Zoom out successful")
            test.verify(yPos == newYPos, "Zoom out successful")
        else:
            compareTwoTexts(i, str(waitForObjectExists(zoomVal).text).split(" ")[0])
            test.verify(xPos > newXPos, "Zoom out successful")
            test.verify(yPos > newYPos, "Zoom out successful")
        
    possiblePlusVal = ["50", "75", "100", "125", "150", "175", "200", "225"]
    for i in possiblePlusVal:
        xPos = waitForObjectExists(rectAreaObj).transformOriginPoint.x
        yPos = waitForObjectExists(rectAreaObj).transformOriginPoint.y
        
        click(plusButton)
        
        newXPos = waitForObjectExists(rectAreaObj).transformOriginPoint.x
        newYPos = waitForObjectExists(rectAreaObj).transformOriginPoint.y
        if(i == "225"):
            compareTwoTexts("200", str(waitForObjectExists(zoomVal).text).split(" ")[0])
            test.verify(xPos == newXPos, "Zoom in successful")
            test.verify(yPos == newYPos, "Zoom in successful")
        else:
            compareTwoTexts(i, str(waitForObjectExists(zoomVal).text).split(" ")[0])
            test.verify(xPos < newXPos, "Zoom in successful")
            test.verify(yPos < newYPos, "Zoom in successful")
    resetZoom(newContainer)

    
def resetZoom(newContainer):
    test.log("Resetting zoom")
    zoomValContainer = {"container": newContainer, "id": "objZoomRect", "type": "ZoomRect", "unnamed": 1, "visible": True}
    zoomVal = {"container": zoomValContainer, "type": "CustomText", "unnamed": 1, "visible": True}    
    plusButton = {"container": zoomValContainer, "id": "icon", "source": Wildcard("images/svgImages/plus.svg"), "type": "Image", "unnamed": 1, "visible": True}
    minusButton = {"container": zoomValContainer, "id": "icon", "source": Wildcard("images/svgImages/minus.svg"), "type": "Image", "unnamed": 1, "visible": True}
    i = 0
    while not (str(waitForObjectExists(zoomVal).text).split(" ")[0] == "100"):
        i += 1
        if(str(waitForObjectExists(zoomVal).text).split(" ")[0] > "100"):
            click(minusButton)
        elif(str(waitForObjectExists(zoomVal).text).split(" ")[0] < "100"):
            click(plusButton)
        if(i > 5):
            test.fail("unable to reset the zoom settings")
            break;                    


def verifyTimer(time, method):
    timeout = 10    
    if(time > timeout):
        test.fail(method + " took more " + "time: " + str(time) + " seconds" + ", timeout: " + str(timeout) + " seconds")
    else:
        test.verify(True, method + " time " + str(time) + " seconds")


def dragAndDropObj(obj, dropLoc, droppedObj=None):  
    test.log("Performing drag-drop")
    mouseMove(waitForObject(obj), 5, 5)
    mousePress(waitForObject(obj), 5, 5, MouseButton.LeftButton)
    snooze(0.25)
# Moving mouse back and forth to ensure selection
#     move_width = 20
#     for i in range(move_width):
#         snooze(0.05)
#         mouseMove(waitForObject(obj), 5 + i, 10)
#     for i in range(move_width, -1, -1):
#         snooze(0.05)
#         mouseMove(waitForObject(obj), 5 + i, 10)
            
    mouseMove(waitForObject(dropLoc), 50, 50)
    mouseRelease(waitForObject(dropLoc), MouseButton.LeftButton)
    if(droppedObj):
        if(len(str(droppedObj)) != 0):
            i = 0
            while(i < 11):
                i += 1
                snooze(0.25)
                if(object.exists(droppedObj)):
                    test.log("Object dragged successfully")
                    break
            if(i >= 11):
                test.fail("Unable to drag object")

def getHightofWindow():
    win = ToplevelWindow.focused()
    geom = win.geometry   
    height = geom.height 
    return height 

def getWidthofWindow():
    win = ToplevelWindow.focused()
    geom = win.geometry   
    width = geom.width    
    return width 

def selectFromDropDownList():
    return True