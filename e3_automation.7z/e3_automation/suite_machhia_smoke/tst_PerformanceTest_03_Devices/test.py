# source(findFile("scripts", "initialize.py"))
# source(findFile("scripts", "devices.py"))
# 
# 
# def main(): 
# #We will create a separate suite for this
   
#     launchMacchia()
#     disconnectAllSystem()    
#     test.compare(str(waitForObject(statusIcon).source.path), "/images/generalImages/g7_yellowDot.png")
#     
#     t0 = time.time()
#     systemDrop()
#     test.compare(str(waitForObject(statusIcon).source.path), "/images/generalImages/g7_greenDot.png")
#     t1 = time.time()
#     verifyTimer(t1-t0,"systemDrop")
#        
#     
#     t0 = time.time()
#     disconnectAllSystem()    
#     test.compare(str(waitForObject(statusIcon).source.path), "/images/generalImages/g7_yellowDot.png")
#     t1 = time.time()
#     verifyTimer(t1-t0,"disconnectAllSystem")    