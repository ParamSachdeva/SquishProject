import os

sd = os.path.abspath("..\..\suite_shared\shared\scripts") 
test.log("Shared Directory Path " + os.path.abspath("..\..\suite_shared\shared\scripts")) 

#sd = os.path.abspath("..\..\suite_machhia_configpage") 
#test.log("Shared Directory Path " + os.path.abspath("..\..\suite_machhia_configpage")) 

source(findFile("scripts", sd + "/common.py"))
source(findFile("scripts", sd + "/systemlevel.py"))
source(findFile("scripts", sd + "/configuration/devices.py"))
source(findFile("scripts", sd + "/configuration/system.py"))
source(findFile("scripts", sd + "/configuration/inputs.py"))