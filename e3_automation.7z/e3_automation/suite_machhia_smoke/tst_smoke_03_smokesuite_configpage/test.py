#https://kb.froglogic.com/squish/howto/create-master-test-case/#the-master-test-case--python


import exceptions
import os.path
    
def main():
    sd = os.path.abspath("..\..\suite_machhia_configpage") 
    source(findFile("scripts", sd + "\\tst_01_Devices_VerifyDiscoveryTabInfo\\test.py"))

    ignore = ("tst_01_Devices_VerifyDiscoveryTabInfo")
    for test_path in os.listdir(".."):
        if (test_path in ignore or
            not test_path.startswith("tst_") or
            test_path == os.path.basename(os.getcwd())):
            continue
        test.log("Executing: %s" % test_path)
        source(os.path.join("..", test_path, "test.py"))

        # Start the application, if not running; useful
        # to ignore application crashes or application
        # having been stopped by previous test case:
        #if applicationContextList().length == 0:
        #    startApplication("addressbook")

        try:
            eval("main()") # Executes the source'd test case's main() function
        except exceptions.Exception, e:
            test.log("Error occurred in test case: %s: %s" % (test_path, e))