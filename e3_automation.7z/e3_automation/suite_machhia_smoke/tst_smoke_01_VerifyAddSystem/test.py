source(findFile("scripts", "intialize.py"))

def main():    
    launchMacchia()
    addSystem("10.98.6.100")
    closeApp()