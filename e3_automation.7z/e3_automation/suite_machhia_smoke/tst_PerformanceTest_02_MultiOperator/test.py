# source(findFile("scripts", "initialize.py"))
# source(findFile("scripts", "multioperator.py"))
# 
# def main():
# 
# #We will create a separate suite for this

# 
# #     
# #     test.log("Validate Performance Time for areas: "
# #     + "Application Launch, Emulator Launch, System Active State")    
# #        
# #     launchMacchia() 
# #     launchEmulator()    
# #     connectEmulator()
# #     
# #     t0 = time.time()
# #     launchMultioperator()
# #     t1 = time.time()
# #     verifyTimer(t1-t0,"launchMultioperator()")
# #   
# #        
# #     t0 = time.time()
# #     enableOperator(1)
# #     enableOperator(2)
# #     enableOperator(3)   
# #     t1 = time.time()
# #     verifyTimer(t1-t0,"enableOperator")
# # 
# #     t0 = time.time()
# #     disableOperator(1)
# #     disableOperator(2)
# #     disableOperator(3)
# #     t1 = time.time()
# #     verifyTimer(t1-t0,"disableOperator")