source(findFile("scripts", "initialize.py"))
source(findFile("scripts", "inputadjustment.py"))

def main():
    test.log("Verification of HDMI Input Adjustments Settings Tab Section")
    closeEmulator() 
    launchMacchia()   
    resetEmulator()
    launchEmulator()  
    connectEmulator()        
    
    t0 = time.time()
    selectInput(5, 5, "asc")
    createInputs()
    verifyInput("hdmi")   
    t1 = time.time()
    verifyTimer(t1-t0,"selectInput, createInputs & verifyInput HDMI")    